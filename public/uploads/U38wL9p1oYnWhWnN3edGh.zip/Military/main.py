import discord
from discord.ext import commands, tasks
import asyncio
import os
import random
from mongodb_database import MongoDatabase
from game_logic import GameLogic
from shop import Shop
from combat import Combat
from embeds import EmbedManager
from config import Config
import traceback

# Bot configuration
intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.members = True

bot = commands.Bot(command_prefix='!', intents=intents)

# Initialize PostgreSQL database
from postgres_database import PostgresDatabase
db = PostgresDatabase()
game_logic = GameLogic(db)
shop_manager = Shop(db)
combat = Combat(db)
embed_manager = EmbedManager()
config = Config()

# Authorized channels storage (loaded from database)
authorized_channels = set()

@bot.event
async def on_ready():
    print(f'{bot.user} قد تم تشغيله بنجاح!')
    print("Dev by CodeX team 💻")
    await db.initialize()
    
    # Load authorized channels from database
    global authorized_channels
    authorized_channels = await db.get_authorized_channels()
    
    # Debug: Print available commands before sync
    print(f"Available slash commands: {[cmd.name for cmd in bot.tree.walk_commands()]}")
    
    try:
        synced = await bot.tree.sync()
        print(f"تم مزامنة {len(synced)} أمر slash")
        for cmd in synced:
            print(f"✓ /{cmd.name} - {cmd.description}")
    except Exception as e:
        print(f"فشل في مزامنة الأوامر: {e}")
        traceback.print_exc()
    
    # Start maintenance task after bot is ready
    if not maintenance_task.is_running():
        maintenance_task.start()

# Channel authorization check
async def is_authorized_channel(ctx_or_interaction):
    """Check if channel is authorized"""
    try:
        if hasattr(ctx_or_interaction, 'channel'):
            # This is a context (prefix command)
            channel_id = ctx_or_interaction.channel.id
        else:
            # This is an interaction (slash command)
            channel_id = ctx_or_interaction.channel.id
        
        return channel_id in authorized_channels
    except Exception as e:
        print(f"Error checking authorized channel: {e}")
        return False

# Slash commands - setchannel only
@bot.tree.command(name="setchannel", description="Set bot channel")
async def setchannel(interaction: discord.Interaction, channel: discord.TextChannel = None):
    try:
        if not interaction.user.guild_permissions.manage_channels:
            embed = embed_manager.error_embed("ليس لديك صلاحية!", "تحتاج صلاحية إدارة القنوات")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        target_channel = channel or interaction.channel
        
        # Check if channel is already authorized
        if await db.is_channel_authorized(target_channel.id):
            embed = embed_manager.error_embed(
                "القناة مربوطة بالفعل! ✅",
                f"تم ربط {target_channel.mention} كقناة البوت مسبقاً\n\nيمكن استخدام جميع الأوامر في هذه القناة\n\n**Dev by CodeX team 💻**"
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Add channel to authorized channels
        success = await db.add_authorized_channel(
            target_channel.id, 
            interaction.guild.id, 
            target_channel.name, 
            interaction.user.id
        )
        
        if success:
            authorized_channels.add(target_channel.id)
            embed = embed_manager.success_embed(
                "تم تعيين القناة بنجاح! ✅",
                f"تم ربط {target_channel.mention} كقناة البوت\n\nالآن يمكن استخدام جميع الأوامر في هذه القناة\n\n**Dev by CodeX team 💻**"
            )
        else:
            embed = embed_manager.error_embed("خطأ في ربط القناة", "حدث خطأ أثناء ربط القناة")
        await interaction.response.send_message(embed=embed)
        
    except Exception as e:
        print(f"Error in setchannel: {e}")
        embed = embed_manager.error_embed("خطأ في النظام", "حدث خطأ غير متوقع")
        await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="help", description="عرض المساعدة التفاعلية")
async def help_slash(interaction: discord.Interaction):
    try:
        view = HelpNavigationView()
        embed = view.get_current_embed()
        await interaction.response.send_message(embed=embed, view=view)
    except Exception as e:
        print(f"Error in help_slash: {e}")
        embed = embed_manager.error_embed("خطأ في النظام", "حدث خطأ في عرض المساعدة")
        await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="جيش", description="إنشاء جيش جديد")
async def army_slash(interaction: discord.Interaction, اسم_الجيش: str):
    """Create a new army - slash command version"""
    try:
        user_id = interaction.user.id
        username = interaction.user.display_name
        
        # Check if channel is authorized
        if not await is_authorized_channel(interaction):
            embed = discord.Embed(
                title="❌ القناة غير مُصرح بها",
                description="يجب على المشرف استخدام `/setchannel` أولاً لتفعيل البوت في هذه القناة",
                color=0xFF0000
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Check if player already exists
        existing_player = await db.get_player(user_id)
        if existing_player:
            embed = discord.Embed(
                title="⚠️ لديك جيش بالفعل!",
                description=f"جيشك **{existing_player['army_name']}** موجود بالفعل!\n"
                           f"استخدم `!حالة` لعرض معلومات جيشك",
                color=0xFFAA00
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Validate army name
        if not اسم_الجيش or len(اسم_الجيش.strip()) < 2:
            embed = discord.Embed(
                title="❌ اسم الجيش غير صالح",
                description="يجب أن يكون اسم الجيش أطول من حرفين",
                color=0xFF0000
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        if len(اسم_الجيش) > 50:
            embed = discord.Embed(
                title="❌ اسم الجيش طويل جداً",
                description="يجب أن يكون اسم الجيش أقل من 50 حرف",
                color=0xFF0000
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Create new player
        success = await db.create_player(user_id, username, اسم_الجيش.strip())
        
        if success:
            embed = discord.Embed(
                title="🎖️ تم إنشاء الجيش بنجاح!",
                description=f"**{اسم_الجيش}** جيشك الجديد تم إنشاؤه بنجاح!\n\n"
                           f"📊 **معلومات الجيش:**\n"
                           f"👥 الجنود: 100\n"
                           f"💰 العملات: 1000\n"
                           f"🏰 القاعدة: المستوى 1\n\n"
                           f"استخدم `!حالة` لعرض تفاصيل جيشك\n"
                           f"استخدم `!متجر` لشراء معدات جديدة\n"
                           f"استخدم `!غارة` لبدء الغارات\n\n"
                           f"🎯 **نصائح للمبتدئين:**\n"
                           f"• ابدأ بالغارات لكسب العملات والخبرة\n"
                           f"• طور قاعدتك ودفاعاتك\n"
                           f"• اشترِ أسلحة ومعدات أفضل\n"
                           f"• استخدم `!مساعدة` للحصول على دليل مفصل\n\n"
                           f"**Developed by CodeX team 💻**",
                color=0x00FF00
            )
            await interaction.response.send_message(embed=embed)
        else:
            embed = discord.Embed(
                title="❌ فشل في إنشاء الجيش",
                description="حدث خطأ أثناء إنشاء الجيش. حاول مرة أخرى.",
                color=0xFF0000
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
    except Exception as e:
        print(f"Error in army_slash command: {e}")
        embed = discord.Embed(
            title="❌ حدث خطأ",
            description="حدث خطأ أثناء معالجة الأمر. حاول مرة أخرى.",
            color=0xFF0000
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

# Command authorization decorator
def require_authorized_channel():
    async def predicate(ctx):
        if not await is_authorized_channel(ctx):
            embed = embed_manager.error_embed(
                "⚠️ قناة غير مخولة", 
                "يجب على الإدارة استخدام `/setchannel` أولاً لتفعيل البوت في هذه القناة\n\n**Dev by CodeX team 💻**"
            )
            await ctx.send(embed=embed)
            return False
        return True
    return commands.check(predicate)

# Start army command (converted to prefix)
@bot.command(name="جيش", aliases=["البدء"])
@require_authorized_channel()
async def start_army(ctx, *, اسم_الجيش: str):
    try:
        user_id = ctx.author.id
        
        # Check if user already has an army
        existing_army = await db.get_player(user_id)
        if existing_army:
            embed = embed_manager.error_embed("لديك جيش بالفعل!", f"جيشك: {existing_army['army_name']}")
            await ctx.send(embed=embed)
            return
        
        # Create new army
        success = await db.create_player(user_id, ctx.author.name, اسم_الجيش)
        if success:
            embed = embed_manager.success_embed(
                "تم إنشاء الجيش بنجاح! 🎖️",
                f"**اسم الجيش:** {اسم_الجيش}\n**الجنود:** 100\n**العملات:** 0\n\nيمكنك الآن البدء بالغارات لجمع العملات!\n\n**Dev by CodeX team 💻**"
            )
            await ctx.send(embed=embed)
        else:
            embed = embed_manager.error_embed("فشل في إنشاء الجيش", "حاول مرة أخرى")
            await ctx.send(embed=embed)
    except Exception as e:
        print(f"Error in start_army: {e}")
        embed = embed_manager.error_embed("خطأ في النظام", "حدث خطأ غير متوقع")
        await ctx.send(embed=embed)

# All other commands are now prefix commands only

# Remove default help command
bot.remove_command('help')

# Help command with forward/back navigation (prefix only)
@bot.command(name="مساعدة")
@require_authorized_channel()
async def help_command(ctx):
    """Help command with forward/back navigation"""
    try:
        view = HelpNavigationView()
        embed = view.get_current_embed()
        await ctx.send(embed=embed, view=view)
    except Exception as e:
        print(f"Error in help_command: {e}")

class HelpNavigationView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)
        self.current_page = 0
        self.pages = [
            "main",
            "missions", 
            "industries",
            "operations",
            "rewards",
            "commands"
        ]
    
    def get_current_embed(self):
        page_name = self.pages[self.current_page]
        
        if page_name == "main":
            return self.get_main_embed()
        elif page_name == "missions":
            return self.get_missions_embed()
        elif page_name == "industries":
            return self.get_industries_embed()
        elif page_name == "operations":
            return self.get_operations_embed()
        elif page_name == "rewards":
            return self.get_rewards_embed()
        elif page_name == "commands":
            return self.get_commands_embed()
    
    def get_main_embed(self):
        embed = discord.Embed(
            title="🎯 المهام العسكرية",
            description="**Dev by CodeX team 💻**\n\n",
            color=0x2F3136
        )
        
        embed.add_field(
            name="🗡️ المهام العسكرية",
            value="→ !مبارزة - مبارزة عسكرية تكتيكية\n→ !استطلاع - مهمة استطلاع المناطق\n→ !قنص - تدريب القنص والدقة\n→ !تفكيك - تفكيك القنابل\n→ !اقتحام - اقتحام القواعد",
            inline=False
        )
        
        embed.add_field(
            name="🏭 الصناعات",
            value="→ !مصنع - إدارة مصانع الأسلحة\n→ !قاعدة - بناء القواعد العسكرية\n→ !تجارة - تجارة الأسلحة",
            inline=False
        )
        
        embed.add_field(
            name="🌍 العمليات الكبرى",
            value="→ !غزو - غزو الدول\n→ !تخصيب - تخصيب اليورانيوم\n→ !نووية - صنع الأسلحة النووية\n→ !طيران - إدارة القوات الجوية\n→ !بحرية - إدارة القوات البحرية",
            inline=False
        )
        
        embed.add_field(
            name="💰 المكافآت",
            value="→ نظام المستويات (1-100)\n→ خصومات حسب المستوى\n→ مكافآت XP للمعارك\n→ ترقيات الرتب العسكرية",
            inline=False
        )
        
        embed.set_footer(text="صفحة 1/6 | Dev by CodeX team 💻")
        return embed
    
    def get_missions_embed(self):
        embed = discord.Embed(
            title="🗡️ المهام العسكرية",
            description="**Dev by CodeX team 💻**\n\n",
            color=0x8B0000
        )
        
        embed.add_field(
            name="⚔️ العمليات الأساسية",
            value="→ !جيش - إنشاء جيش جديد\n→ !غارة - تنفيذ غارات على الوحوش\n→ !حالة - عرض حالة الجيش والإحصائيات\n→ !متجر - شراء المعدات والأسلحة",
            inline=False
        )
        
        embed.add_field(
            name="🎯 العمليات القتالية",
            value="→ !هجوم - مهاجمة لاعب آخر\n→ !قصف - قصف بالصواريخ\n→ !صاروخ - اختيار نوع الصاروخ\n→ !صواريخ - عرض الصواريخ المتاحة",
            inline=False
        )
        
        embed.add_field(
            name="🏅 أوامر المساعدة",
            value="→ !مساعدة - عرض هذه القائمة\n→ !أوامر - قائمة جميع الأوامر\n→ !شرح - شرح مفصل للبوت\n→ !بداية - دليل المبتدئين",
            inline=False
        )
        
        embed.add_field(
            name="📊 أوامر إضافية",
            value="→ !أسلحة - عرض جميع الأسلحة المتاحة\n→ /setchannel - ربط قناة للبوت (Admin)\n→ /help - المساعدة التفاعلية",
            inline=False
        )
        
        embed.set_footer(text="صفحة 2/6 | Dev by CodeX team 💻")
        return embed
    
    def get_industries_embed(self):
        embed = discord.Embed(
            title="🏭 الصناعات",
            description="**Dev by CodeX team 💻**\n\n",
            color=0xFF4500
        )
        
        embed.add_field(
            name="🔧 تصنيع الأسلحة المتقدمة",
            value="→ !مصنع [سلاح] - تصنيع الأسلحة المتقدمة\n→ !قاعدة [عمل] - إدارة القواعد العسكرية\n→ !تجارة [عمل] - تجارة الأسلحة",
            inline=False
        )
        
        embed.set_footer(text="صفحة 3/6 | Dev by CodeX team 💻")
        return embed
    
    def get_operations_embed(self):
        embed = discord.Embed(
            title="🌍 العمليات الكبرى",
            description="**Dev by CodeX team 💻**\n\n",
            color=0x32CD32
        )
        
        embed.add_field(
            name="🌍 غزو الدول",
            value="→ !غزو [دولة] - غزو الدول\n→ !تخصيب - تخصيب اليورانيوم\n→ !نووية - صنع أسلحة نووية",
            inline=False
        )
        
        embed.set_footer(text="صفحة 4/6 | Dev by CodeX team 💻")
        return embed
    
    def get_rewards_embed(self):
        embed = discord.Embed(
            title="💰 المكافآت",
            description="**Dev by CodeX team 💻**\n\n",
            color=0xFFD700
        )
        
        embed.add_field(
            name="💰 المهام تعطي مكافآت أكبر",
            value="→ معدات نادرة عند النجاح\n→ بعض المهام تتطلب موارد\n→ الفشل قد يؤدي لخسائر",
            inline=False
        )
        
        embed.set_footer(text="صفحة 5/6 | Dev by CodeX team 💻")
        return embed
    
    def get_commands_embed(self):
        embed = discord.Embed(
            title="📋 جميع الأوامر",
            description="**Dev by CodeX team 💻**\n\n",
            color=0x9932CC
        )
        
        embed.add_field(
            name="⚔️ أوامر القتال",
            value="→ !هجوم [@لاعب] - مهاجمة لاعب\n→ !قصف [@لاعب] - قصف بالصواريخ\n→ !غارة [عدد] - غارة على الوحوش",
            inline=False
        )
        
        embed.add_field(
            name="🛒 أوامر الشراء",
            value="→ !متجر - فتح المتجر\n→ !حالة - عرض الإحصائيات\n→ !أسلحة - عرض الأسلحة",
            inline=False
        )
        
        embed.add_field(
            name="🎯 المهام والألعاب",
            value="→ !مبارزة - لعبة المبارزة\n→ !استطلاع - مهمة الاستطلاع\n→ !قنص - تدريب القنص",
            inline=False
        )
        
        embed.set_footer(text="صفحة 6/6 | Dev by CodeX team 💻")
        return embed
    
    def get_combat_embed(self):
        embed = discord.Embed(
            title="⚔️ أنظمة القتال",
            description="كل ما تحتاج معرفته عن القتال",
            color=0xff4500
        )
        embed.add_field(
            name="🐺 غارات الوحوش",
            value="`!غارة [1-10]` - كل 5 دقائق\n• ذئب بري (30-80 عملة)\n• دب شرس (60-120 عملة)\n• تنين صغير (100-200 عملة)\n• عملاق الجبل (150-300 عملة)\n• تنين النار (250-500 عملة)",
            inline=False
        )
        embed.add_field(
            name="⚔️ هجمات اللاعبين",
            value="`!هجوم [@لاعب]` - كل 10 دقائق\n• يعتمد على قوة الجيش\n• يمكن سرقة العملات\n• خسائر في الجنود\n• تأثير الدفاعات",
            inline=False
        )
        embed.add_field(
            name="🚀 الهجمات الصاروخية",
            value="• صاروخ مدمر (100 ضرر)\n• صاروخ باليستي (200 ضرر)\n• صاروخ نووي (500 ضرر)\n• يمكن اعتراضها بالدفاع الجوي",
            inline=False
        )
        embed.set_footer(text=f"الصفحة {self.current_page + 1}/{len(self.pages)} | Dev by CodeX team")
        return embed
    
    def get_economy_embed(self):
        embed = discord.Embed(
            title="🛒 الاقتصاد والمتجر",
            description="إدارة الموارد والشراء الذكي",
            color=0x9370db
        )
        embed.add_field(
            name="🪖 شراء الجنود",
            value="• جندي واحد: 5 عملات\n• 10 جنود: 45 عملة\n• 50 جندي: 200 عملة\n• 200 جندي: 900 عملة",
            inline=True
        )
        embed.add_field(
            name="🛡️ الدفاعات",
            value="• سور حماية: 500 عملة\n• 5 أسوار: 2000 عملة\n• دفاع جوي: 3000 عملة\n• ذخيرة دفاع: 100 عملة",
            inline=True
        )
        embed.add_field(
            name="🚀 الصواريخ",
            value="• صاروخ مدمر: 800 عملة\n• صاروخ باليستي: 1500 عملة\n• صاروخ نووي: 5000 عملة\n• قاعدة صواريخ: 2500 عملة",
            inline=True
        )
        embed.add_field(
            name="💡 نصائح اقتصادية",
            value="• ابدأ بشراء الجنود أولاً\n• ابن الدفاعات لحماية مواردك\n• استثمر في قاعدة الصواريخ\n• نوع مصادر دخلك",
            inline=False
        )
        embed.set_footer(text=f"الصفحة {self.current_page + 1}/{len(self.pages)} | Dev by CodeX team")
        return embed
    
    def get_advanced_embed(self):
        embed = discord.Embed(
            title="🏭 الأنظمة المتقدمة",
            description="القوات المتخصصة والتقنيات المتطورة",
            color=0x4169e1
        )
        embed.add_field(
            name="✈️ القوات الجوية",
            value="`!طيران شراء/غارة/حالة`\n• مقاتلة F-16 (800 عملة)\n• مقاتلة ميج-29 (1000 عملة)\n• قاذفة قنابل (1200 عملة)\n• طائرة استطلاع (600 عملة)",
            inline=False
        )
        embed.add_field(
            name="⚓ القوات البحرية",
            value="`!بحرية شراء/هجوم/حالة`\n• مدمرة (1000 عملة)\n• غواصة (1500 عملة)\n• حاملة طائرات (3000 عملة)\n• زورق دورية (500 عملة)",
            inline=False
        )
        embed.add_field(
            name="☢️ البرنامج النووي",
            value="`!تخصيب` - تخصيب اليورانيوم (500 عملة)\n`!نووية` - صنع قنبلة نووية (2000 عملة + 10 كيلو يورانيوم)\nيتطلب قاعدة مستوى 2+",
            inline=False
        )
        embed.set_footer(text=f"الصفحة {self.current_page + 1}/{len(self.pages)} | Dev by CodeX team")
        return embed
    

    
    @discord.ui.button(label="◀️ السابق", style=discord.ButtonStyle.secondary)
    async def previous_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.current_page > 0:
            self.current_page -= 1
        else:
            self.current_page = len(self.pages) - 1
        
        embed = self.get_current_embed()
        await interaction.response.edit_message(embed=embed, view=self)
    
    @discord.ui.button(label="▶️ التالي", style=discord.ButtonStyle.secondary)
    async def next_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.current_page < len(self.pages) - 1:
            self.current_page += 1
        else:
            self.current_page = 0
        
        embed = self.get_current_embed()
        await interaction.response.edit_message(embed=embed, view=self)

# PREFIX COMMANDS - All main commands are now prefix-based

@bot.command(name="غارة", aliases=['غاره', 'مغارة', 'مغاره'])
@require_authorized_channel()
async def raid_prefix(ctx, raids: int = 1):
    """Raid command with prefix"""
    try:
        user_id = ctx.author.id
        player = await db.get_player(user_id)
        
        if not player:
            embed = embed_manager.error_embed(
                "❌ لا يوجد جيش!",
                "أهلاً بك قائد! 🎖️\n\n**لبدء مغامرتك العسكرية:**\n• استخدم الأمر `!جيش اسم_جيشك` لإنشاء جيشك\n• اختر اسماً قوياً لجيشك\n• ابدأ رحلتك نحو المجد العسكري!\n\n**Dev by CodeX team 💻**"
            )
            await ctx.send(embed=embed)
            return
        
        if player['soldiers'] <= 0:
            embed = embed_manager.error_embed(
                "💀 جيش محطم!",
                "للأسف، جيشك قد دُمر في المعارك! 💔\n\n**لإعادة بناء قوتك:**\n• استخدم الأمر `!جيش اسم_جيش_جديد` لتكوين جيش جديد\n• ابدأ من جديد بـ 100 جندي\n• عُد أقوى من السابق!\n\n**Dev by CodeX team 💻**"
            )
            await ctx.send(embed=embed)
            return
        
        if raids < 1 or raids > 10:
            embed = embed_manager.error_embed("عدد غير صحيح", "يمكنك القيام بـ 1-10 غارات في المرة الواحدة")
            await ctx.send(embed=embed)
            return
        
        # Check cooldown
        cooldown_remaining = await game_logic.check_raid_cooldown(user_id)
        if cooldown_remaining > 0:
            embed = embed_manager.error_embed(
                "انتظر قليلاً! ⏰", 
                f"يمكنك القيام بغارة أخرى خلال {cooldown_remaining} ثانية"
            )
            await ctx.send(embed=embed)
            return
        
        # Execute raids
        total_coins_earned = 0
        total_soldiers_lost = 0
        raid_results = []
        
        for i in range(raids):
            if player['soldiers'] <= 0:
                break
                
            result = await game_logic.execute_raid(user_id)
            if result:
                total_coins_earned += result['coins_earned']
                total_soldiers_lost += result['soldiers_lost']
                raid_results.append(result)
                player['soldiers'] -= result['soldiers_lost']
        
        if raid_results:
            await game_logic.set_raid_cooldown(user_id)
            embed = embed_manager.raid_result_embed(
                raid_results, total_coins_earned, total_soldiers_lost, player['soldiers']
            )
            embed.set_footer(text="Dev by CodeX team 💻")
            await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in raid_prefix: {e}")
        embed = embed_manager.error_embed("خطأ في النظام", "حدث خطأ أثناء الغارة")
        await ctx.send(embed=embed)

@bot.command(name="متجر")
@require_authorized_channel()
async def shop_prefix(ctx):
    """Shop command with prefix"""
    try:
        user_id = ctx.author.id
        player = await db.get_player(user_id)
        
        if not player:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر !جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        embed, view = await shop_manager.create_shop_menu(player)
        embed.set_footer(text="Dev by CodeX team 💻")
        await ctx.send(embed=embed, view=view)
        
    except Exception as e:
        print(f"Error in shop_prefix: {e}")
        embed = embed_manager.error_embed("خطأ في النظام", "حدث خطأ في المتجر")
        await ctx.send(embed=embed)

@bot.command(name="حالة")
@require_authorized_channel()
async def status_prefix(ctx):
    """Status command with prefix"""
    try:
        user_id = ctx.author.id
        player = await db.get_player(user_id)
        
        if not player:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر !جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        embed = await embed_manager.player_status_embed(player, ctx.author)
        embed.set_footer(text="Dev by CodeX team 💻")
        await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in status_prefix: {e}")
        embed = embed_manager.error_embed("خطأ في النظام", "حدث خطأ في عرض الحالة")
        await ctx.send(embed=embed)

@bot.command(name="قصف", aliases=["صاروخ", "صواريخ", "missile"])
@require_authorized_channel()
async def missile_attack(ctx, target: discord.Member):
    """Missile attack command"""
    try:
        attacker_id = ctx.author.id
        target_id = target.id
        
        if attacker_id == target_id:
            embed = embed_manager.error_embed("خطأ!", "لا يمكنك قصف نفسك!")
            await ctx.send(embed=embed)
            return
        
        # Check if attacker exists
        attacker = await db.get_player(attacker_id)
        if not attacker:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر /جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        # Check if target exists
        target_player = await db.get_player(target_id)
        if not target_player:
            embed = embed_manager.error_embed("الهدف لا يملك جيش!", "لا يمكن قصف لاعب بدون جيش")
            await ctx.send(embed=embed)
            return
        
        # Check missile cooldown
        cooldown_remaining = await combat.check_missile_cooldown(attacker_id)
        if cooldown_remaining > 0:
            embed = embed_manager.error_embed(
                "انتظر قليلاً! ⏰",
                f"يمكنك إطلاق صاروخ آخر خلال {cooldown_remaining} ثانية"
            )
            await ctx.send(embed=embed)
            return
        
        # Get attacker's missiles  
        missiles = await db.get_player_missiles(attacker_id)
        if not missiles:
            embed = embed_manager.error_embed(
                "لا تملك صواريخ!",
                "اشتري صواريخ من المتجر أولاً باستخدام `!متجر`"
            )
            await ctx.send(embed=embed)
            return
        
        # Create missile selection menu
        embed, view = await combat.create_missile_menu(attacker, target_player, missiles, target)
        embed.set_footer(text="Dev by CodeX team 💻")
        await ctx.send(embed=embed, view=view)
        
    except Exception as e:
        print(f"Error in missile_attack: {e}")
        embed = embed_manager.error_embed("خطأ!", "حدث خطأ أثناء إعداد القصف الصاروخي")
        await ctx.send(embed=embed)

@bot.command(name="هجوم")
@require_authorized_channel()
async def attack_prefix(ctx, target: discord.Member):
    """Attack command with prefix"""
    try:
        attacker_id = ctx.author.id
        target_id = target.id
        
        if attacker_id == target_id:
            embed = embed_manager.error_embed("خطأ", "لا يمكنك مهاجمة نفسك!")
            await ctx.send(embed=embed)
            return
        
        attacker = await db.get_player(attacker_id)
        target_player = await db.get_player(target_id)
        
        if not attacker:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر !جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        if not target_player:
            embed = embed_manager.error_embed("الهدف لا يملك جيش", "الهدف لم ينشئ جيشه بعد")
            await ctx.send(embed=embed)
            return
        
        # Check if target has walls
        if target_player.get('walls', 0) > 0:
            embed = embed_manager.error_embed(
                "محمي بالأسوار! 🏰", 
                f"{target.display_name} محمي بـ {target_player['walls']} سور\nيجب تدمير الأسوار أولاً بالصواريخ"
            )
            await ctx.send(embed=embed)
            return
        
        # Check cooldown
        cooldown_remaining = await combat.check_attack_cooldown(attacker_id)
        if cooldown_remaining > 0:
            embed = embed_manager.error_embed(
                "انتظر قليلاً! ⏰", 
                f"يمكنك مهاجمة لاعب آخر خلال {cooldown_remaining} ثانية"
            )
            await ctx.send(embed=embed)
            return
        
        # Execute attack
        result = await combat.execute_attack(attacker_id, target_id)
        
        if result:
            embed = embed_manager.attack_result_embed(ctx.author, target, result)
            embed.set_footer(text="Dev by CodeX team 💻")
            await ctx.send(embed=embed)
            
            # Notify target
            try:
                notify_embed = embed_manager.attack_notification_embed(ctx.author, result)
                notify_embed.set_footer(text="Dev by CodeX team 💻")
                await target.send(embed=notify_embed)
            except:
                pass
        else:
            embed = embed_manager.error_embed("فشل الهجوم", "حاول مرة أخرى")
            await ctx.send(embed=embed)
            
    except Exception as e:
        print(f"Error in attack_prefix: {e}")
        embed = embed_manager.error_embed("خطأ في النظام", "حدث خطأ أثناء الهجوم")
        await ctx.send(embed=embed)

# WAR GAMES
@bot.command(name="مبارزة")
@require_authorized_channel()
async def duel_game(ctx, choice=None):
    """Military duel game"""
    try:
        if not choice:
            embed = discord.Embed(
                title="⚔️ مبارزة عسكرية",
                description="استخدم: `!مبارزة [سيف/رمح/درع]`\n\n🗡️ **السيف** يهزم الرمح\n🛡️ **الدرع** يصد السيف\n🏹 **الرمح** يخترق الدرع",
                color=0xff4500
            )
            embed.set_footer(text="Dev by CodeX team 💻")
            await ctx.send(embed=embed)
            return
        
        choices = ['سيف', 'رمح', 'درع']
        user_choice = choice.lower()
        bot_choice = random.choice(choices)
        
        # Normalize input
        if user_choice in ['سيف', 'sword']:
            user_choice = 'سيف'
            user_emoji = "🗡️"
        elif user_choice in ['رمح', 'spear']:
            user_choice = 'رمح'
            user_emoji = "🏹"
        elif user_choice in ['درع', 'shield']:
            user_choice = 'درع'
            user_emoji = "🛡️"
        else:
            embed = discord.Embed(
                title="❌ سلاح غير صحيح",
                description="استخدم: سيف، رمح، أو درع",
                color=0xff0000
            )
            await ctx.send(embed=embed)
            return
        
        bot_emojis = {'سيف': '🗡️', 'رمح': '🏹', 'درع': '🛡️'}
        bot_emoji = bot_emojis[bot_choice]
        
        # Determine winner
        if user_choice == bot_choice:
            result = "تعادل في المبارزة! ⚔️"
            color = 0xffa500
            coins = 5
        elif (user_choice == 'سيف' and bot_choice == 'رمح') or \
             (user_choice == 'درع' and bot_choice == 'سيف') or \
             (user_choice == 'رمح' and bot_choice == 'درع'):
            result = "انتصرت في المبارزة! 🏆"
            color = 0x00ff00
            coins = 15
        else:
            result = "هُزمت في المبارزة! 💀"
            color = 0xff0000
            coins = 0
        
        # Give coins if player has army
        player = await db.get_player(ctx.author.id)
        if player and coins > 0:
            await db.add_coins(ctx.author.id, coins)
            result += f" (+{coins} عملة)"
        
        embed = discord.Embed(
            title="⚔️ مبارزة عسكرية",
            description=f"**أنت:** {user_emoji} {user_choice}\n**العدو:** {bot_emoji} {bot_choice}\n\n{result}",
            color=color
        )
        embed.set_footer(text="Dev by CodeX team 💻")
        await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in duel_game: {e}")

@bot.command(name="استطلاع")
@require_authorized_channel()
async def recon_mission(ctx):
    """Military reconnaissance mission"""
    try:
        # Random reconnaissance outcomes
        recon_results = [
            {"name": "دورية استطلاع", "soldiers": random.randint(5, 15), "coins": random.randint(20, 40)},
            {"name": "مراقبة العدو", "soldiers": random.randint(10, 25), "coins": random.randint(30, 60)},
            {"name": "استطلاع المنطقة", "soldiers": random.randint(3, 12), "coins": random.randint(15, 35)},
            {"name": "مهمة تجسس", "soldiers": random.randint(20, 40), "coins": random.randint(50, 100)}
        ]
        
        mission = random.choice(recon_results)
        success = random.choice([True, False])
        
        player = await db.get_player(ctx.author.id)
        if not player:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر !جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        embed = discord.Embed(
            title=f"🔍 {mission['name']}",
            color=0x8B4513
        )
        
        if success:
            embed.description = f"**نجحت المهمة!** 🎖️\n\nحصلت على معلومات استخباراتية قيمة"
            embed.color = 0x00ff00
            embed.add_field(name="💰 مكافأة المهمة", value=f"+{mission['coins']} عملة", inline=True)
            embed.add_field(name="🪖 جنود مدربون", value=f"+{mission['soldiers']} جندي", inline=True)
            
            await db.add_coins(ctx.author.id, mission['coins'])
            await db.update_player(ctx.author.id, soldiers=player['soldiers'] + mission['soldiers'])
        else:
            losses = random.randint(1, 5)
            embed.description = f"**فشلت المهمة!** 💀\n\nتم اكتشاف دوريتك من قبل العدو"
            embed.color = 0xff0000
            embed.add_field(name="💀 خسائر", value=f"-{losses} جندي", inline=True)
            
            new_soldiers = max(0, player['soldiers'] - losses)
            await db.update_player(ctx.author.id, soldiers=new_soldiers)
        
        embed.set_footer(text="Dev by CodeX team 💻")
        await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in recon_mission: {e}")

@bot.command(name="قنص")
@require_authorized_channel()
async def sniper_mission(ctx):
    """Sniper training mission"""
    try:
        player = await db.get_player(ctx.author.id)
        if not player:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر !جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        # Sniper accuracy test
        hit_chance = random.random()
        target_distance = random.randint(200, 800)
        
        embed = discord.Embed(
            title="🎯 مهمة قنص",
            description=f"**المسافة للهدف:** {target_distance} متر",
            color=0x556B2F
        )
        
        if hit_chance > 0.4:  # 60% success rate
            headshot = hit_chance > 0.85  # 15% chance for headshot
            if headshot:
                embed.add_field(name="🎯 إصابة في الرأس!", value="قنص دقيق ومميت!", inline=False)
                embed.color = 0xFFD700
                coins = 30
                soldiers = 3
            else:
                embed.add_field(name="✅ إصابة ناجحة", value="أصبت الهدف بنجاح", inline=False)
                embed.color = 0x00FF00
                coins = 15
                soldiers = 1
            
            await db.add_coins(ctx.author.id, coins)
            await db.update_player(ctx.author.id, soldiers=player['soldiers'] + soldiers)
            embed.add_field(name="💰 مكافأة", value=f"+{coins} عملة", inline=True)
            embed.add_field(name="🪖 جنود مدربون", value=f"+{soldiers} قناص", inline=True)
        else:
            embed.add_field(name="❌ أخطأت الهدف", value="تحتاج للمزيد من التدريب", inline=False)
            embed.color = 0xFF0000
            embed.add_field(name="💡 نصيحة", value="كرر التدريب لتحسين دقتك", inline=False)
        
        embed.set_footer(text="Dev by CodeX team 💻")
        await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in sniper_mission: {e}")

@bot.command(name="تفكيك")
@require_authorized_channel()
async def bomb_defuse(ctx, wire_color=None):
    """Bomb defusing training game"""
    try:
        if wire_color is None:
            embed = discord.Embed(
                title="💣 تفكيك القنبلة",
                description="اختر السلك المناسب لتفكيك القنبلة!\nاستخدم: `!تفكيك [أحمر/أزرق/أخضر/أصفر]`",
                color=0xff6600
            )
            embed.add_field(name="⏰ تحذير!", value="لديك محاولة واحدة فقط!", inline=False)
            embed.set_footer(text="Dev by CodeX team 💻")
            await ctx.send(embed=embed)
            return
        
        player = await db.get_player(ctx.author.id)
        if not player:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر !جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        wire_colors = ['أحمر', 'أزرق', 'أخضر', 'أصفر']
        correct_wire = random.choice(wire_colors)
        user_choice = wire_color.lower()
        
        # Normalize input
        wire_map = {
            'أحمر': 'أحمر', 'احمر': 'أحمر', 'red': 'أحمر',
            'أزرق': 'أزرق', 'ازرق': 'أزرق', 'blue': 'أزرق',
            'أخضر': 'أخضر', 'اخضر': 'أخضر', 'green': 'أخضر',
            'أصفر': 'أصفر', 'اصفر': 'أصفر', 'yellow': 'أصفر'
        }
        
        if user_choice not in wire_map:
            embed = discord.Embed(
                title="❌ لون غير صحيح",
                description="استخدم: أحمر، أزرق، أخضر، أو أصفر",
                color=0xff0000
            )
            await ctx.send(embed=embed)
            return
        
        chosen_wire = wire_map[user_choice]
        
        if chosen_wire == correct_wire:
            embed = discord.Embed(
                title="✅ تم تفكيك القنبلة!",
                description=f"أحسنت! السلك **{correct_wire}** كان الاختيار الصحيح",
                color=0x00ff00
            )
            coins = 50
            soldiers = 5
            await db.add_coins(ctx.author.id, coins)
            await db.update_player(ctx.author.id, soldiers=player['soldiers'] + soldiers)
            embed.add_field(name="💰 مكافأة البطولة", value=f"+{coins} عملة", inline=True)
            embed.add_field(name="🪖 خبراء متفجرات", value=f"+{soldiers} جندي", inline=True)
        else:
            embed = discord.Embed(
                title="💥 انفجرت القنبلة!",
                description=f"اخترت السلك **{chosen_wire}** لكن الصحيح كان **{correct_wire}**",
                color=0xff0000
            )
            losses = random.randint(2, 8)
            new_soldiers = max(0, player['soldiers'] - losses)
            await db.update_player(ctx.author.id, soldiers=new_soldiers)
            embed.add_field(name="💀 ضحايا الانفجار", value=f"-{losses} جندي", inline=False)
        
        embed.set_footer(text="Dev by CodeX team 💻")
        await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in bomb_defuse: {e}")

@bot.command(name="اقتحام")
@require_authorized_channel()
async def base_assault(ctx):
    """Military base assault mission"""
    try:
        player = await db.get_player(ctx.author.id)
        if not player:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر !جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        if player['coins'] < 100:
            embed = embed_manager.error_embed("موارد غير كافية!", "تحتاج 100 عملة لتجهيز مهمة اقتحام")
            await ctx.send(embed=embed)
            return
        
        if player['soldiers'] < 20:
            embed = embed_manager.error_embed("جنود غير كافيين!", "تحتاج على الأقل 20 جندي لمهمة الاقتحام")
            await ctx.send(embed=embed)
            return
        
        # Deduct mission cost
        await db.spend_coins(ctx.author.id, 100)
        
        # Generate mission parameters
        base_types = [
            {"name": "مخبأ العدو", "difficulty": 3, "reward": 300, "soldiers": 15},
            {"name": "نقطة تفتيش", "difficulty": 2, "reward": 200, "soldiers": 10},
            {"name": "مستودع أسلحة", "difficulty": 4, "reward": 500, "soldiers": 25},
            {"name": "معسكر تدريب", "difficulty": 1, "reward": 150, "soldiers": 8}
        ]
        
        target_base = random.choice(base_types)
        success_chance = max(0.3, 1.0 - (target_base['difficulty'] * 0.15))
        mission_success = random.random() < success_chance
        
        embed = discord.Embed(
            title=f"🏴‍☠️ اقتحام {target_base['name']}",
            color=0x8B0000
        )
        
        if mission_success:
            embed.description = f"**نجح الاقتحام!** 🎖️\n\nتم الاستيلاء على الهدف بنجاح"
            embed.color = 0x00ff00
            embed.add_field(name="💰 غنائم الحرب", value=f"+{target_base['reward']} عملة", inline=True)
            embed.add_field(name="🪖 أسرى محررون", value=f"+{target_base['soldiers']} جندي", inline=True)
            embed.add_field(name="⭐ تقييم المهمة", value="ممتاز", inline=True)
            
            await db.add_coins(ctx.author.id, target_base['reward'])
            await db.update_player(ctx.author.id, soldiers=player['soldiers'] + target_base['soldiers'])
        else:
            losses = random.randint(5, 15)
            embed.description = f"**فشل الاقتحام!** 💀\n\nواجهت مقاومة شديدة من العدو"
            embed.color = 0xff0000
            embed.add_field(name="💀 خسائر المعركة", value=f"-{losses} جندي", inline=True)
            embed.add_field(name="📊 حالة المهمة", value="فاشلة", inline=True)
            
            new_soldiers = max(0, player['soldiers'] - losses)
            await db.update_player(ctx.author.id, soldiers=new_soldiers)
            
            if new_soldiers == 0:
                await db.delete_player(ctx.author.id)
                embed.add_field(name="⚠️ تحذير", value="تم تدمير جيشك بالكامل!", inline=False)
        
        embed.add_field(name="🎯 صعوبة المهمة", value=f"{target_base['difficulty']}/5", inline=True)
        embed.set_footer(text="Dev by CodeX team 💻 | تكلفة المهمة: 100 عملة")
        await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in base_assault: {e}")

@bot.command(name="أوامر")
async def commands_list(ctx):
    """List all available commands"""
    try:
        embed = discord.Embed(
            title="📋 قائمة الأوامر العسكرية",
            description="جميع الأوامر والمهام المتاحة في البوت",
            color=0x0099ff
        )
        
        embed.add_field(
            name="⚔️ أوامر الحرب الأساسية",
            value="`!جيش [اسم]` - إنشاء جيش\n`!غارة [عدد]` - غارة على الوحوش\n`!هجوم [@لاعب]` - مهاجمة لاعب\n`!متجر` - فتح المتجر\n`!حالة` - عرض حالة الجيش",
            inline=False
        )
        
        embed.add_field(
            name="🎯 المهام العسكرية",
            value="`!مبارزة [سيف/رمح/درع]` - مبارزة عسكرية\n`!استطلاع` - مهمة استطلاع\n`!قنص` - تدريب القناصة\n`!تفكيك [لون]` - تفكيك القنابل\n`!اقتحام` - اقتحام قواعد العدو",
            inline=False
        )
        
        embed.add_field(
            name="☢️ العمليات النووية",
            value="`!تخصيب` - تخصيب اليورانيوم\n`!نووية` - صنع قنبلة نووية\n`!غزو [دولة]` - غزو الدول",
            inline=False
        )
        
        embed.add_field(
            name="🚁 القوات المسلحة",
            value="`!طيران [شراء/غارة/حالة]` - القوات الجوية\n`!بحرية [شراء/هجوم/حالة]` - القوات البحرية",
            inline=False
        )
        
        embed.add_field(
            name="🏭 البنية العسكرية",
            value="`!مصنع [سلاح]` - تصنيع الأسلحة\n`!قاعدة [بناء/ترقية/حالة]` - إدارة القواعد\n`!تجارة [شراء/بيع/سوق]` - تجارة الأسلحة",
            inline=False
        )
        
        embed.add_field(
            name="ℹ️ معلومات وأوامر إضافية",
            value="`!أوامر` - قائمة الأوامر\n`!بداية` - دليل المبتدئين\n`!شرح` - شرح البوت بالتفصيل\n`!أسلحة` - دليل الأسلحة الشامل\n`/المتصدرين` - قائمة أقوى الجيوش\n`/مساعدة` - المساعدة التفصيلية",
            inline=False
        )
        
        embed.add_field(
            name="💡 نصائح المهام",
            value="• المهام العسكرية تعطي مكافآت أكبر\n• بعض المهام تتطلب موارد للبدء\n• النجاح يعتمد على المهارة والحظ\n• الفشل قد يؤدي لخسارة جنود",
            inline=False
        )
        
        embed.set_footer(text="Dev by CodeX team 💻")
        await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in commands_list: {e}")

# ADVANCED MILITARY OPERATIONS
@bot.command(name="تخصيب")
@require_authorized_channel()
async def uranium_enrichment(ctx):
    """Uranium enrichment for nuclear program"""
    try:
        player = await db.get_player(ctx.author.id)
        if not player:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر !جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        if player['coins'] < 500:
            embed = embed_manager.error_embed("موارد غير كافية!", "تحتاج 500 عملة لبدء برنامج تخصيب اليورانيوم")
            await ctx.send(embed=embed)
            return
        
        if player.get('base_level', 0) < 2:
            embed = embed_manager.error_embed("قاعدة غير متطورة!", "تحتاج قاعدة مستوى 2 على الأقل للبرنامج النووي")
            await ctx.send(embed=embed)
            return
        
        # Deduct enrichment cost
        await db.spend_coins(ctx.author.id, 500)
        
        # Enrichment process
        enrichment_success = random.random() > 0.3  # 70% success rate
        
        embed = discord.Embed(
            title="☢️ برنامج تخصيب اليورانيوم",
            color=0x32CD32
        )
        
        if enrichment_success:
            uranium_amount = random.randint(5, 15)
            embed.description = f"**نجح التخصيب!** ⚛️\n\nتم إنتاج يورانيوم مخصب عالي الجودة"
            embed.color = 0x00ff00
            embed.add_field(name="☢️ اليورانيوم المنتج", value=f"{uranium_amount} كيلوجرام", inline=True)
            embed.add_field(name="🔬 درجة النقاء", value="90%+", inline=True)
            
            # Add uranium to inventory
            await db.add_item(ctx.author.id, 'nuclear', 'يورانيوم مخصب', uranium_amount)
        else:
            embed.description = f"**فشل التخصيب!** ⚠️\n\nحدث عطل في أجهزة الطرد المركزي"
            embed.color = 0xff6600
            embed.add_field(name="💰 خسارة مالية", value="تم فقدان 500 عملة", inline=True)
            embed.add_field(name="🔧 حالة المعدات", value="تحتاج صيانة", inline=True)
        
        embed.set_footer(text="Dev by CodeX team 💻 | برنامج نووي سري")
        await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in uranium_enrichment: {e}")

@bot.command(name="نووية")
@require_authorized_channel()
async def nuclear_bomb(ctx):
    """Create nuclear weapons"""
    try:
        player = await db.get_player(ctx.author.id)
        if not player:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر !جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        # Check uranium inventory
        inventory = await db.get_player_inventory(ctx.author.id)
        uranium = inventory.get('nuclear', {}).get('يورانيوم مخصب', 0)
        
        if uranium < 10:
            embed = embed_manager.error_embed("يورانيوم غير كافي!", f"تحتاج 10 كيلوجرام يورانيوم مخصب (لديك {uranium})")
            await ctx.send(embed=embed)
            return
        
        if player['coins'] < 2000:
            embed = embed_manager.error_embed("موارد غير كافية!", "تحتاج 2000 عملة لصنع قنبلة نووية")
            await ctx.send(embed=embed)
            return
        
        # Deduct resources
        await db.spend_coins(ctx.author.id, 2000)
        await db.use_item(ctx.author.id, 'nuclear', 'يورانيوم مخصب', 10)
        
        # Nuclear bomb creation
        bomb_types = [
            {"name": "قنبلة نووية تكتيكية", "power": 50, "description": "للأهداف العسكرية"},
            {"name": "قنبلة نووية استراتيجية", "power": 100, "description": "تدمير شامل"},
            {"name": "رأس نووي باليستي", "power": 150, "description": "صاروخ عابر للقارات"}
        ]
        
        bomb = random.choice(bomb_types)
        
        embed = discord.Embed(
            title="💥 صنع سلاح نووي",
            description=f"**تم تصنيع {bomb['name']} بنجاح!** ☢️",
            color=0xff4500
        )
        
        embed.add_field(name="⚛️ القوة التدميرية", value=f"{bomb['power']} كيلوطن", inline=True)
        embed.add_field(name="📝 الوصف", value=bomb['description'], inline=True)
        embed.add_field(name="🎯 حالة السلاح", value="جاهز للاستخدام", inline=True)
        
        # Add nuclear weapon to inventory
        await db.add_item(ctx.author.id, 'nuclear', bomb['name'], 1)
        
        embed.set_footer(text="Dev by CodeX team 💻 | سلاح دمار شامل")
        await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in nuclear_bomb: {e}")

@bot.command(name="غزو")
@require_authorized_channel()
async def invade_country(ctx, *, country_name=None):
    """Invade countries"""
    try:
        if not country_name:
            embed = discord.Embed(
                title="🌍 غزو الدول",
                description="استخدم: `!غزو [اسم الدولة]`\n\nالدول المتاحة للغزو:",
                color=0x8B0000
            )
            countries = ["سوريا", "العراق", "لبنان", "الأردن", "فلسطين", "اليمن", "ليبيا", "تونس", "الجزائر", "المغرب"]
            embed.add_field(name="🎯 أهداف متاحة", value=" | ".join(countries), inline=False)
            embed.set_footer(text="Dev by CodeX team 💻")
            await ctx.send(embed=embed)
            return
        
        player = await db.get_player(ctx.author.id)
        if not player:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر !جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        if player['soldiers'] < 1000:
            embed = embed_manager.error_embed("جيش صغير!", "تحتاج على الأقل 1000 جندي لغزو دولة")
            await ctx.send(embed=embed)
            return
        
        if player['coins'] < 1000:
            embed = embed_manager.error_embed("موارد غير كافية!", "تحتاج 1000 عملة لتمويل الغزو")
            await ctx.send(embed=embed)
            return
        
        # Country data
        countries = {
            "سوريا": {"difficulty": 4, "resources": 3000, "soldiers": 500},
            "العراق": {"difficulty": 5, "resources": 4000, "soldiers": 700},
            "لبنان": {"difficulty": 2, "resources": 1500, "soldiers": 200},
            "الأردن": {"difficulty": 3, "resources": 2000, "soldiers": 300},
            "فلسطين": {"difficulty": 3, "resources": 2500, "soldiers": 400},
            "اليمن": {"difficulty": 4, "resources": 2000, "soldiers": 300},
            "ليبيا": {"difficulty": 3, "resources": 3500, "soldiers": 600},
            "تونس": {"difficulty": 2, "resources": 1800, "soldiers": 250},
            "الجزائر": {"difficulty": 4, "resources": 3000, "soldiers": 500},
            "المغرب": {"difficulty": 3, "resources": 2200, "soldiers": 350}
        }
        
        target_country = countries.get(country_name.lower())
        if not target_country:
            embed = embed_manager.error_embed("دولة غير موجودة!", "اختر دولة من القائمة المتاحة")
            await ctx.send(embed=embed)
            return
        
        # Deduct invasion cost
        await db.spend_coins(ctx.author.id, 1000)
        
        # Calculate success chance
        success_chance = min(0.8, player['soldiers'] / (target_country['difficulty'] * 500))
        invasion_success = random.random() < success_chance
        
        embed = discord.Embed(
            title=f"🏴‍☠️ غزو {country_name}",
            color=0x8B0000
        )
        
        if invasion_success:
            losses = random.randint(100, 300)
            embed.description = f"**نجح الغزو!** 🎖️\n\nتم الاستيلاء على {country_name} بنجاح"
            embed.color = 0x00ff00
            embed.add_field(name="💰 موارد مصادرة", value=f"+{target_country['resources']} عملة", inline=True)
            embed.add_field(name="🪖 جنود محررون", value=f"+{target_country['soldiers']} جندي", inline=True)
            embed.add_field(name="💀 خسائرنا", value=f"-{losses} جندي", inline=True)
            
            await db.add_coins(ctx.author.id, target_country['resources'])
            new_soldiers = max(0, player['soldiers'] - losses + target_country['soldiers'])
            await db.update_player(ctx.author.id, soldiers=new_soldiers)
        else:
            losses = random.randint(200, 500)
            embed.description = f"**فشل الغزو!** 💀\n\nواجهت مقاومة شديدة من {country_name}"
            embed.color = 0xff0000
            embed.add_field(name="💀 خسائر فادحة", value=f"-{losses} جندي", inline=True)
            embed.add_field(name="📊 حالة الغزو", value="انسحاب تكتيكي", inline=True)
            
            new_soldiers = max(0, player['soldiers'] - losses)
            await db.update_player(ctx.author.id, soldiers=new_soldiers)
            
            if new_soldiers == 0:
                await db.delete_player(ctx.author.id)
                embed.add_field(name="⚠️ تحذير", value="تم تدمير جيشك بالكامل!", inline=False)
        
        embed.set_footer(text="Dev by CodeX team 💻 | عملية عسكرية")
        await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in invade_country: {e}")

@bot.command(name="طيران")
@require_authorized_channel()
async def air_force(ctx, action=None):
    """Manage air force"""
    try:
        if not action:
            embed = discord.Embed(
                title="✈️ القوات الجوية",
                description="إدارة أسطولك الجوي\n\nاستخدم: `!طيران [شراء/غارة/حالة]`",
                color=0x87CEEB
            )
            embed.add_field(name="🛒 شراء", value="شراء طائرات جديدة", inline=True)
            embed.add_field(name="💥 غارة", value="تنفيذ غارة جوية", inline=True)
            embed.add_field(name="📊 حالة", value="عرض الأسطول الجوي", inline=True)
            embed.set_footer(text="Dev by CodeX team 💻")
            await ctx.send(embed=embed)
            return
        
        player = await db.get_player(ctx.author.id)
        if not player:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر !جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        if action.lower() == "شراء":
            if player['coins'] < 800:
                embed = embed_manager.error_embed("موارد غير كافية!", "تحتاج 800 عملة لشراء طائرة")
                await ctx.send(embed=embed)
                return
            
            aircraft_types = [
                {"name": "مقاتلة F-16", "cost": 800, "power": 50},
                {"name": "مقاتلة ميج-29", "cost": 1000, "power": 60},
                {"name": "قاذفة قنابل", "cost": 1200, "power": 80},
                {"name": "طائرة استطلاع", "cost": 600, "power": 30}
            ]
            
            aircraft = random.choice(aircraft_types)
            await db.spend_coins(ctx.author.id, aircraft['cost'])
            await db.add_item(ctx.author.id, 'aircraft', aircraft['name'], 1)
            
            # Get updated player data
            updated_player = await db.get_player(ctx.author.id)
            remaining_coins = updated_player['coins'] if updated_player else 0
            
            embed = discord.Embed(
                title="✈️ شراء طائرة",
                description=f"تم شراء **{aircraft['name']}** بنجاح!",
                color=0x00ff00
            )
            embed.add_field(name="💰 التكلفة", value=f"{aircraft['cost']} عملة", inline=True)
            embed.add_field(name="⚡ القوة القتالية", value=f"{aircraft['power']}", inline=True)
            embed.add_field(name="💰 رصيدك الحالي", value=f"{remaining_coins} عملة", inline=False)
            
        elif action.lower() == "غارة":
            inventory = await db.get_player_inventory(ctx.author.id)
            aircraft = inventory.get('aircraft', {})
            
            if not aircraft:
                embed = embed_manager.error_embed("لا توجد طائرات!", "اشتر طائرات أولاً باستخدام !طيران شراء")
                await ctx.send(embed=embed)
                return
            
            # Air raid execution
            total_power = sum(aircraft.values()) * 20
            raid_success = random.random() > 0.4
            
            if raid_success:
                coins_earned = random.randint(200, 500)
                embed = discord.Embed(
                    title="💥 غارة جوية ناجحة",
                    description="تم تدمير أهداف العدو بنجاح!",
                    color=0x00ff00
                )
                embed.add_field(name="💰 غنائم", value=f"+{coins_earned} عملة", inline=True)
                await db.add_coins(ctx.author.id, coins_earned)
            else:
                # Lose some aircraft
                lost_aircraft = random.choice(list(aircraft.keys()))
                embed = discord.Embed(
                    title="💥 فشلت الغارة",
                    description="تم إسقاط إحدى طائراتك!",
                    color=0xff0000
                )
                embed.add_field(name="💀 خسائر", value=f"فقدت {lost_aircraft}", inline=True)
                await db.use_item(ctx.author.id, 'aircraft', lost_aircraft, 1)
        
        elif action.lower() == "حالة":
            inventory = await db.get_player_inventory(ctx.author.id)
            aircraft = inventory.get('aircraft', {})
            
            embed = discord.Embed(
                title="✈️ الأسطول الجوي",
                description="حالة قواتك الجوية",
                color=0x87CEEB
            )
            
            if aircraft:
                for plane, count in aircraft.items():
                    embed.add_field(name=f"✈️ {plane}", value=f"العدد: {count}", inline=True)
                total_aircraft = sum(aircraft.values())
                embed.add_field(name="📊 إجمالي الطائرات", value=f"{total_aircraft} طائرة", inline=False)
            else:
                embed.add_field(name="📭 فارغ", value="لا توجد طائرات", inline=False)
            
            embed.set_footer(text="Dev by CodeX team 💻")
            await ctx.send(embed=embed)
        else:
            embed = embed_manager.error_embed("أمر غير صحيح!", "استخدم: شراء، غارة، أو حالة")
            await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in air_force: {e}")

@bot.command(name="بحرية")
@require_authorized_channel()
async def navy(ctx, action=None):
    """Manage naval forces"""
    try:
        if not action:
            embed = discord.Embed(
                title="🚢 القوات البحرية",
                description="إدارة أسطولك البحري\n\nاستخدم: `!بحرية [شراء/هجوم/حالة]`",
                color=0x006994
            )
            embed.add_field(name="🛒 شراء", value="بناء سفن حربية", inline=True)
            embed.add_field(name="⚓ هجوم", value="هجوم بحري", inline=True)
            embed.add_field(name="📊 حالة", value="عرض الأسطول البحري", inline=True)
            embed.set_footer(text="Dev by CodeX team 💻")
            await ctx.send(embed=embed)
            return
        
        player = await db.get_player(ctx.author.id)
        if not player:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر !جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        if action.lower() == "شراء":
            if player['coins'] < 1500:
                embed = embed_manager.error_embed("موارد غير كافية!", "تحتاج 1500 عملة لبناء سفينة حربية")
                await ctx.send(embed=embed)
                return
            
            ship_types = [
                {"name": "مدمرة", "cost": 1500, "power": 70, "crew": 50},
                {"name": "فرقاطة", "cost": 2000, "power": 90, "crew": 80},
                {"name": "غواصة هجومية", "cost": 2500, "power": 120, "crew": 30},
                {"name": "حاملة طائرات", "cost": 5000, "power": 200, "crew": 200}
            ]
            
            affordable_ships = [ship for ship in ship_types if ship['cost'] <= player['coins']]
            if not affordable_ships:
                embed = embed_manager.error_embed("موارد غير كافية!", "لا تستطيع شراء أي سفينة")
                await ctx.send(embed=embed)
                return
            
            ship = random.choice(affordable_ships)
            await db.spend_coins(ctx.author.id, ship['cost'])
            await db.add_item(ctx.author.id, 'navy', ship['name'], 1)
            
            # Get updated player data
            updated_player = await db.get_player(ctx.author.id)
            remaining_coins = updated_player['coins'] if updated_player else 0
            
            embed = discord.Embed(
                title="⚓ بناء سفينة حربية",
                description=f"تم بناء **{ship['name']}** بنجاح!",
                color=0x00ff00
            )
            embed.add_field(name="💰 التكلفة", value=f"{ship['cost']} عملة", inline=True)
            embed.add_field(name="⚡ القوة البحرية", value=f"{ship['power']}", inline=True)
            embed.add_field(name="👥 الطاقم", value=f"{ship['crew']} بحار", inline=True)
            embed.add_field(name="💰 رصيدك الحالي", value=f"{remaining_coins} عملة", inline=False)
            
        elif action.lower() == "هجوم":
            inventory = await db.get_player_inventory(ctx.author.id)
            ships = inventory.get('navy', {})
            
            if not ships:
                embed = embed_manager.error_embed("لا توجد سفن!", "ابن سفن حربية أولاً باستخدام !بحرية شراء")
                await ctx.send(embed=embed)
                return
            
            # Naval attack
            fleet_power = sum(ships.values()) * 30
            attack_success = random.random() > 0.3
            
            if attack_success:
                coins_earned = random.randint(300, 800)
                soldiers_captured = random.randint(20, 60)
                embed = discord.Embed(
                    title="⚓ هجوم بحري ناجح",
                    description="تم تدمير أهداف العدو الساحلية!",
                    color=0x00ff00
                )
                embed.add_field(name="💰 غنائم", value=f"+{coins_earned} عملة", inline=True)
                embed.add_field(name="🪖 أسرى", value=f"+{soldiers_captured} جندي", inline=True)
                await db.add_coins(ctx.author.id, coins_earned)
                await db.update_player(ctx.author.id, soldiers=player['soldiers'] + soldiers_captured)
            else:
                lost_ship = random.choice(list(ships.keys()))
                embed = discord.Embed(
                    title="💥 فشل الهجوم البحري",
                    description="تم إغراق إحدى سفنك!",
                    color=0xff0000
                )
                embed.add_field(name="💀 خسائر", value=f"فقدت {lost_ship}", inline=True)
                await db.use_item(ctx.author.id, 'navy', lost_ship, 1)
        
        elif action.lower() == "حالة":
            inventory = await db.get_player_inventory(ctx.author.id)
            ships = inventory.get('navy', {})
            
            embed = discord.Embed(
                title="🚢 الأسطول البحري",
                description="حالة قواتك البحرية",
                color=0x006994
            )
            
            if ships:
                for ship, count in ships.items():
                    embed.add_field(name=f"⚓ {ship}", value=f"العدد: {count}", inline=True)
                total_ships = sum(ships.values())
                embed.add_field(name="📊 إجمالي السفن", value=f"{total_ships} سفينة", inline=False)
            else:
                embed.add_field(name="📭 فارغ", value="لا توجد سفن حربية", inline=False)
            
            embed.set_footer(text="Dev by CodeX team 💻")
            await ctx.send(embed=embed)
        else:
            embed = embed_manager.error_embed("أمر غير صحيح!", "استخدم: شراء، هجوم، أو حالة")
            await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in navy: {e}")

@bot.command(name="مصنع")
@require_authorized_channel()
async def weapons_factory(ctx, weapon_type=None):
    """Advanced weapons manufacturing"""
    try:
        if not weapon_type:
            embed = discord.Embed(
                title="🏭 مصنع الأسلحة",
                description="تصنيع أسلحة متقدمة\n\nاستخدم: `!مصنع [نوع السلاح]`",
                color=0x8B4513
            )
            embed.add_field(name="🔫 أسلحة متاحة", value="`دبابة` | `طائرة` | `صاروخ` | `مدفع` | `لغم`", inline=False)
            embed.set_footer(text="Dev by CodeX team 💻")
            await ctx.send(embed=embed)
            return
        
        player = await db.get_player(ctx.author.id)
        if not player:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر !جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        weapon_configs = {
            "دبابة": {"cost": 1200, "materials": 100, "power": 80, "description": "دبابة قتال رئيسية"},
            "طائرة": {"cost": 1800, "materials": 150, "power": 120, "description": "طائرة مقاتلة متقدمة"},
            "صاروخ": {"cost": 800, "materials": 80, "power": 60, "description": "صاروخ موجه دقيق"},
            "مدفع": {"cost": 600, "materials": 60, "power": 45, "description": "مدفعية ثقيلة"},
            "لغم": {"cost": 200, "materials": 20, "power": 30, "description": "ألغام مضادة للأفراد"}
        }
        
        weapon = weapon_configs.get(weapon_type.lower())
        if not weapon:
            embed = embed_manager.error_embed("سلاح غير متاح!", "اختر من الأسلحة المتاحة")
            await ctx.send(embed=embed)
            return
        
        if player['coins'] < weapon['cost']:
            embed = embed_manager.error_embed("موارد غير كافية!", f"تحتاج {weapon['cost']} عملة")
            await ctx.send(embed=embed)
            return
        
        # Check materials
        inventory = await db.get_player_inventory(ctx.author.id)
        materials = inventory.get('materials', {}).get('معادن', 0)
        
        if materials < weapon['materials']:
            embed = embed_manager.error_embed("مواد خام غير كافية!", f"تحتاج {weapon['materials']} معدن (لديك {materials})")
            await ctx.send(embed=embed)
            return
        
        # Manufacturing process
        manufacturing_success = random.random() > 0.2  # 80% success rate
        
        await db.spend_coins(ctx.author.id, weapon['cost'])
        await db.use_item(ctx.author.id, 'materials', 'معادن', weapon['materials'])
        
        embed = discord.Embed(
            title="🏭 تصنيع الأسلحة",
            color=0x8B4513
        )
        
        if manufacturing_success:
            quantity = random.randint(1, 3)
            embed.description = f"**نجح التصنيع!** 🔧\n\nتم إنتاج {weapon_type} بجودة عالية"
            embed.color = 0x00ff00
            embed.add_field(name="🔫 السلاح المنتج", value=f"{quantity}x {weapon_type}", inline=True)
            embed.add_field(name="⚡ القوة", value=f"{weapon['power']}", inline=True)
            embed.add_field(name="📝 الوصف", value=weapon['description'], inline=True)
            
            await db.add_item(ctx.author.id, 'weapons', weapon_type, quantity)
            
            # Get updated player data
            updated_player = await db.get_player(ctx.author.id)
            remaining_coins = updated_player['coins'] if updated_player else 0
            embed.add_field(name="💰 رصيدك الحالي", value=f"{remaining_coins} عملة", inline=False)
        else:
            embed.description = f"**فشل التصنيع!** ⚠️\n\nحدث عطل في خط الإنتاج"
            embed.color = 0xff6600
            embed.add_field(name="💰 خسارة", value=f"تم فقدان {weapon['cost']} عملة", inline=True)
            embed.add_field(name="🔧 المشكلة", value="عطل في الآلات", inline=True)
        
        embed.set_footer(text="Dev by CodeX team 💻 | مجمع صناعي عسكري")
        await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in weapons_factory: {e}")

@bot.command(name="قاعدة")
@require_authorized_channel()
async def military_base(ctx, action=None):
    """Advanced military base management"""
    try:
        if not action:
            embed = discord.Embed(
                title="🏗️ إدارة القواعد العسكرية",
                description="بناء وإدارة القواعد المتقدمة\n\nاستخدم: `!قاعدة [بناء/ترقية/حالة]`",
                color=0x696969
            )
            embed.add_field(name="🏗️ بناء", value="بناء منشآت جديدة", inline=True)
            embed.add_field(name="⬆️ ترقية", value="ترقية المنشآت الموجودة", inline=True)
            embed.add_field(name="📊 حالة", value="عرض حالة القواعد", inline=True)
            embed.set_footer(text="Dev by CodeX team 💻")
            await ctx.send(embed=embed)
            return
        
        player = await db.get_player(ctx.author.id)
        if not player:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر !جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        if action.lower() == "بناء":
            facilities = [
                {"name": "مطار عسكري", "cost": 3000, "type": "airfield"},
                {"name": "ميناء حربي", "cost": 3500, "type": "port"},
                {"name": "مصنع ذخيرة", "cost": 2500, "type": "ammunition"},
                {"name": "مركز قيادة", "cost": 4000, "type": "command"},
                {"name": "مستشفى عسكري", "cost": 2000, "type": "hospital"}
            ]
            
            affordable_facilities = [f for f in facilities if f['cost'] <= player['coins']]
            if not affordable_facilities:
                embed = embed_manager.error_embed("موارد غير كافية!", "لا تستطيع بناء أي منشأة")
                await ctx.send(embed=embed)
                return
            
            facility = random.choice(affordable_facilities)
            await db.spend_coins(ctx.author.id, facility['cost'])
            await db.add_item(ctx.author.id, 'facilities', facility['name'], 1)
            
            # Get updated player data
            updated_player = await db.get_player(ctx.author.id)
            remaining_coins = updated_player['coins'] if updated_player else 0
            
            embed = discord.Embed(
                title="🏗️ بناء منشأة عسكرية",
                description=f"تم بناء **{facility['name']}** بنجاح!",
                color=0x00ff00
            )
            embed.add_field(name="💰 التكلفة", value=f"{facility['cost']} عملة", inline=True)
            embed.add_field(name="🏗️ النوع", value=facility['type'], inline=True)
            embed.add_field(name="💰 رصيدك الحالي", value=f"{remaining_coins} عملة", inline=False)
            
        elif action.lower() == "ترقية":
            if player.get('base_level', 0) >= 5:
                embed = embed_manager.error_embed("مستوى أقصى!", "وصلت قاعدتك للمستوى الأقصى")
                await ctx.send(embed=embed)
                return
            
            upgrade_cost = (player.get('base_level', 0) + 1) * 1000
            if player['coins'] < upgrade_cost:
                embed = embed_manager.error_embed("موارد غير كافية!", f"تحتاج {upgrade_cost} عملة للترقية")
                await ctx.send(embed=embed)
                return
            
            await db.spend_coins(ctx.author.id, upgrade_cost)
            new_level = player.get('base_level', 0) + 1
            await db.update_player(ctx.author.id, base_level=new_level)
            
            # Get updated player data
            updated_player = await db.get_player(ctx.author.id)
            remaining_coins = updated_player['coins'] if updated_player else 0
            
            embed = discord.Embed(
                title="⬆️ ترقية القاعدة العسكرية",
                description=f"تم ترقية القاعدة إلى المستوى {new_level}!",
                color=0x00ff00
            )
            embed.add_field(name="💰 التكلفة", value=f"{upgrade_cost} عملة", inline=True)
            embed.add_field(name="📈 المستوى الجديد", value=f"{new_level}/5", inline=True)
            embed.add_field(name="💰 رصيدك الحالي", value=f"{remaining_coins} عملة", inline=False)
            
            # Level benefits
            benefits = {
                1: "فتح المزيد من الأسلحة",
                2: "إمكانية البرنامج النووي", 
                3: "قدرات هجومية متقدمة",
                4: "دفاعات قوية",
                5: "قوة عظمى عالمية"
            }
            embed.add_field(name="🎯 المزايا الجديدة", value=benefits.get(new_level, "مزايا خاصة"), inline=False)
            
        elif action.lower() == "حالة":
            embed = discord.Embed(
                title="🏗️ حالة القواعد العسكرية",
                description=f"**مستوى القاعدة:** {player.get('base_level', 0)}/5",
                color=0x696969
            )
            
            # Show facilities
            inventory = await db.get_player_inventory(ctx.author.id)
            facilities = inventory.get('facilities', {})
            
            if facilities:
                facilities_text = []
                for facility, count in facilities.items():
                    facilities_text.append(f"🏗️ {facility}: {count}")
                embed.add_field(name="المنشآت المبنية", value="\n".join(facilities_text), inline=False)
            else:
                embed.add_field(name="المنشآت المبنية", value="لا توجد منشآت إضافية", inline=False)
            
            # Base stats
            embed.add_field(name="🛡️ الدفاعات", value=f"أسوار: {player.get('walls', 0)}\nدفاع جوي: {player.get('air_defense', 0)}", inline=True)
            embed.add_field(name="🚀 الصواريخ", value=f"قواعد: {player.get('missile_base', 0)}", inline=True)
            
            embed.set_footer(text="Dev by CodeX team 💻")
            await ctx.send(embed=embed)
        else:
            embed = embed_manager.error_embed("أمر غير صحيح!", "استخدم: بناء، ترقية، أو حالة")
            await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in military_base: {e}")

@bot.command(name="تجارة")
@require_authorized_channel()
async def arms_trade(ctx, action=None):
    """Arms trading system"""
    try:
        if not action:
            embed = discord.Embed(
                title="💼 تجارة الأسلحة",
                description="تجارة الأسلحة والموارد\n\nاستخدم: `!تجارة [شراء/بيع/سوق]`",
                color=0x4B0082
            )
            embed.add_field(name="🛒 شراء", value="شراء موارد من السوق السوداء", inline=True)
            embed.add_field(name="💰 بيع", value="بيع الأسلحة الفائضة", inline=True)
            embed.add_field(name="📈 سوق", value="عرض أسعار السوق", inline=True)
            embed.set_footer(text="Dev by CodeX team 💻")
            await ctx.send(embed=embed)
            return
        
        player = await db.get_player(ctx.author.id)
        if not player:
            embed = embed_manager.error_embed("لا يوجد لديك جيش!", "استخدم أمر !جيش لإنشاء جيش")
            await ctx.send(embed=embed)
            return
        
        if action.lower() == "سوق":
            # Show market prices
            market_items = [
                {"name": "معادن خام", "buy_price": 50, "sell_price": 30},
                {"name": "وقود عسكري", "buy_price": 80, "sell_price": 60},
                {"name": "ذخيرة", "buy_price": 100, "sell_price": 70},
                {"name": "قطع غيار", "buy_price": 120, "sell_price": 90},
                {"name": "معلومات استخباراتية", "buy_price": 200, "sell_price": 150}
            ]
            
            embed = discord.Embed(
                title="📈 السوق السوداء",
                description="أسعار اليوم في السوق السوداء",
                color=0x4B0082
            )
            
            for item in market_items:
                embed.add_field(
                    name=f"💼 {item['name']}", 
                    value=f"شراء: {item['buy_price']}💰\nبيع: {item['sell_price']}💰", 
                    inline=True
                )
            
        elif action.lower() == "شراء":
            if player['coins'] < 200:
                embed = embed_manager.error_embed("موارد غير كافية!", "تحتاج على الأقل 200 عملة للتجارة")
                await ctx.send(embed=embed)
                return
            
            # Random trade deal
            deals = [
                {"item": "معادن خام", "quantity": 20, "price": 200},
                {"item": "وقود عسكري", "quantity": 15, "price": 300},
                {"item": "ذخيرة متقدمة", "quantity": 10, "price": 400},
                {"item": "تقنية عسكرية", "quantity": 5, "price": 500}
            ]
            
            affordable_deals = [d for d in deals if d['price'] <= player['coins']]
            if not affordable_deals:
                embed = embed_manager.error_embed("لا توجد صفقات متاحة!", "تحتاج المزيد من العملات")
                await ctx.send(embed=embed)
                return
            
            deal = random.choice(affordable_deals)
            await db.spend_coins(ctx.author.id, deal['price'])
            await db.add_item(ctx.author.id, 'materials', deal['item'], deal['quantity'])
            
            # Get updated player data
            updated_player = await db.get_player(ctx.author.id)
            remaining_coins = updated_player['coins'] if updated_player else 0
            
            embed = discord.Embed(
                title="💼 صفقة ناجحة",
                description=f"تم شراء **{deal['quantity']}x {deal['item']}** من السوق السوداء",
                color=0x00ff00
            )
            embed.add_field(name="💰 السعر", value=f"{deal['price']} عملة", inline=True)
            embed.add_field(name="📦 الكمية", value=f"{deal['quantity']}", inline=True)
            embed.add_field(name="💰 رصيدك الحالي", value=f"{remaining_coins} عملة", inline=False)
            
        elif action.lower() == "بيع":
            inventory = await db.get_player_inventory(ctx.author.id)
            weapons = inventory.get('weapons', {})
            
            if not weapons:
                embed = embed_manager.error_embed("لا توجد أسلحة للبيع!", "تحتاج أسلحة لبيعها")
                await ctx.send(embed=embed)
                return
            
            # Sell random weapon
            weapon_name = random.choice(list(weapons.keys()))
            sell_price = random.randint(200, 600)
            
            await db.use_item(ctx.author.id, 'weapons', weapon_name, 1)
            await db.add_coins(ctx.author.id, sell_price)
            
            # Get updated player data
            updated_player = await db.get_player(ctx.author.id)
            remaining_coins = updated_player['coins'] if updated_player else 0
            
            embed = discord.Embed(
                title="💰 بيع ناجح",
                description=f"تم بيع **{weapon_name}** في السوق السوداء",
                color=0x00ff00
            )
            embed.add_field(name="💰 السعر", value=f"{sell_price} عملة", inline=True)
            embed.add_field(name="🔫 السلاح", value=weapon_name, inline=True)
            embed.add_field(name="💰 رصيدك الحالي", value=f"{remaining_coins} عملة", inline=False)
            embed.set_footer(text="Dev by CodeX team 💻 | السوق السوداء")
            await ctx.send(embed=embed)
        else:
            embed = embed_manager.error_embed("أمر غير صحيح!", "استخدم: شراء، بيع، أو سوق")
            await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in arms_trade: {e}")

class GameGuideView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)
        self.current_page = "main"
    
    def get_main_embed(self):
        embed = discord.Embed(
            title="🎖️ دليل اللعبة الشامل",
            description="مرحباً بك في أقوى بوت حرب عسكرية على Discord!\n\n**تم تطويره بواسطة فريق CodeX 💻**\n\nاختر القسم الذي تريد معرفة المزيد عنه:",
            color=0x8B0000
        )
        embed.add_field(
            name="🚀 البداية السريعة",
            value="تعلم كيفية بدء اللعب والأوامر الأساسية",
            inline=False
        )
        embed.add_field(
            name="⚔️ أنظمة القتال",
            value="الغارات، الهجمات، والصواريخ النووية",
            inline=False
        )
        embed.add_field(
            name="🛒 المتجر والاقتصاد",
            value="كيفية شراء الجنود والأسلحة وإدارة العملات",
            inline=False
        )
        embed.add_field(
            name="🏭 الأنظمة المتقدمة",
            value="القوات الجوية، البحرية، والبرنامج النووي",
            inline=False
        )
        embed.add_field(
            name="🎯 المهام والألعاب",
            value="المهام العسكرية وألعاب التحدي",
            inline=False
        )
        embed.add_field(
            name="📊 النصائح والاستراتيجيات",
            value="نصائح متقدمة لتطوير جيشك",
            inline=False
        )
        return embed
    
    def get_quick_start_embed(self):
        embed = discord.Embed(
            title="🚀 البداية السريعة",
            description="كيفية بدء اللعب والأوامر الأساسية",
            color=0x00ff00
        )
        embed.add_field(
            name="1️⃣ إنشاء الجيش",
            value="`/البدء اسم_الجيش` أو `!جيش اسم_الجيش`\nتبدأ بـ 100 جندي و 0 عملة",
            inline=False
        )
        embed.add_field(
            name="2️⃣ جمع العملات",
            value="`/غارة 5` أو `!غارة 5`\nاهجم على الوحوش لكسب العملات (كل 5 دقائق)",
            inline=False
        )
        embed.add_field(
            name="3️⃣ الشراء من المتجر",
            value="`/متجر` أو `!متجر`\nاشتر جنود وأسلحة ودفاعات",
            inline=False
        )
        embed.add_field(
            name="4️⃣ مراقبة التقدم",
            value="`/حالة` أو `!حالة`\nتابع إحصائياتك ورتبتك العسكرية",
            inline=False
        )
        embed.add_field(
            name="5️⃣ القتال",
            value="`/هجوم @لاعب` أو `!هجوم @لاعب`\nهاجم لاعبين آخرين (كل 10 دقائق)",
            inline=False
        )
        embed.set_footer(text="استخدم الأزرار للانتقال بين الأقسام | Dev by CodeX team 💻")
        return embed
    
    def get_combat_embed(self):
        embed = discord.Embed(
            title="⚔️ أنظمة القتال",
            description="كل ما تحتاج معرفته عن القتال والهجمات",
            color=0xff4500
        )
        embed.add_field(
            name="🐺 غارات الوحوش",
            value="`/غارة [1-10]` - كل 5 دقائق\n• ذئب بري (30-80 عملة)\n• دب شرس (60-120 عملة)\n• تنين صغير (100-200 عملة)\n• عملاق الجبل (150-300 عملة)\n• تنين النار (250-500 عملة)",
            inline=False
        )
        embed.add_field(
            name="⚔️ هجمات اللاعبين",
            value="`/هجوم @لاعب` - كل 10 دقائق\n• يعتمد على قوة الجيش\n• يمكن سرقة العملات\n• خسائر في الجنود\n• تأثير الدفاعات",
            inline=False
        )
        embed.add_field(
            name="🚀 الهجمات الصاروخية",
            value="`/صواريخ @لاعب` - كل 15 دقيقة\n• صاروخ مدمر (100 ضرر)\n• صاروخ باليستي (200 ضرر)\n• صاروخ نووي (500 ضرر)\n• يمكن اعتراضها بالدفاع الجوي",
            inline=False
        )
        embed.set_footer(text="استخدم الأزرار للانتقال بين الأقسام | Dev by CodeX team 💻")
        return embed
    
    def get_economy_embed(self):
        embed = discord.Embed(
            title="🛒 المتجر والاقتصاد",
            description="إدارة الموارد والشراء الذكي",
            color=0x9370db
        )
        embed.add_field(
            name="🪖 شراء الجنود",
            value="• جندي واحد: 5 عملات\n• 10 جنود: 45 عملة\n• 50 جندي: 200 عملة\n• 200 جندي: 900 عملة",
            inline=True
        )
        embed.add_field(
            name="🛡️ الدفاعات",
            value="• سور حماية: 500 عملة\n• 5 أسوار: 2000 عملة\n• دفاع جوي: 3000 عملة\n• ذخيرة دفاع: 100 عملة",
            inline=True
        )
        embed.add_field(
            name="🚀 الصواريخ",
            value="• صاروخ مدمر: 800 عملة\n• صاروخ باليستي: 1500 عملة\n• صاروخ نووي: 5000 عملة\n• قاعدة صواريخ: 2500 عملة",
            inline=True
        )
        embed.add_field(
            name="🏰 القواعد",
            value="• قاعدة عسكرية: 1000 عملة\n• ترقية قاعدة: 2000 عملة\n• تزيد قوة الجيش وتفتح خيارات جديدة",
            inline=False
        )
        embed.add_field(
            name="💡 نصائح اقتصادية",
            value="• ابدأ بشراء الجنود أولاً\n• ابن الدفاعات لحماية مواردك\n• استثمر في قاعدة الصواريخ للهجمات القوية\n• نوع مصادر دخلك",
            inline=False
        )
        embed.set_footer(text="استخدم الأزرار للانتقال بين الأقسام | Dev by CodeX team 💻")
        return embed
    
    def get_advanced_embed(self):
        embed = discord.Embed(
            title="🏭 الأنظمة المتقدمة",
            description="القوات المتخصصة والتقنيات المتطورة",
            color=0x4169e1
        )
        embed.add_field(
            name="✈️ القوات الجوية",
            value="`!طيران شراء/غارة/حالة`\n• مقاتلة F-16 (800 عملة)\n• مقاتلة ميج-29 (1000 عملة)\n• قاذفة قنابل (1200 عملة)\n• طائرة استطلاع (600 عملة)",
            inline=False
        )
        embed.add_field(
            name="⚓ القوات البحرية",
            value="`!بحرية شراء/هجوم/حالة`\n• مدمرة (1000 عملة)\n• غواصة (1500 عملة)\n• حاملة طائرات (3000 عملة)\n• زورق دورية (500 عملة)",
            inline=False
        )
        embed.add_field(
            name="☢️ البرنامج النووي",
            value="`!تخصيب` - تخصيب اليورانيوم (500 عملة)\n`!نووية` - صنع قنبلة نووية (2000 عملة + 10 كيلو يورانيوم)\nيتطلب قاعدة مستوى 2+",
            inline=False
        )
        embed.add_field(
            name="🌍 غزو الدول",
            value="`!غزو [دولة]` - غزو 10 دول مختلفة\nيتطلب 1000+ جندي و 1000 عملة\nمكافآت ضخمة عند النجاح",
            inline=False
        )
        embed.set_footer(text="استخدم الأزرار للانتقال بين الأقسام | Dev by CodeX team 💻")
        return embed
    
    def get_missions_embed(self):
        embed = discord.Embed(
            title="🎯 المهام والألعاب",
            description="مهام عسكرية تفاعلية ومكافآت إضافية",
            color=0xffd700
        )
        embed.add_field(
            name="🗡️ المهام العسكرية",
            value="`!مبارزة [سيف/رمح/درع]` - مبارزة تكتيكية\n`!استطلاع` - مهمة استطلاع خطيرة\n`!قنص` - تدريب القناصة\n`!تفكيك [لون]` - تفكيك القنابل\n`!اقتحام` - اقتحام قواعد العدو",
            inline=False
        )
        embed.add_field(
            name="🏭 الصناعات",
            value="`!مصنع [سلاح]` - تصنيع الأسلحة المتقدمة\n`!قاعدة [عمل]` - إدارة القواعد العسكرية\n`!تجارة [عمل]` - تجارة الأسلحة",
            inline=False
        )
        embed.add_field(
            name="💰 المكافآت",
            value="• المهام تعطي مكافآت أكبر من الغارات العادية\n• نجح في المهام لكسب معدات نادرة\n• بعض المهام تتطلب موارد للبدء\n• الفشل قد يؤدي لخسائر",
            inline=False
        )
        embed.add_field(
            name="🎖️ نظام الرتب",
            value="مجند (0) → جندي أول (100) → ملازم (200) → نقيب (500) → رائد (1000) → عقيد (2000) → جنرال (5000) → مارشال (10000+)",
            inline=False
        )
        embed.set_footer(text="استخدم الأزرار للانتقال بين الأقسام | Dev by CodeX team 💻")
        return embed
    
    def get_strategies_embed(self):
        embed = discord.Embed(
            title="📊 النصائح والاستراتيجيات",
            description="استراتيجيات متقدمة لبناء إمبراطوريتك العسكرية",
            color=0x32cd32
        )
        embed.add_field(
            name="🚀 استراتيجية البداية المثلى",
            value="1. ابدأ بالغارات لجمع 1000 عملة\n2. اشتر 200 جندي إضافي\n3. ابن قاعدة عسكرية\n4. اشتر دفاعات أساسية\n5. ابدأ بمهاجمة اللاعبين الضعفاء",
            inline=False
        )
        embed.add_field(
            name="⚔️ استراتيجيات القتال",
            value="• هاجم اللاعبين الأضعف أولاً\n• بناء الدفاعات يقلل خسائرك\n• الصواريخ فعالة ضد القواعد المحصنة\n• استخدم الطيران ضد الأعداء البعيدين",
            inline=False
        )
        embed.add_field(
            name="💰 إدارة الاقتصاد",
            value="• احتفظ بـ 20% من عملاتك للطوارئ\n• استثمر في مصادر دخل متنوعة\n• الدفاعات استثمار طويل المدى\n• لا تخزن عملات كثيرة (هدف للسرقة)",
            inline=False
        )
        embed.add_field(
            name="🏆 الوصول للمراتب العليا",
            value="• ركز على النمو المتوازن\n• شارك في جميع أنشطة اللعبة\n• ابن تحالفات مع لاعبين آخرين\n• طور تخصصك (جوي/بحري/نووي)",
            inline=False
        )
        embed.add_field(
            name="⚠️ أخطاء شائعة",
            value="• لا تنفق كل عملاتك على الجنود فقط\n• لا تهمل الدفاعات\n• لا تهاجم أعداء أقوى منك\n• لا تترك التبريدات تنتهي دون استغلالها",
            inline=False
        )
        embed.set_footer(text="استخدم الأزرار للانتقال بين الأقسام | Dev by CodeX team 💻")
        return embed
    
    @discord.ui.button(label="🏠 الرئيسية", style=discord.ButtonStyle.primary, row=0)
    async def main_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.current_page = "main"
        embed = self.get_main_embed()
        await interaction.response.edit_message(embed=embed, view=self)
    
    @discord.ui.button(label="🚀 البداية", style=discord.ButtonStyle.success, row=0)
    async def quick_start_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.current_page = "quick_start"
        embed = self.get_quick_start_embed()
        await interaction.response.edit_message(embed=embed, view=self)
    
    @discord.ui.button(label="⚔️ القتال", style=discord.ButtonStyle.danger, row=0)
    async def combat_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.current_page = "combat"
        embed = self.get_combat_embed()
        await interaction.response.edit_message(embed=embed, view=self)
    
    @discord.ui.button(label="🛒 المتجر", style=discord.ButtonStyle.secondary, row=1)
    async def economy_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.current_page = "economy"
        embed = self.get_economy_embed()
        await interaction.response.edit_message(embed=embed, view=self)
    
    @discord.ui.button(label="🏭 متقدم", style=discord.ButtonStyle.primary, row=1)
    async def advanced_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.current_page = "advanced"
        embed = self.get_advanced_embed()
        await interaction.response.edit_message(embed=embed, view=self)
    
    @discord.ui.button(label="🎯 المهام", style=discord.ButtonStyle.success, row=1)
    async def missions_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.current_page = "missions"
        embed = self.get_missions_embed()
        await interaction.response.edit_message(embed=embed, view=self)
    
    @discord.ui.button(label="📊 نصائح", style=discord.ButtonStyle.secondary, row=2)
    async def strategies_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.current_page = "strategies"
        embed = self.get_strategies_embed()
        await interaction.response.edit_message(embed=embed, view=self)

@bot.command(name="شرح")
@require_authorized_channel()
async def help(ctx):
    """Detailed bot explanation with interactive navigation"""
    try:
        view = GameGuideView()
        embed = view.get_main_embed()
        await ctx.send(embed=embed, view=view)
        
    except Exception as e:
        print(f"Error in bot_explanation: {e}")

@bot.command(name="أسلحة", aliases=["اسلحة", "أسلحه", "اسلحه"])
@require_authorized_channel()
async def weapons_list(ctx):
    """Show all available weapons and equipment"""
    try:
        embed = discord.Embed(
            title="🔫 دليل الأسلحة والمعدات",
            description="جميع الأسلحة والمعدات المتاحة في البوت",
            color=0x8B0000
        )
        
        embed.add_field(
            name="🛒 أسلحة المتجر",
            value="• **AK-47** - 50 عملة\n• **قاذف RPG** - 150 عملة\n• **قناص** - 100 عملة\n• **رشاش ثقيل** - 200 عملة",
            inline=False
        )
        
        embed.add_field(
            name="🚀 الصواريخ",
            value="• **صاروخ كاتيوشا** - 200 عملة\n• **صاروخ باتريوت** - 500 عملة\n• **صاروخ سكود** - 800 عملة\n• **صاروخ توماهوك** - 1200 عملة",
            inline=False
        )
        
        embed.add_field(
            name="🏭 أسلحة المصنع",
            value="• **دبابة** - 1200 عملة + 100 معدن\n• **طائرة مقاتلة** - 1800 عملة + 150 معدن\n• **صاروخ موجه** - 800 عملة + 80 معدن\n• **مدفعية ثقيلة** - 600 عملة + 60 معدن\n• **ألغام** - 200 عملة + 20 معدن",
            inline=False
        )
        
        embed.add_field(
            name="✈️ الطائرات",
            value="• **مقاتلة F-16** - 800 عملة\n• **مقاتلة ميج-29** - 1000 عملة\n• **قاذفة قنابل** - 1200 عملة\n• **طائرة استطلاع** - 600 عملة",
            inline=False
        )
        
        embed.add_field(
            name="🚢 السفن الحربية",
            value="• **مدمرة** - 1500 عملة\n• **فرقاطة** - 2000 عملة\n• **غواصة هجومية** - 2500 عملة\n• **حاملة طائرات** - 5000 عملة",
            inline=False
        )
        
        embed.add_field(
            name="☢️ الأسلحة النووية",
            value="• **قنبلة نووية تكتيكية** - 50 كيلوطن\n• **قنبلة نووية استراتيجية** - 100 كيلوطن\n• **رأس نووي باليستي** - 150 كيلوطن\n*يتطلب 10 كيلو يورانيوم مخصب + 2000 عملة*",
            inline=False
        )
        
        embed.add_field(
            name="🏗️ منشآت القاعدة",
            value="• **مطار عسكري** - 3000 عملة\n• **ميناء حربي** - 3500 عملة\n• **مصنع ذخيرة** - 2500 عملة\n• **مركز قيادة** - 4000 عملة\n• **مستشفى عسكري** - 2000 عملة",
            inline=False
        )
        
        embed.add_field(
            name="💡 ملاحظات مهمة",
            value="• بعض الأسلحة تتطلب مستوى قاعدة معين\n• الأسلحة المتقدمة تحتاج مواد خام\n• استخدم `!متجر` أو `!مصنع` للشراء\n• الأسعار قابلة للتغيير حسب السوق",
            inline=False
        )
        
        embed.set_footer(text="Dev by CodeX team 💻 | كتالوج الأسلحة الشامل")
        await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in weapons_list: {e}")

@bot.command(name="بداية")
@require_authorized_channel()
async def beginner_guide(ctx):
    """Beginner's guide for new players"""
    try:
        embed = discord.Embed(
            title="🎮 دليل المبتدئين - كيف تلعب",
            description="خطوات بسيطة لبدء رحلتك العسكرية",
            color=0x00FF7F
        )
        
        embed.add_field(
            name="🏁 الخطوة الأولى - إنشاء الجيش",
            value="**استخدم:** `!جيش [اسم جيشك]`\n"
                  "**مثال:** `!جيش جيش النصر`\n"
                  "• ستحصل على 100 جندي\n"
                  "• ستحصل على 500 عملة ذهبية\n"
                  "• هذا هو أساس إمبراطوريتك العسكرية",
            inline=False
        )
        
        embed.add_field(
            name="💰 الخطوة الثانية - جمع الموارد",
            value="**استخدم:** `!غارة` أو `!غارة 3`\n"
                  "• مهاجمة الوحوش لكسب العملات\n"
                  "• كل غارة تعطي 20-100 عملة\n"
                  "• انتظر 5 دقائق بين كل غارة\n"
                  "• ابدأ بغارة واحدة لتتعلم",
            inline=False
        )
        
        embed.add_field(
            name="🛒 الخطوة الثالثة - التسوق الذكي",
            value="**استخدم:** `!متجر`\n"
                  "**أول مشترياتك:**\n"
                  "• اشتر 50 جندي إضافي (150 عملة)\n"
                  "• اشتر أسوار للدفاع (100 عملة)\n"
                  "• اشتر سلاح AK-47 (50 عملة)\n"
                  "• احتفظ ببعض العملات للطوارئ",
            inline=False
        )
        
        embed.add_field(
            name="📊 الخطوة الرابعة - مراقبة التقدم",
            value="**استخدم:** `!حالة`\n"
                  "• راقب عدد جنودك\n"
                  "• تابع رصيد العملات\n"
                  "• اطلع على أسلحتك ودفاعاتك\n"
                  "• تأكد من نمو قوتك باستمرار",
            inline=False
        )
        
        embed.add_field(
            name="🎯 الخطوة الخامسة - التوسع",
            value="**بعد 300 عملة:**\n"
                  "• جرب المهام العسكرية: `!مبارزة سيف`\n"
                  "• طور قاعدتك: `!قاعدة ترقية`\n"
                  "• ابدأ في صناعة الأسلحة: `!مصنع`\n"
                  "• فكر في مهاجمة لاعبين آخرين",
            inline=False
        )
        
        embed.add_field(
            name="⚠️ نصائح مهمة للمبتدئين",
            value="🔸 **لا تفقد كل جنودك** - سيحذف جيشك!\n"
                  "🔸 **ابن دفاعات قوية** - الأسوار تحميك\n"
                  "🔸 **لا تتسرع** - خطط قبل الهجمات الكبيرة\n"
                  "🔸 **تعلم من الأخطاء** - كل فشل درس\n"
                  "🔸 **تابع الأوامر** - `!أوامر` و `!شرح`",
            inline=False
        )
        
        embed.add_field(
            name="🚀 هدفك الأول",
            value="**وصل إلى:**\n"
                  "• 500 جندي على الأقل\n"
                  "• 1000 عملة في الخزينة\n"
                  "• قاعدة مستوى 2\n"
                  "• 3 أنواع أسلحة مختلفة\n"
                  "**ثم ابدأ في العمليات المتقدمة!**",
            inline=False
        )
        
        embed.add_field(
            name="🆘 إذا احتجت مساعدة",
            value="`!شرح` - شرح مفصل للبوت\n"
                  "`!أسلحة` - دليل جميع الأسلحة\n"
                  "`!أوامر` - قائمة كاملة بالأوامر\n"
                  "**تذكر: التجربة أفضل معلم!**",
            inline=False
        )
        
        embed.set_footer(text="Dev by CodeX team 💻 | دليل المبتدئين الشامل")
        await ctx.send(embed=embed)
        
    except Exception as e:
        print(f"Error in beginner_guide: {e}")

# Error handler
@bot.event
async def on_application_command_error(interaction: discord.Interaction, error):
    print(f"Command error: {error}")
    print(traceback.format_exc())
    
    if not interaction.response.is_done():
        embed = embed_manager.error_embed("خطأ في الأمر", "حدث خطأ أثناء تنفيذ الأمر")
        await interaction.response.send_message(embed=embed, ephemeral=True)

# ADMIN COMMANDS - HIDDEN FROM HELP
@bot.command(name="منح_عملات", hidden=True)
async def admin_give_coins(ctx, user: discord.Member, amount: int):
    """Give coins to a user (Admin only)"""
    try:
        if not config.is_admin(ctx.author.id):
            await ctx.message.delete()
            return
        
        player = await db.get_player(user.id)
        if not player:
            embed = embed_manager.error_embed("اللاعب غير موجود", f"{user.mention} لا يملك جيش")
            await ctx.send(embed=embed, delete_after=10)
            return
        
        await db.add_coins(user.id, amount)
        
        embed = discord.Embed(
            title="💰 منح عملات - أمر إداري",
            description=f"تم منح **{amount}** عملة لـ {user.mention}",
            color=0x00ff00
        )
        embed.add_field(name="🎯 المستلم", value=user.mention, inline=True)
        embed.add_field(name="💰 المبلغ", value=f"{amount} عملة", inline=True)
        embed.add_field(name="👤 المرسل", value=ctx.author.mention, inline=True)
        embed.set_footer(text="أمر إداري مخفي | Dev by CodeX team 💻")
        
        await ctx.send(embed=embed, delete_after=15)
        await ctx.message.delete()
        
    except Exception as e:
        print(f"Error in admin_give_coins: {e}")

@bot.command(name="منح_جنود", hidden=True)
async def admin_give_soldiers(ctx, user: discord.Member, amount: int):
    """Give soldiers to a user (Admin only)"""
    try:
        if not config.is_admin(ctx.author.id):
            await ctx.message.delete()
            return
        
        player = await db.get_player(user.id)
        if not player:
            embed = embed_manager.error_embed("اللاعب غير موجود", f"{user.mention} لا يملك جيش")
            await ctx.send(embed=embed, delete_after=10)
            return
        
        new_soldiers = player['soldiers'] + amount
        await db.update_player(user.id, soldiers=new_soldiers)
        
        embed = discord.Embed(
            title="🪖 منح جنود - أمر إداري",
            description=f"تم منح **{amount}** جندي لـ {user.mention}",
            color=0x00ff00
        )
        embed.add_field(name="🎯 المستلم", value=user.mention, inline=True)
        embed.add_field(name="🪖 العدد", value=f"{amount} جندي", inline=True)
        embed.add_field(name="📊 الإجمالي", value=f"{new_soldiers} جندي", inline=True)
        embed.set_footer(text="أمر إداري مخفي | Dev by CodeX team 💻")
        
        await ctx.send(embed=embed, delete_after=15)
        await ctx.message.delete()
        
    except Exception as e:
        print(f"Error in admin_give_soldiers: {e}")

@bot.command(name="منح_أسلحة", hidden=True)
async def admin_give_weapons(ctx, user: discord.Member, weapon_type: str, weapon_name: str, quantity: int = 1):
    """Give weapons to a user (Admin only)"""
    try:
        if not config.is_admin(ctx.author.id):
            await ctx.message.delete()
            return
        
        player = await db.get_player(user.id)
        if not player:
            embed = embed_manager.error_embed("اللاعب غير موجود", f"{user.mention} لا يملك جيش")
            await ctx.send(embed=embed, delete_after=10)
            return
        
        # Add weapon to inventory
        await db.add_item(user.id, weapon_type, weapon_name, quantity)
        
        embed = discord.Embed(
            title="🚀 منح أسلحة - أمر إداري",
            description=f"تم منح **{quantity}x {weapon_name}** لـ {user.mention}",
            color=0xff6600
        )
        embed.add_field(name="🎯 المستلم", value=user.mention, inline=True)
        embed.add_field(name="🔫 السلاح", value=weapon_name, inline=True)
        embed.add_field(name="📦 الكمية", value=f"{quantity}x", inline=True)
        embed.add_field(name="📂 النوع", value=weapon_type, inline=True)
        embed.set_footer(text="أمر إداري مخفي | Dev by CodeX team 💻")
        
        await ctx.send(embed=embed, delete_after=15)
        await ctx.message.delete()
        
    except Exception as e:
        print(f"Error in admin_give_weapons: {e}")

@bot.command(name="حذف_لاعب", hidden=True)
async def admin_delete_player(ctx, user: discord.Member):
    """Delete a player completely (Admin only)"""
    try:
        if not config.is_admin(ctx.author.id):
            await ctx.message.delete()
            return
        
        player = await db.get_player(user.id)
        if not player:
            embed = embed_manager.error_embed("اللاعب غير موجود", f"{user.mention} لا يملك جيش")
            await ctx.send(embed=embed, delete_after=10)
            return
        
        # Delete player
        await db.delete_player(user.id)
        
        embed = discord.Embed(
            title="🗑️ حذف لاعب - أمر إداري",
            description=f"تم حذف جيش {user.mention} بالكامل",
            color=0xff0000
        )
        embed.add_field(name="🎯 المحذوف", value=user.mention, inline=True)
        embed.add_field(name="🪖 الجنود المفقودة", value=f"{player['soldiers']}", inline=True)
        embed.add_field(name="💰 العملات المفقودة", value=f"{player['coins']}", inline=True)
        embed.set_footer(text="أمر إداري مخفي | Dev by CodeX team 💻")
        
        await ctx.send(embed=embed, delete_after=15)
        await ctx.message.delete()
        
    except Exception as e:
        print(f"Error in admin_delete_player: {e}")

@bot.command(name="تعديل_قاعدة", hidden=True)
async def admin_modify_base(ctx, user: discord.Member, base_level: int = 1):
    """Modify user's base level (Admin only)"""
    try:
        if not config.is_admin(ctx.author.id):
            await ctx.message.delete()
            return
        
        player = await db.get_player(user.id)
        if not player:
            embed = embed_manager.error_embed("اللاعب غير موجود", f"{user.mention} لا يملك جيش")
            await ctx.send(embed=embed, delete_after=10)
            return
        
        await db.update_player(user.id, base_level=base_level)
        
        embed = discord.Embed(
            title="🏰 تعديل قاعدة - أمر إداري",
            description=f"تم تعديل مستوى قاعدة {user.mention}",
            color=0x8b4513
        )
        embed.add_field(name="🎯 اللاعب", value=user.mention, inline=True)
        embed.add_field(name="🏰 المستوى الجديد", value=f"المستوى {base_level}", inline=True)
        embed.set_footer(text="أمر إداري مخفي | Dev by CodeX team 💻")
        
        await ctx.send(embed=embed, delete_after=15)
        await ctx.message.delete()
        
    except Exception as e:
        print(f"Error in admin_modify_base: {e}")

@bot.command(name="معلومات_لاعب", hidden=True)
async def admin_player_info(ctx, user: discord.Member):
    """Get detailed player information (Admin only)"""
    try:
        if not config.is_admin(ctx.author.id):
            await ctx.message.delete()
            return
        
        player = await db.get_player(user.id)
        if not player:
            embed = embed_manager.error_embed("اللاعب غير موجود", f"{user.mention} لا يملك جيش")
            await ctx.send(embed=embed, delete_after=10)
            return
        
        # Get inventory
        inventory = await db.get_player_inventory(user.id)
        
        embed = discord.Embed(
            title="🔍 معلومات اللاعب - أمر إداري",
            description=f"معلومات مفصلة عن {user.mention}",
            color=0x9370db
        )
        
        embed.add_field(name="🪖 الجيش", value=player['army_name'], inline=True)
        embed.add_field(name="👥 الجنود", value=f"{player['soldiers']}", inline=True)
        embed.add_field(name="💰 العملات", value=f"{player['coins']}", inline=True)
        embed.add_field(name="🏰 مستوى القاعدة", value=f"{player.get('base_level', 0)}", inline=True)
        embed.add_field(name="🛡️ الأسوار", value=f"{player.get('walls', 0)}", inline=True)
        embed.add_field(name="🚀 قاعدة صواريخ", value=f"{player.get('missile_base', 0)}", inline=True)
        
        # Add inventory info
        if inventory:
            inv_text = ""
            for category, items in inventory.items():
                if items:
                    inv_text += f"**{category}:**\n"
                    for item, count in items.items():
                        inv_text += f"• {item}: {count}\n"
            if inv_text:
                embed.add_field(name="📦 المخزون", value=inv_text[:1024], inline=False)
        
        embed.set_footer(text="أمر إداري مخفي | Dev by CodeX team 💻")
        
        await ctx.send(embed=embed, delete_after=30)
        await ctx.message.delete()
        
    except Exception as e:
        print(f"Error in admin_player_info: {e}")

@bot.command(name="إزالة_تبريد", hidden=True)
async def admin_remove_cooldown(ctx, user: discord.Member, cooldown_type: str = ""):
    """Remove cooldowns for a user (Admin only)"""
    try:
        if not config.is_admin(ctx.author.id):
            await ctx.message.delete()
            return
        
        player = await db.get_player(user.id)
        if not player:
            embed = embed_manager.error_embed("اللاعب غير موجود", f"{user.mention} لا يملك جيش")
            await ctx.send(embed=embed, delete_after=10)
            return
        
        if cooldown_type and cooldown_type.strip():
            # Remove specific cooldown
            await db.set_cooldown(user.id, cooldown_type, 0)
            embed = discord.Embed(
                title="⏰ إزالة تبريد - أمر إداري",
                description=f"تم إزالة تبريد **{cooldown_type}** لـ {user.mention}",
                color=0x00ffff
            )
        else:
            # Remove all cooldowns
            cooldown_types = ['raid', 'attack', 'missile']
            for ct in cooldown_types:
                await db.set_cooldown(user.id, ct, 0)
            embed = discord.Embed(
                title="⏰ إزالة جميع التبريدات - أمر إداري", 
                description=f"تم إزالة جميع التبريدات لـ {user.mention}",
                color=0x00ffff
            )
        
        embed.add_field(name="🎯 اللاعب", value=user.mention, inline=True)
        embed.set_footer(text="أمر إداري مخفي | Dev by CodeX team 💻")
        
        await ctx.send(embed=embed, delete_after=15)
        await ctx.message.delete()
        
    except Exception as e:
        print(f"Error in admin_remove_cooldown: {e}")

class AdminGuideView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)
        self.current_page = "main"
    
    def get_main_embed(self):
        embed = discord.Embed(
            title="🔧 دليل الأوامر الإدارية",
            description="أوامر مخصصة للمشرفين والمديرين فقط\n\n**⚠️ سرية عالية - للمشرفين فقط**",
            color=0xff6600
        )
        embed.add_field(
            name="💰 إدارة الموارد",
            value="منح العملات والجنود والأسلحة للاعبين",
            inline=False
        )
        embed.add_field(
            name="🛠️ إدارة اللاعبين",
            value="حذف وتعديل ومراقبة بيانات اللاعبين",
            inline=False
        )
        embed.add_field(
            name="⏰ إدارة النظام",
            value="إزالة التبريدات وإدارة القيود الزمنية",
            inline=False
        )
        embed.add_field(
            name="📊 المراقبة والتحليل",
            value="مراقبة الأنشطة وتحليل البيانات",
            inline=False
        )
        embed.set_footer(text="استخدم الأزرار للتنقل | أوامر سرية")
        return embed
    
    def get_resources_embed(self):
        embed = discord.Embed(
            title="💰 إدارة الموارد",
            description="أوامر منح الموارد للاعبين",
            color=0x00ff00
        )
        embed.add_field(
            name="💰 منح العملات",
            value="`!منح_عملات @لاعب [مبلغ]`\nمثال: `!منح_عملات @User 5000`",
            inline=False
        )
        embed.add_field(
            name="🪖 منح الجنود",
            value="`!منح_جنود @لاعب [عدد]`\nمثال: `!منح_جنود @User 1000`",
            inline=False
        )
        embed.add_field(
            name="🚀 منح الأسلحة",
            value="`!منح_أسلحة @لاعب [نوع] [اسم] [كمية]`\nمثال: `!منح_أسلحة @User missiles \"صاروخ نووي\" 5`",
            inline=False
        )
        embed.add_field(
            name="📦 أنواع الأسلحة المتاحة",
            value="• `missiles` - الصواريخ\n• `aircraft` - الطائرات\n• `ships` - السفن\n• `nuclear` - الأسلحة النووية\n• `weapons` - الأسلحة التقليدية\n• `defense` - معدات الدفاع",
            inline=False
        )
        embed.set_footer(text="الأوامر تُحذف تلقائياً بعد الاستخدام")
        return embed
    
    def get_players_embed(self):
        embed = discord.Embed(
            title="🛠️ إدارة اللاعبين",
            description="أوامر التحكم في بيانات اللاعبين",
            color=0xff4500
        )
        embed.add_field(
            name="🔍 معلومات اللاعب",
            value="`!معلومات_لاعب @لاعب`\nعرض جميع بيانات اللاعب المفصلة",
            inline=False
        )
        embed.add_field(
            name="🏰 تعديل القاعدة",
            value="`!تعديل_قاعدة @لاعب [مستوى]`\nمثال: `!تعديل_قاعدة @User 5`",
            inline=False
        )
        embed.add_field(
            name="🗑️ حذف اللاعب",
            value="`!حذف_لاعب @لاعب`\nحذف جيش اللاعب بالكامل (خطير!)",
            inline=False
        )
        embed.add_field(
            name="⚠️ تحذير",
            value="حذف اللاعب يزيل جميع بياناته نهائياً\nتأكد من صحة القرار قبل التنفيذ",
            inline=False
        )
        embed.set_footer(text="استخدم بحذر - التغييرات لا يمكن التراجع عنها")
        return embed
    
    def get_system_embed(self):
        embed = discord.Embed(
            title="⏰ إدارة النظام",
            description="أوامر إدارة التبريدات والقيود",
            color=0x00ffff
        )
        embed.add_field(
            name="⏰ إزالة جميع التبريدات",
            value="`!إزالة_تبريد @لاعب`\nإزالة جميع التبريدات للاعب",
            inline=False
        )
        embed.add_field(
            name="🎯 إزالة تبريد محدد",
            value="`!إزالة_تبريد @لاعب [نوع]`\nأنواع التبريد:\n• `raid` - تبريد الغارات\n• `attack` - تبريد الهجمات\n• `missile` - تبريد الصواريخ",
            inline=False
        )
        embed.add_field(
            name="📋 عرض الأوامر",
            value="`!أوامر_إدارية`\nعرض هذا الدليل التفاعلي",
            inline=False
        )
        embed.set_footer(text="إزالة التبريدات تسمح بالاستخدام الفوري")
        return embed
    
    def get_monitoring_embed(self):
        embed = discord.Embed(
            title="📊 المراقبة والتحليل",
            description="أدوات مراقبة الأنشطة والإحصائيات",
            color=0x9370db
        )
        embed.add_field(
            name="🔍 تتبع الأنشطة",
            value="• مراقبة تلقائية للأنشطة المشبوهة\n• تسجيل جميع المعاملات الكبيرة\n• إنذارات عند اكتشاف غش محتمل",
            inline=False
        )
        embed.add_field(
            name="📈 الإحصائيات",
            value="• إحصائيات استخدام الأوامر\n• تقارير النشاط اليومي\n• إحصائيات اللاعبين النشطين",
            inline=False
        )
        embed.add_field(
            name="🛡️ الأمان",
            value="• جميع الأوامر الإدارية محفوظة في السجل\n• الوصول محدود للمشرفين المحددين فقط\n• حذف تلقائي للأوامر الحساسة",
            inline=False
        )
        embed.add_field(
            name="📝 السجلات",
            value="جميع الأنشطة الإدارية يتم تسجيلها تلقائياً للمراجعة والتدقيق",
            inline=False
        )
        embed.set_footer(text="المراقبة تعمل على مدار الساعة")
        return embed
    
    @discord.ui.button(label="🏠 الرئيسية", style=discord.ButtonStyle.primary, row=0)
    async def main_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = self.get_main_embed()
        await interaction.response.edit_message(embed=embed, view=self)
    
    @discord.ui.button(label="💰 الموارد", style=discord.ButtonStyle.success, row=0)
    async def resources_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = self.get_resources_embed()
        await interaction.response.edit_message(embed=embed, view=self)
    
    @discord.ui.button(label="🛠️ اللاعبين", style=discord.ButtonStyle.danger, row=0)
    async def players_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = self.get_players_embed()
        await interaction.response.edit_message(embed=embed, view=self)
    
    @discord.ui.button(label="⏰ النظام", style=discord.ButtonStyle.secondary, row=1)
    async def system_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = self.get_system_embed()
        await interaction.response.edit_message(embed=embed, view=self)
    
    @discord.ui.button(label="📊 المراقبة", style=discord.ButtonStyle.primary, row=1)
    async def monitoring_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = self.get_monitoring_embed()
        await interaction.response.edit_message(embed=embed, view=self)

@bot.command(name="أوامر_إدارية", hidden=True)
async def admin_commands_list(ctx):
    """List all admin commands (Admin only)"""
    try:
        if not config.is_admin(ctx.author.id):
            await ctx.message.delete()
            return
        
        view = AdminGuideView()
        embed = view.get_main_embed()
        await ctx.send(embed=embed, view=view, delete_after=300)
        await ctx.message.delete()
        
    except Exception as e:
        print(f"Error in admin_commands_list: {e}")

@bot.command(name="إدارة", hidden=True, aliases=["ادارة", "إداره", "اداره"])
async def admin_quick_access(ctx):
    """Quick access to admin commands (Admin only)"""
    try:
        if not config.is_admin(ctx.author.id):
            await ctx.message.delete()
            return
        
        embed = discord.Embed(
            title="🔧 الوصول السريع للإدارة",
            description="أوامر الإدارة الأساسية للوصول السريع",
            color=0xff6600
        )
        
        embed.add_field(
            name="💰 إدارة الموارد",
            value="`!منح_عملات @لاعب مبلغ` - منح عملات\n"
                  "`!منح_جنود @لاعب عدد` - منح جنود\n"
                  "`!منح_أسلحة @لاعب نوع اسم كمية` - منح أسلحة",
            inline=False
        )
        
        embed.add_field(
            name="🛠️ إدارة اللاعبين",
            value="`!حذف_لاعب @لاعب` - حذف لاعب كاملاً\n"
                  "`!تعديل_قاعدة @لاعب مستوى` - تعديل مستوى القاعدة\n"
                  "`!معلومات_لاعب @لاعب` - معلومات مفصلة",
            inline=False
        )
        
        embed.add_field(
            name="⏰ إدارة التبريد",
            value="`!إزالة_تبريد @لاعب [نوع]` - إزالة تبريد\n"
                  "أنواع التبريد: raid, attack, missile",
            inline=False
        )
        
        embed.add_field(
            name="📝 أمثلة الاستخدام",
            value="```\n!منح_عملات @User 1000\n!منح_جنود @User 500\n!منح_أسلحة @User missiles \"صاروخ نووي\" 5\n!إزالة_تبريد @User raid```",
            inline=False
        )
        
        embed.set_footer(text="أوامر إدارية مخفية | Dev by CodeX team 💻")
        
        await ctx.send(embed=embed, delete_after=120)
        await ctx.message.delete()
        
    except Exception as e:
        print(f"Error in admin_quick_access: {e}")

# Background task for cleanup and maintenance
@tasks.loop(hours=1)
async def maintenance_task():
    try:
        await db.cleanup_expired_cooldowns()
        print("تم تنظيف البيانات المنتهية الصلاحية")
    except Exception as e:
        print(f"Error in maintenance: {e}")

@maintenance_task.before_loop
async def before_maintenance():
    await bot.wait_until_ready()

# Start the bot
if __name__ == "__main__":
    TOKEN = os.getenv("DISCORD_TOKEN", "YOUR_DISCORD_BOT_TOKEN")
    bot.run(TOKEN)
