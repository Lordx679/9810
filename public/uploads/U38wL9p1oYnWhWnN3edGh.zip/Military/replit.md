# Discord War Game Bot

## Overview

This is a Discord bot implementation of a war-themed multiplayer game written in Python. Players can create armies, conduct raids against monsters, engage in PvP combat, purchase military equipment, and launch missile attacks. The game features a comprehensive economy system with coins, cooldowns, and strategic elements.

## System Architecture

The application follows a modular architecture pattern with clear separation of concerns:

### Core Components
- **main.py**: Discord bot entry point and command handling
- **database.py**: SQLite database operations using aiosqlite
- **game_logic.py**: Core game mechanics for raids and basic gameplay
- **combat.py**: PvP combat system and missile attacks
- **shop.py**: In-game store and item purchasing system
- **embeds.py**: Discord embed formatting and UI management
- **utils.py**: Utility functions for formatting and calculations
- **config.py**: Centralized configuration management

### Architecture Pattern
The system uses a service-oriented architecture where each module handles specific game aspects. Components are loosely coupled through dependency injection, with the database layer serving as the central data store.

## Key Components

### Database Layer
- **Technology**: MongoDB with Motor (async driver) for cloud storage
- **Connection**: CodeX team MongoDB Atlas cluster
- **Collections**: 
  - `players`: Core player data (army info, stats, resources)
  - `inventory`: Item storage system with user_id indexing
  - `cooldowns`: Time-based action restrictions
  - `battle_records`: Combat history and statistics
- **Design**: Document-based NoSQL with proper indexing for performance

### Discord Integration
- **Framework**: discord.py with slash commands
- **Features**: Interactive embeds, ephemeral responses, command synchronization
- **UI Pattern**: Embed-based interface with color-coded feedback

### Game Systems
- **Combat**: Turn-based with power calculations and random elements
- **Economy**: Coin-based system with multiple earning methods
- **Progression**: Level-based upgrades and equipment tiers
- **Cooldowns**: Time-based action limitations for balance

## Data Flow

1. **User Input**: Discord slash commands trigger bot handlers
2. **Validation**: Input validation and cooldown checks
3. **Business Logic**: Game mechanics processing in respective modules
4. **Database Operations**: Async SQLite operations for persistence
5. **Response Generation**: Embed creation and Discord API responses

### Combat Flow
- Attacker/defender power calculation
- Random battle resolution with weighted outcomes
- Resource transfer and casualty calculation
- Database updates and cooldown application

### Shop Flow
- Item availability checking
- Price validation against player resources
- Inventory updates and resource deduction
- Confirmation through Discord embeds

## External Dependencies

### Core Dependencies
- **discord.py**: Discord API wrapper for bot functionality
- **motor**: Async MongoDB driver for database operations
- **pymongo**: MongoDB driver with connection management
- **asyncio**: Async/await pattern implementation

### Python Standard Library
- **json**: Data serialization
- **time**: Timestamp and cooldown calculations
- **random**: Battle outcomes and raid rewards
- **typing**: Type hints for better code clarity

## Deployment Strategy

### Current Setup
- **Platform**: Replit-based deployment
- **Runtime**: Python 3.11 with Nix package management
- **Database**: MongoDB Atlas cloud database (CodeX team cluster)
- **Process**: Single-process bot with async event handling

### Configuration
- Environment variable for Discord bot token
- Local file-based database storage
- Automatic dependency installation via pip

### Scalability Considerations
- MongoDB Atlas provides automatic scaling and backups
- Cloud-based storage enables multi-instance deployment
- Document-based design supports flexible data growth

## Changelog

```
Changelog:
- June 23, 2025: Initial Discord bot setup completed
- June 23, 2025: Fixed all syntax errors and import conflicts  
- June 23, 2025: Bot successfully deployed and running with 8 Arabic commands
- June 23, 2025: Database initialized with full game schema
- June 23, 2025: All core systems operational (raids, combat, shop, missiles)
- June 23, 2025: Added prefix commands (!جيش, !غارة, !متجر, !حالة, !هجوم)
- June 23, 2025: Transformed mini-games into war-themed military missions
- June 23, 2025: Added 5 military missions (!مبارزة, !استطلاع, !قنص, !تفكيك, !اقتحام)
- June 23, 2025: Added CodeX team credits throughout all bot responses
- June 23, 2025: Updated help system to include all new commands and war games
- June 23, 2025: Implemented nuclear operations (!تخصيب, !نووية) with uranium enrichment system
- June 23, 2025: Added country invasion system (!غزو) with 10 Middle Eastern countries
- June 23, 2025: Built comprehensive air force management (!طيران) with aircraft purchase and raids
- June 23, 2025: Developed naval forces system (!بحرية) with warships and maritime operations
- June 23, 2025: Created advanced weapons factory (!مصنع) with material requirements
- June 23, 2025: Implemented military base infrastructure (!قاعدة) with facility construction
- June 23, 2025: Added arms trading system (!تجارة) with black market operations
- June 23, 2025: Added comprehensive bot explanation (!شرح) with detailed usage guide
- June 23, 2025: Implemented weapons catalog (!أسلحة) showing all available equipment
- June 23, 2025: Created beginner's guide (!بداية) with step-by-step instructions
- June 23, 2025: Fixed weapons command with Arabic character aliases support
- June 23, 2025: Enhanced shop system to display remaining coins after each purchase
- June 23, 2025: Updated all purchasing systems (air force, navy, factory, base, trading) to show current balance
- June 23, 2025: Added comprehensive admin command system with hidden commands for game masters
- June 23, 2025: Created admin_config.py for easy admin user management
- June 23, 2025: Implemented secure admin commands for resource management, player control, and cooldown removal
- June 23, 2025: Implemented comprehensive level system (1-100) with XP rewards
- June 23, 2025: Added level-based discounts on all shop purchases (5%-70% discount)
- June 23, 2025: Enhanced error messages for players without armies with helpful guidance
- June 23, 2025: Added XP rewards for raids (50 XP per successful raid) and combat activities
- June 23, 2025: Updated shop system to show level discounts and savings
- June 23, 2025: Integrated player level display in status and shop interfaces
- June 23, 2025: MAJOR UPDATE - Removed all slash commands except /setchannel
- June 23, 2025: Converted all main commands to prefix-only system
- June 23, 2025: Implemented new help command (!مساعدة) with forward/back navigation buttons
- June 23, 2025: Created 6-page help system with detailed command explanations and usage guides
- June 23, 2025: Added /help slash command alongside existing !مساعدة prefix command
- June 23, 2025: Removed /help slash command - keeping only /setchannel slash command and all others as prefix
- June 23, 2025: Added channel authorization system - all commands require /setchannel to be used first
- June 23, 2025: Implemented command blocking for unauthorized channels with informative error messages
- June 23, 2025: Added /help slash command with interactive navigation (works in all channels)
- June 23, 2025: Added /جيش slash command for army creation with channel authorization check
- June 23, 2025: Migrated from SQLite to MongoDB Atlas cloud database
- June 23, 2025: Implemented MongoDB integration with Motor async driver
- June 23, 2025: Added database indexing for improved performance
- June 23, 2025: Enhanced data persistence with cloud-based storage
- June 23, 2025: Added !قصف command for direct missile attacks
- June 23, 2025: Implemented missile attack system with interactive selection menu
- June 23, 2025: Added aliases for missile commands (!صاروخ, !صواريخ, missile)
- June 24, 2025: Redesigned help system to match user's UI mockup
- June 24, 2025: Organized help into 5 focused sections with clean navigation
- June 24, 2025: Updated help layout with proper Arabic formatting and arrows
- June 24, 2025: Migrated to PostgreSQL database for enhanced persistence
- June 24, 2025: Added comprehensive player change logging system
- June 24, 2025: Enhanced channel authorization with duplicate checking
- June 24, 2025: Limited help system to 2 pages maximum as requested
- June 24, 2025: Updated help system layout to match user's screenshot design
- June 24, 2025: Reorganized help sections with arrow formatting and proper categorization
- June 24, 2025: Expanded help system to 6 pages as requested by user
- June 24, 2025: Added dedicated pages for industries, operations, rewards, and commands
- June 24, 2025: Fixed raid command with missing database columns and aliases
- June 24, 2025: Added support for common Arabic variations (مغارة، مغاره)
- June 24, 2025: Resolved total_raids and successful_raids tracking issues
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```

## Technical Notes

### Game Balance
- Configurable cooldowns prevent spam abuse
- Tiered pricing system encourages progression
- Random elements maintain engagement
- Resource scarcity drives strategic decisions

### Code Quality
- Modular design enables easy feature additions
- Async patterns ensure responsive bot performance
- Type hints improve maintainability
- Arabic language support for UI elements

### Security Considerations
- SQL injection protection through parameterized queries
- Rate limiting via cooldown systems
- Input validation for all user commands
- Ephemeral responses for sensitive information