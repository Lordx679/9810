import discord
from typing import Dict, List, Any, Optional
from datetime import datetime
import random

class EmbedManager:
    """Manages Discord embed creation for the game"""
    
    def __init__(self):
        self.colors = {
            'success': 0x00ff00,
            'error': 0xff0000,
            'info': 0x0099ff,
            'warning': 0xffa500,
            'raid': 0x8b4513,
            'combat': 0xff4500,
            'shop': 0x9370db,
            'missile': 0xff6600
        }
    
    def success_embed(self, title: str, description: str) -> discord.Embed:
        """Create success embed"""
        embed = discord.Embed(
            title=f"✅ {title}",
            description=description,
            color=self.colors['success']
        )
        embed.timestamp = datetime.utcnow()
        return embed
    
    def error_embed(self, title: str, description: str) -> discord.Embed:
        """Create error embed"""
        embed = discord.Embed(
            title=f"❌ {title}",
            description=description,
            color=self.colors['error']
        )
        embed.timestamp = datetime.utcnow()
        return embed
    
    def info_embed(self, title: str, description: str) -> discord.Embed:
        """Create info embed"""
        embed = discord.Embed(
            title=f"ℹ️ {title}",
            description=description,
            color=self.colors['info']
        )
        embed.timestamp = datetime.utcnow()
        return embed
    
    def raid_result_embed(self, raid_results: List[Dict[str, Any]], total_coins: int, 
                         total_losses: int, remaining_soldiers: int) -> discord.Embed:
        """Create raid result embed"""
        embed = discord.Embed(
            title="⚔️ نتائج الغارة",
            color=self.colors['raid']
        )
        
        # Summary
        embed.add_field(
            name="📊 الملخص",
            value=f"**عدد الغارات:** {len(raid_results)}\n**العملات المكتسبة:** {total_coins} 💰\n**الجنود المفقودون:** {total_losses} 💀\n**الجنود المتبقون:** {remaining_soldiers} ⚔️",
            inline=False
        )
        
        # Individual raid results
        results_text = []
        for i, result in enumerate(raid_results[:5]):  # Show max 5 raids
            status = "🏆" if result['battle_won'] else "💀"
            results_text.append(
                f"{status} **الغارة {i+1}:** {result['monster']} - "
                f"{result['coins_earned']} عملة ({result['soldiers_lost']} خسائر)"
            )
        
        if results_text:
            embed.add_field(
                name="🎯 تفاصيل الغارات",
                value="\n".join(results_text),
                inline=False
            )
        
        if len(raid_results) > 5:
            embed.add_field(
                name="📝 ملاحظة",
                value=f"تم عرض 5 من أصل {len(raid_results)} غارة",
                inline=False
            )
        
        # Warning if army is weak
        if remaining_soldiers < 50:
            embed.add_field(
                name="⚠️ تحذير",
                value="جيشك ضعيف! فكر في شراء المزيد من الجنود قبل الغارة التالية",
                inline=False
            )
        
        embed.timestamp = datetime.utcnow()
        return embed
    
    def attack_result_embed(self, attacker, target, 
                           result: Dict[str, Any]) -> discord.Embed:
        """Create attack result embed"""
        if result['attacker_wins']:
            embed = discord.Embed(
                title="🏆 انتصار في المعركة!",
                color=self.colors['success']
            )
            description = f"**المهاجم:** {attacker.display_name} ✅\n**المدافع:** {target.display_name} ❌"
        else:
            embed = discord.Embed(
                title="🛡️ صد الهجوم بنجاح!",
                color=self.colors['warning']
            )
            description = f"**المهاجم:** {attacker.display_name} ❌\n**المدافع:** {target.display_name} ✅"
        
        embed.description = description
        
        # Battle details
        embed.add_field(
            name="⚔️ خسائر المهاجم",
            value=f"{result['attacker_losses']} جندي\n**المتبقي:** {result['attacker_remaining']}",
            inline=True
        )
        
        embed.add_field(
            name="🛡️ خسائر المدافع",
            value=f"{result['target_losses']} جندي\n**المتبقي:** {result['target_remaining']}",
            inline=True
        )
        
        if result['coins_stolen'] > 0:
            embed.add_field(
                name="💰 الغنائم",
                value=f"{result['coins_stolen']} عملة",
                inline=True
            )
        
        # Army status warnings
        warnings = []
        if result['attacker_remaining'] == 0:
            warnings.append(f"💀 تم تدمير جيش {attacker.display_name} بالكامل!")
        if result['target_remaining'] == 0:
            warnings.append(f"💀 تم تدمير جيش {target.display_name} بالكامل!")
        
        if warnings:
            embed.add_field(
                name="⚠️ تحديثات مهمة",
                value="\n".join(warnings),
                inline=False
            )
        
        embed.timestamp = datetime.utcnow()
        return embed
    
    def attack_notification_embed(self, attacker, result: Dict[str, Any]) -> discord.Embed:
        """Create attack notification embed for the target"""
        if result['attacker_wins']:
            embed = discord.Embed(
                title="🚨 تعرضت لهجوم!",
                description=f"**المهاجم:** {attacker.display_name}\n**النتيجة:** هزمك في المعركة",
                color=self.colors['error']
            )
        else:
            embed = discord.Embed(
                title="🛡️ صددت هجوماً!",
                description=f"**المهاجم:** {attacker.display_name}\n**النتيجة:** فشل في هزيمتك",
                color=self.colors['success']
            )
        
        embed.add_field(
            name="💀 خسائرك",
            value=f"{result['target_losses']} جندي",
            inline=True
        )
        
        embed.add_field(
            name="⚔️ جنودك المتبقون",
            value=f"{result['target_remaining']} جندي",
            inline=True
        )
        
        if result['coins_stolen'] > 0:
            embed.add_field(
                name="💸 العملات المسروقة",
                value=f"{result['coins_stolen']} عملة",
                inline=True
            )
        
        embed.timestamp = datetime.utcnow()
        return embed
    
    async def player_status_embed(self, player: Dict[str, Any], user) -> discord.Embed:
        """Create player status embed"""
        embed = discord.Embed(
            title=f"🎖️ حالة الجيش: {player['army_name']}",
            color=self.colors['info']
        )
        
        embed.set_author(name=user.display_name, icon_url=user.display_avatar.url)
        
        # Basic stats
        embed.add_field(
            name="⚔️ القوات",
            value=f"**الجنود:** {player['soldiers']}\n**الرتبة:** {self.get_rank(player['soldiers'])}",
            inline=True
        )
        
        embed.add_field(
            name="💰 الموارد",
            value=f"**العملات:** {player['coins']}\n**المستوى:** {self.get_player_level(player)}",
            inline=True
        )
        
        # Buildings and defenses
        buildings = []
        if player.get('base_level', 0) > 0:
            buildings.append(f"🏰 قاعدة مستوى {player['base_level']}")
        if player.get('walls', 0) > 0:
            buildings.append(f"🧱 {player['walls']} سور")
        if player.get('air_defense', 0) > 0:
            buildings.append(f"🛡️ {player['air_defense']} دفاع جوي")
        if player.get('missile_base', 0) > 0:
            buildings.append(f"🚀 {player['missile_base']} قاعدة صواريخ")
        
        if buildings:
            embed.add_field(
                name="🏗️ المباني والدفاعات",
                value="\n".join(buildings),
                inline=False
            )
        
        # Battle statistics
        total_battles = player.get('battles_won', 0) + player.get('battles_lost', 0)
        if total_battles > 0:
            win_rate = (player.get('battles_won', 0) / total_battles) * 100
            embed.add_field(
                name="📊 إحصائيات القتال",
                value=f"**المعارك:** {total_battles}\n**الانتصارات:** {player.get('battles_won', 0)}\n**الهزائم:** {player.get('battles_lost', 0)}\n**معدل النجاح:** {win_rate:.1f}%",
                inline=True
            )
        
        embed.add_field(
            name="📈 الأنشطة",
            value=f"**الغارات:** {player.get('total_raids', 0)}\n**الهجمات:** {player.get('total_attacks', 0)}",
            inline=True
        )
        
        # Army status
        army_status = self.get_army_status(player['soldiers'])
        embed.add_field(
            name="🎯 حالة الجيش",
            value=army_status,
            inline=False
        )
        
        embed.timestamp = datetime.utcnow()
        return embed
    
    async def leaderboard_embed(self, top_players: List[Dict[str, Any]], bot) -> discord.Embed:
        """Create leaderboard embed"""
        embed = discord.Embed(
            title="🏆 قائمة أقوى الجيوش",
            description="أقوى 10 جيوش في اللعبة",
            color=0xffd700
        )
        
        if not top_players:
            embed.add_field(
                name="📝 لا توجد بيانات",
                value="لم يبدأ أي لاعب اللعبة بعد!",
                inline=False
            )
            return embed
        
        leaderboard_text = []
        medals = ["🥇", "🥈", "🥉"] + ["🏅"] * 7
        
        for i, player in enumerate(top_players):
            medal = medals[i] if i < len(medals) else "🔸"
            rank = self.get_rank(player['soldiers'])
            
            leaderboard_text.append(
                f"{medal} **{player['army_name']}** ({player['username']})\n"
                f"   ⚔️ {player['soldiers']} جندي | 💰 {player['coins']} عملة | {rank}"
            )
        
        embed.add_field(
            name="👑 المتصدرون",
            value="\n\n".join(leaderboard_text),
            inline=False
        )
        
        embed.set_footer(text="يتم التحديث تلقائياً كل ساعة")
        embed.timestamp = datetime.utcnow()
        return embed
    
    def help_embed(self) -> discord.Embed:
        """Create help embed"""
        embed = discord.Embed(
            title="📖 دليل اللعبة العسكرية",
            description="دليل شامل لجميع أوامر اللعبة",
            color=self.colors['info']
        )
        
        # Slash commands
        embed.add_field(
            name="🎖️ أوامر أساسية (Slash Commands)",
            value="`/البدء [اسم الجيش]` - ابدأ لعبتك وأنشئ جيشك\n"
                  "`/حالة` - اعرض حالة جيشك\n"
                  "`/المتصدرين` - اعرض أقوى الجيوش\n"
                  "`/مساعدة` - عرض هذه المساعدة",
            inline=False
        )
        
        # Combat commands
        embed.add_field(
            name="⚔️ أوامر القتال (Slash Commands)",
            value="`/غارة [عدد الغارات]` - قم بغارة على الوحوش\n"
                  "`/هجوم [@اللاعب]` - هاجم لاعب آخر\n"
                  "`/قصف [@اللاعب]` - قصف لاعب بالصواريخ\n"
                  "`/شراء` - افتح المتجر لشراء الجنود والمعدات",
            inline=False
        )
        
        # Prefix commands
        embed.add_field(
            name="📝 أوامر البادئة (Prefix Commands)",
            value="`!جيش [اسم]` - إنشاء جيش\n"
                  "`!غارة [عدد]` - غارة على الوحوش\n"
                  "`!متجر` - فتح المتجر\n"
                  "`!حالة` - عرض حالة الجيش\n"
                  "`!هجوم [@لاعب]` - مهاجمة لاعب\n"
                  "`!أوامر` - قائمة الأوامر الكاملة",
            inline=False
        )
        
        # War games
        embed.add_field(
            name="🎯 المهام العسكرية",
            value="`!مبارزة [سيف/رمح/درع]` - مبارزة عسكرية\n"
                  "`!استطلاع` - مهمة استطلاع\n"
                  "`!قنص` - تدريب القناصة\n"
                  "`!تفكيك [لون]` - تفكيك القنابل\n"
                  "`!اقتحام` - اقتحام قواعد العدو",
            inline=False
        )
        
        # Advanced military operations
        embed.add_field(
            name="☢️ العمليات المتقدمة",
            value="`!تخصيب` - تخصيب اليورانيوم\n"
                  "`!نووية` - صنع أسلحة نووية\n"
                  "`!غزو [دولة]` - غزو الدول\n"
                  "`!طيران [عمل]` - إدارة القوات الجوية\n"
                  "`!بحرية [عمل]` - إدارة القوات البحرية",
            inline=False
        )
        
        # Infrastructure
        embed.add_field(
            name="🏭 البنية التحتية",
            value="`!مصنع [سلاح]` - تصنيع الأسلحة\n"
                  "`!قاعدة [عمل]` - إدارة القواعد العسكرية\n"
                  "`!تجارة [عمل]` - تجارة الأسلحة والموارد",
            inline=False
        )
        
        # Game mechanics
        embed.add_field(
            name="🎯 آليات اللعبة",
            value="• ابدأ بـ 100 جندي\n"
                  "• اجمع العملات من الغارات والمهام العسكرية\n"
                  "• اشتر المزيد من الجنود والمعدات\n"
                  "• ابن قاعدتك ودفاعاتك\n"
                  "• هاجم اللاعبين الآخرين أو ادافع عن قاعدتك",
            inline=False
        )
        
        # Tips
        embed.add_field(
            name="💡 نصائح عسكرية",
            value="• الأسوار تحميك من الهجمات البرية\n"
                  "• الدفاع الجوي يعترض الصواريخ\n"
                  "• لا تفقد جميع جنودك وإلا سيتم حذف جيشك\n"
                  "• هناك مهلة زمنية بين كل غارة وهجوم\n"
                  "• نفذ المهام العسكرية لكسب موارد إضافية\n"
                  "• بعض المهام محفوفة بالمخاطر لكن مكافآتها أكبر",
            inline=False
        )
        
        embed.set_footer(text="Dev by CodeX team 💻 | استمتع باللعبة وحظاً سعيداً!")
        embed.timestamp = datetime.utcnow()
        return embed
    
    def get_rank(self, soldiers: int) -> str:
        """Get military rank based on soldier count"""
        if soldiers >= 10000:
            return "مارشال 🎖️"
        elif soldiers >= 5000:
            return "جنرال ⭐"
        elif soldiers >= 2000:
            return "عقيد 🔰"
        elif soldiers >= 1000:
            return "رائد 🎯"
        elif soldiers >= 500:
            return "نقيب ⚡"
        elif soldiers >= 200:
            return "ملازم 🏅"
        elif soldiers >= 100:
            return "جندي أول 🔰"
        else:
            return "مجند 👤"
    
    def get_player_level(self, player: Dict[str, Any]) -> int:
        """Calculate player level based on various factors"""
        base_level = player.get('base_level', 0)
        soldiers = player['soldiers']
        total_raids = player.get('total_raids', 0)
        battles_won = player.get('battles_won', 0)
        
        # Simple level calculation
        level = (soldiers // 100) + (total_raids // 10) + (battles_won * 2) + base_level
        return max(1, level)
    
    def get_army_status(self, soldiers: int) -> str:
        """Get army status description"""
        if soldiers >= 5000:
            return "جيش عظيم لا يُقهر! 🏰"
        elif soldiers >= 2000:
            return "جيش قوي ومرهوب! ⚔️"
        elif soldiers >= 1000:
            return "جيش محترم وقادر! 🛡️"
        elif soldiers >= 500:
            return "قوة متنامية! 📈"
        elif soldiers >= 100:
            return "جيش في بداية الطريق 🌱"
        elif soldiers > 0:
            return "بحاجة لتعزيزات عاجلة! ⚠️"
        else:
            return "الجيش محطم! 💀"
