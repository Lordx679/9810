import random
import time
from typing import Dict, Optional, Any
from postgres_database import PostgresDatabase

class GameLogic:
    def __init__(self, db: PostgresDatabase):
        self.db = db
        
        # Game balance configuration
        self.RAID_COOLDOWN = 300  # 5 minutes
        self.RAID_BASE_COINS = 50
        self.RAID_BONUS_COINS = 100
        self.RAID_SOLDIER_LOSS_RATE = 0.15  # 15% chance to lose soldiers
        self.RAID_MAX_LOSS_PERCENT = 0.3  # Max 30% soldiers lost
        
        # Monster types for raids
        self.MONSTERS = [
            {"name": "ذئب بري", "difficulty": 1, "coins_min": 30, "coins_max": 80},
            {"name": "دب شرس", "difficulty": 2, "coins_min": 60, "coins_max": 120},
            {"name": "تنين صغير", "difficulty": 3, "coins_min": 100, "coins_max": 200},
            {"name": "عملاق الجبل", "difficulty": 4, "coins_min": 150, "coins_max": 300},
            {"name": "تنين النار", "difficulty": 5, "coins_min": 250, "coins_max": 500}
        ]
    
    async def check_raid_cooldown(self, user_id: int) -> int:
        """Check raid cooldown remaining time"""
        return await self.db.get_cooldown(user_id, "raid")
    
    async def set_raid_cooldown(self, user_id: int):
        """Set raid cooldown"""
        await self.db.set_cooldown(user_id, "raid", self.RAID_COOLDOWN)
    
    async def execute_raid(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Execute a raid against monsters"""
        try:
            player = await self.db.get_player(user_id)
            if not player or player['soldiers'] <= 0:
                return None
            
            # Select random monster based on army strength
            army_strength = player['soldiers']
            available_monsters = []
            
            for monster in self.MONSTERS:
                # Players can fight monsters up to their army size tier
                if army_strength >= monster['difficulty'] * 20:
                    available_monsters.append(monster)
            
            if not available_monsters:
                available_monsters = [self.MONSTERS[0]]  # At least fight wolves
            
            monster = random.choice(available_monsters)
            
            # Calculate battle outcome
            success_rate = min(0.9, army_strength / (monster['difficulty'] * 50))
            battle_won = random.random() < success_rate
            
            coins_earned = 0
            soldiers_lost = 0
            
            if battle_won:
                # Victory - earn coins
                coins_earned = random.randint(monster['coins_min'], monster['coins_max'])
                # Bonus for larger armies
                if army_strength > 200:
                    coins_earned = int(coins_earned * 1.5)
                
                # Small chance to lose soldiers even in victory
                if random.random() < 0.1:
                    soldiers_lost = random.randint(1, max(1, int(army_strength * 0.05)))
            else:
                # Defeat - lose soldiers, earn small coins
                loss_percent = random.uniform(0.1, self.RAID_MAX_LOSS_PERCENT)
                soldiers_lost = max(1, int(army_strength * loss_percent))
                coins_earned = random.randint(10, 30)  # Consolation coins
            
            # Update player data
            new_soldiers = max(0, player['soldiers'] - soldiers_lost)
            current_total_raids = player.get('total_raids', 0)
            current_successful_raids = player.get('successful_raids', 0)
            
            await self.db.update_player(
                user_id,
                soldiers=new_soldiers,
                coins=player['coins'] + coins_earned,
                total_raids=current_total_raids + 1,
                successful_raids=current_successful_raids + (1 if battle_won else 0)
            )
            
            # If army is completely destroyed, delete player
            if new_soldiers == 0:
                await self.db.delete_player(user_id)
            
            return {
                'monster': monster['name'],
                'battle_won': battle_won,
                'coins_earned': coins_earned,
                'soldiers_lost': soldiers_lost,
                'remaining_soldiers': new_soldiers
            }
            
        except Exception as e:
            print(f"Error in execute_raid: {e}")
            return None
    
    async def calculate_army_power(self, player: Dict[str, Any]) -> int:
        """Calculate total army power including equipment"""
        base_power = player['soldiers']
        
        # Base bonus
        if player.get('base_level', 0) > 0:
            base_power += player['base_level'] * 50
        
        # Walls bonus (defensive)
        if player.get('walls', 0) > 0:
            base_power += player['walls'] * 30
        
        # Air defense bonus
        if player.get('air_defense', 0) > 0:
            base_power += player['air_defense'] * 40
        
        return base_power
    
    async def generate_raid_event_text(self, result: Dict[str, Any]) -> str:
        """Generate descriptive text for raid events"""
        monster = result['monster']
        won = result['battle_won']
        coins = result['coins_earned']
        lost = result['soldiers_lost']
        
        if won:
            if lost > 0:
                return f"⚔️ انتصر جيشك على {monster} لكن فقد {lost} جندي في المعركة! حصلت على {coins} عملة"
            else:
                return f"🏆 انتصار ساحق! هزم جيشك {monster} دون خسائر وحصل على {coins} عملة"
        else:
            return f"💀 هُزم جيشك أمام {monster}! فقدت {lost} جندي لكن حصلت على {coins} عملة كغنائم"
    
    async def check_player_exists(self, user_id: int) -> bool:
        """Check if player exists and has active army"""
        player = await self.db.get_player(user_id)
        return player is not None and player['soldiers'] > 0
    
    async def format_time_remaining(self, seconds: int) -> str:
        """Format time remaining in Arabic"""
        if seconds <= 0:
            return "الآن"
        
        minutes = seconds // 60
        seconds = seconds % 60
        
        if minutes > 0:
            return f"{minutes} دقيقة و {seconds} ثانية"
        else:
            return f"{seconds} ثانية"
    
    def get_rank_by_soldiers(self, soldiers: int) -> str:
        """Get military rank based on soldier count"""
        if soldiers >= 10000:
            return "مارشال 🎖️"
        elif soldiers >= 5000:
            return "جنرال ⭐"
        elif soldiers >= 2000:
            return "عقيد 🔰"
        elif soldiers >= 1000:
            return "رائد 🎯"
        elif soldiers >= 500:
            return "نقيب ⚡"
        elif soldiers >= 200:
            return "ملازم 🏅"
        elif soldiers >= 100:
            return "جندي أول 🔰"
        else:
            return "مجند 👤"
    
    def get_army_status(self, soldiers: int) -> str:
        """Get army status description"""
        if soldiers >= 5000:
            return "جيش عظيم لا يُقهر! 🏰"
        elif soldiers >= 2000:
            return "جيش قوي ومرهوب! ⚔️"
        elif soldiers >= 1000:
            return "جيش محترم وقادر! 🛡️"
        elif soldiers >= 500:
            return "قوة متنامية! 📈"
        elif soldiers >= 100:
            return "جيش في بداية الطريق 🌱"
        elif soldiers > 0:
            return "بحاجة لتعزيزات عاجلة! ⚠️"
        else:
            return "الجيش محطم! 💀"
