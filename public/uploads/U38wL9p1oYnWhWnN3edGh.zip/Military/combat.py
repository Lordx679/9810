import discord
import random
import time
from typing import Dict, List, Optional, Any, Tuple
from postgres_database import PostgresDatabase

class Combat:
    def __init__(self, db: PostgresDatabase):
        self.db = db
        
        # Combat configuration
        self.ATTACK_COOLDOWN = 600  # 10 minutes
        self.MISSILE_COOLDOWN = 900  # 15 minutes
        
        # Missile data
        self.MISSILE_DATA = {
            'صاروخ مدمر': {'damage': 100, 'target': 'walls', 'description': 'يدمر الأسوار'},
            'صاروخ باليستي': {'damage': 200, 'target': 'base', 'description': 'يدمر المباني والجنود'},
            'صاروخ نووي': {'damage': 500, 'target': 'all', 'description': 'دمار شامل'}
        }
    
    async def check_attack_cooldown(self, user_id: int) -> int:
        """Check attack cooldown remaining time"""
        return await self.db.get_cooldown(user_id, "attack")
    
    async def check_missile_cooldown(self, user_id: int) -> int:
        """Check missile attack cooldown remaining time"""
        return await self.db.get_cooldown(user_id, "missile")
    
    async def execute_attack(self, attacker_id: int, target_id: int) -> Optional[Dict[str, Any]]:
        """Execute ground attack between players"""
        try:
            attacker = await self.db.get_player(attacker_id)
            target = await self.db.get_player(target_id)
            
            if not attacker or not target:
                return None
            
            # Calculate army strengths
            attacker_power = await self.calculate_army_power(attacker)
            target_power = await self.calculate_army_power(target)
            
            # Battle calculation
            attacker_advantage = attacker_power / (attacker_power + target_power)
            battle_result = random.random()
            
            attacker_wins = battle_result < attacker_advantage
            
            # Calculate casualties
            if attacker_wins:
                # Attacker wins
                attacker_losses = random.randint(
                    int(attacker['soldiers'] * 0.05),
                    int(attacker['soldiers'] * 0.2)
                )
                target_losses = random.randint(
                    int(target['soldiers'] * 0.3),
                    int(target['soldiers'] * 0.6)
                )
                
                # Coin theft
                coins_stolen = min(target['coins'], random.randint(100, 500))
                
            else:
                # Defender wins
                attacker_losses = random.randint(
                    int(attacker['soldiers'] * 0.4),
                    int(attacker['soldiers'] * 0.7)
                )
                target_losses = random.randint(
                    int(target['soldiers'] * 0.1),
                    int(target['soldiers'] * 0.3)
                )
                
                coins_stolen = 0
            
            # Apply casualties
            new_attacker_soldiers = max(0, attacker['soldiers'] - attacker_losses)
            new_target_soldiers = max(0, target['soldiers'] - target_losses)
            
            # Update database
            await self.db.update_player(
                attacker_id,
                soldiers=new_attacker_soldiers,
                coins=attacker['coins'] + coins_stolen,
                total_attacks=attacker['total_attacks'] + 1,
                battles_won=attacker['battles_won'] + (1 if attacker_wins else 0),
                battles_lost=attacker['battles_lost'] + (0 if attacker_wins else 1)
            )
            
            await self.db.update_player(
                target_id,
                soldiers=new_target_soldiers,
                coins=max(0, target['coins'] - coins_stolen),
                battles_won=target['battles_won'] + (0 if attacker_wins else 1),
                battles_lost=target['battles_lost'] + (1 if attacker_wins else 0)
            )
            
            # Set cooldown
            await self.db.set_cooldown(attacker_id, "attack", self.ATTACK_COOLDOWN)
            
            # Record battle
            await self.db.add_battle_record(
                attacker_id, target_id, "ground_attack",
                "victory" if attacker_wins else "defeat",
                target_losses, coins_stolen
            )
            
            # Delete players if armies destroyed
            if new_attacker_soldiers == 0:
                await self.db.delete_player(attacker_id)
            if new_target_soldiers == 0:
                await self.db.delete_player(target_id)
            
            return {
                'attacker_wins': attacker_wins,
                'attacker_losses': attacker_losses,
                'target_losses': target_losses,
                'coins_stolen': coins_stolen,
                'attacker_remaining': new_attacker_soldiers,
                'target_remaining': new_target_soldiers
            }
            
        except Exception as e:
            print(f"Error in execute_attack: {e}")
            return None
    
    async def execute_missile_attack(self, attacker_id: int, target_id: int, missile_name: str) -> Optional[Dict[str, Any]]:
        """Execute missile attack"""
        try:
            attacker = await self.db.get_player(attacker_id)
            target = await self.db.get_player(target_id)
            
            if not attacker or not target:
                return None
            
            # Check if attacker has the missile
            if not await self.db.use_item(attacker_id, 'missiles', missile_name, 1):
                return {'success': False, 'message': 'ليس لديك هذا الصاروخ!'}
            
            missile_data = self.MISSILE_DATA.get(missile_name)
            if not missile_data:
                return {'success': False, 'message': 'نوع صاروخ غير صحيح!'}
            
            # Check for air defense
            intercepted = False
            if target.get('air_defense', 0) > 0 and target.get('air_defense_ammo', 0) > 0:
                intercept_chance = min(0.8, target['air_defense'] * 0.2)
                if random.random() < intercept_chance:
                    intercepted = True
                    # Use air defense ammo
                    await self.db.update_player(
                        target_id,
                        air_defense_ammo=target['air_defense_ammo'] - 1
                    )
            
            if intercepted:
                # Set cooldown even if intercepted
                await self.db.set_cooldown(attacker_id, "missile", self.MISSILE_COOLDOWN)
                
                return {
                    'success': True,
                    'intercepted': True,
                    'message': f'تم اعتراض {missile_name} بواسطة الدفاع الجوي!'
                }
            
            # Calculate damage
            damage = missile_data['damage']
            target_type = missile_data['target']
            
            walls_destroyed = 0
            soldiers_killed = 0
            buildings_destroyed = 0
            
            if target_type == 'walls' or target_type == 'all':
                # Destroy walls
                walls_destroyed = min(target.get('walls', 0), damage // 50)
                damage -= walls_destroyed * 50
            
            if target_type == 'base' or target_type == 'all':
                # Damage buildings
                if target.get('base_level', 0) > 0 and damage >= 100:
                    buildings_destroyed = 1
                    damage -= 100
                
                # Damage air defense
                if target.get('air_defense', 0) > 0 and damage >= 80:
                    buildings_destroyed += target['air_defense']
                    damage -= target['air_defense'] * 80
                    await self.db.update_player(target_id, air_defense=0)
            
            if damage > 0:
                # Remaining damage kills soldiers
                soldiers_killed = min(target['soldiers'], damage // 2)
            
            # Apply damage
            updates = {}
            if walls_destroyed > 0:
                updates['walls'] = max(0, target.get('walls', 0) - walls_destroyed)
            if soldiers_killed > 0:
                updates['soldiers'] = max(0, target['soldiers'] - soldiers_killed)
            if buildings_destroyed > 0 and target.get('base_level', 0) > 0:
                updates['base_level'] = 0
            
            await self.db.update_player(target_id, **updates)
            
            # Set cooldown
            await self.db.set_cooldown(attacker_id, "missile", self.MISSILE_COOLDOWN)
            
            # Record battle
            await self.db.add_battle_record(
                attacker_id, target_id, "missile_attack", "success",
                soldiers_killed, 0,
                f"Missile: {missile_name}, Walls: {walls_destroyed}, Buildings: {buildings_destroyed}"
            )
            
            # Check if target army is destroyed
            remaining_soldiers = target['soldiers'] - soldiers_killed
            if remaining_soldiers <= 0:
                await self.db.delete_player(target_id)
            
            return {
                'success': True,
                'intercepted': False,
                'missile_name': missile_name,
                'walls_destroyed': walls_destroyed,
                'soldiers_killed': soldiers_killed,
                'buildings_destroyed': buildings_destroyed,
                'remaining_soldiers': remaining_soldiers
            }
            
        except Exception as e:
            print(f"Error in execute_missile_attack: {e}")
            return {'success': False, 'message': 'حدث خطأ أثناء القصف!'}
    
    async def calculate_army_power(self, player: Dict[str, Any]) -> int:
        """Calculate total army power"""
        base_power = player['soldiers']
        
        # Base multiplier
        if player.get('base_level', 0) > 0:
            base_power *= (1 + player['base_level'] * 0.2)
        
        # Defensive bonus when defending
        if player.get('walls', 0) > 0:
            base_power += player['walls'] * 20
        
        return int(base_power)
    
    async def create_missile_menu(self, attacker: Dict[str, Any], target: Dict[str, Any], 
                                missiles: List[Dict[str, Any]], target_user: discord.Member) -> Tuple[discord.Embed, discord.ui.View]:
        """Create missile selection menu"""
        embed = discord.Embed(
            title="💥 القصف الصاروخي",
            color=0xff0000
        )
        
        # Add target defenses info
        defense_info = []
        if target.get('walls', 0) > 0:
            defense_info.append(f"🏰 الأسوار: {target['walls']}")
        if target.get('air_defense', 0) > 0:
            defense_info.append(f"🛡️ دفاع جوي: {target['air_defense']}")
            defense_info.append(f"📦 ذخيرة: {target.get('air_defense_ammo', 0)}")
        
        if defense_info:
            embed.add_field(
                name="دفاعات الهدف",
                value="\n".join(defense_info),
                inline=False
            )
        
        # Show missile selection interface
        embed.add_field(
            name="🚀 اختر الصاروخ",
            value=f"**الهدف:** {target_user.display_name}\n**جيش الهدف:** {target['army_name']}\n\nاختر نوع الصاروخ من الأزرار أدناه:",
            inline=False
        )
        
        # Add missile info to embed
        missile_list = []
        for missile in missiles:
            missile_name = missile['name']
            quantity = missile['quantity']
            missile_info = self.MISSILE_DATA.get(missile_name, {})
            damage = missile_info.get('damage', 0)
            missile_list.append(f"🚀 **{missile_name}**\n   الضرر: {damage}\n   المتوفر: {quantity}")
        
        if missile_list:
            embed.add_field(
                name="الصواريخ المتاحة:",
                value="\n\n".join(missile_list),
                inline=False
            )
        
        view = MissileView(self, attacker['user_id'], target_user.id, missiles)
        return embed, view

class MissileView(discord.ui.View):
    def __init__(self, combat: Combat, attacker_id: int, target_id: int, missiles: List[Dict[str, Any]]):
        super().__init__(timeout=300)
        self.combat = combat
        self.attacker_id = attacker_id
        self.target_id = target_id
        
        # Create buttons for each missile type with proper layout
        for i, missile in enumerate(missiles[:4]):  # Max 4 missiles
            missile_name = missile['name']
            quantity = missile['quantity']
            missile_info = self.combat.MISSILE_DATA.get(missile_name, {})
            
            # Create button with missile info
            button = discord.ui.Button(
                label=f"{missile_name} ({quantity})",
                style=discord.ButtonStyle.danger,
                custom_id=f"missile_{i}",
                row=i // 2  # 2 buttons per row
            )
            button.callback = self.create_missile_callback(missile_name)
            self.add_item(button)
        
        # Add back/cancel button
        back_button = discord.ui.Button(
            label="🔄 العودة",
            style=discord.ButtonStyle.secondary,
            custom_id="back",
            row=2
        )
        back_button.callback = self.back_callback
        self.add_item(back_button)
    
    async def back_callback(self, interaction: discord.Interaction):
        """Handle back button"""
        embed = discord.Embed(
            title="❌ تم إلغاء القصف",
            description="تم إلغاء عملية القصف الصاروخي",
            color=0x808080
        )
        await interaction.response.edit_message(embed=embed, view=None)
    
    def create_missile_callback(self, missile_name: str):
        async def missile_callback(interaction: discord.Interaction):
            if interaction.user.id != self.attacker_id:
                await interaction.response.send_message("هذا ليس صاروخك!", ephemeral=True)
                return
            
            # Check cooldown
            cooldown_remaining = await self.combat.check_missile_cooldown(self.attacker_id)
            if cooldown_remaining > 0:
                embed = discord.Embed(
                    title="انتظر قليلاً! ⏰",
                    description=f"يمكنك إطلاق صاروخ آخر خلال {cooldown_remaining} ثانية",
                    color=0xff0000
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            await interaction.response.defer()
            
            # Execute missile attack
            result = await self.combat.execute_missile_attack(
                self.attacker_id, self.target_id, missile_name
            )
            
            if result and result['success']:
                if result.get('intercepted'):
                    embed = discord.Embed(
                        title="🛡️ تم اعتراض الصاروخ!",
                        description=result['message'],
                        color=0xffa500
                    )
                else:
                    embed = discord.Embed(
                        title="💥 إصابة مباشرة!",
                        description=self.format_missile_result(result),
                        color=0xff0000
                    )
                    
                    # Notify target
                    try:
                        target_user = interaction.client.get_user(self.target_id)
                        if target_user:
                            notify_embed = discord.Embed(
                                title="🚨 تعرضت لقصف صاروخي!",
                                description=f"**المهاجم:** {interaction.user.display_name}\n{self.format_missile_result(result)}",
                                color=0xff0000
                            )
                            await target_user.send(embed=notify_embed)
                    except:
                        pass
            else:
                embed = discord.Embed(
                    title="❌ فشل القصف",
                    description=result.get('message', 'حدث خطأ غير متوقع'),
                    color=0xff0000
                )
            
            await interaction.followup.send(embed=embed)
        
        return missile_callback
    
    def format_missile_result(self, result: Dict[str, Any]) -> str:
        """Format missile attack result"""
        lines = [f"**الصاروخ:** {result['missile_name']}"]
        
        if result.get('walls_destroyed', 0) > 0:
            lines.append(f"🏰 تم تدمير {result['walls_destroyed']} سور")
        
        if result.get('soldiers_killed', 0) > 0:
            lines.append(f"💀 قُتل {result['soldiers_killed']} جندي")
        
        if result.get('buildings_destroyed', 0) > 0:
            lines.append(f"🏗️ تم تدمير {result['buildings_destroyed']} مبنى")
        
        lines.append(f"⚔️ الجنود المتبقون: {result.get('remaining_soldiers', 0)}")
        
        return "\n".join(lines)
