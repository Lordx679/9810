import aiosqlite
import json
import time
from typing import Dict, List, Optional, Any

class Database:
    def __init__(self, db_path: str = "game.db"):
        self.db_path = db_path
    
    async def initialize(self):
        """Initialize database tables"""
        async with aiosqlite.connect(self.db_path) as db:
            # Players table
            await db.execute('''
                CREATE TABLE IF NOT EXISTS players (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT NOT NULL,
                    army_name TEXT NOT NULL,
                    soldiers INTEGER DEFAULT 100,
                    coins INTEGER DEFAULT 0,
                    base_level INTEGER DEFAULT 0,
                    walls INTEGER DEFAULT 0,
                    air_defense INTEGER DEFAULT 0,
                    air_defense_ammo INTEGER DEFAULT 0,
                    missile_base INTEGER DEFAULT 0,
                    created_at INTEGER DEFAULT 0,
                    last_raid INTEGER DEFAULT 0,
                    last_attack INTEGER DEFAULT 0,
                    total_raids INTEGER DEFAULT 0,
                    total_attacks INTEGER DEFAULT 0,
                    battles_won INTEGER DEFAULT 0,
                    battles_lost INTEGER DEFAULT 0,
                    xp INTEGER DEFAULT 0
                )
            ''')
            
            # Player inventory table
            await db.execute('''
                CREATE TABLE IF NOT EXISTS player_inventory (
                    user_id INTEGER,
                    item_type TEXT,
                    item_name TEXT,
                    quantity INTEGER DEFAULT 0,
                    PRIMARY KEY (user_id, item_type, item_name),
                    FOREIGN KEY (user_id) REFERENCES players (user_id)
                )
            ''')
            
            # Cooldowns table
            await db.execute('''
                CREATE TABLE IF NOT EXISTS cooldowns (
                    user_id INTEGER,
                    action_type TEXT,
                    expires_at INTEGER,
                    PRIMARY KEY (user_id, action_type)
                )
            ''')
            
            # Battle history table
            await db.execute('''
                CREATE TABLE IF NOT EXISTS battle_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    attacker_id INTEGER,
                    target_id INTEGER,
                    battle_type TEXT,
                    result TEXT,
                    damage_dealt INTEGER,
                    coins_stolen INTEGER,
                    timestamp INTEGER,
                    details TEXT
                )
            ''')
            
            await db.commit()
            
            # Add XP column if it doesn't exist (for existing databases)
            try:
                await db.execute('ALTER TABLE players ADD COLUMN xp INTEGER DEFAULT 0')
                await db.commit()
            except:
                pass  # Column already exists
    
    async def create_player(self, user_id: int, username: str, army_name: str) -> bool:
        """Create a new player"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute('''
                    INSERT INTO players (user_id, username, army_name, created_at)
                    VALUES (?, ?, ?, ?)
                ''', (user_id, username, army_name, int(time.time())))
                await db.commit()
                return True
        except Exception as e:
            print(f"Error creating player: {e}")
            return False
    
    async def get_player(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Get player data"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                db.row_factory = aiosqlite.Row
                async with db.execute('''
                    SELECT * FROM players WHERE user_id = ?
                ''', (user_id,)) as cursor:
                    row = await cursor.fetchone()
                    return dict(row) if row else None
        except Exception as e:
            print(f"Error getting player: {e}")
            return None
    
    async def update_player(self, user_id: int, **kwargs) -> bool:
        """Update player data"""
        try:
            if not kwargs:
                return True
                
            fields = []
            values = []
            for key, value in kwargs.items():
                fields.append(f"{key} = ?")
                values.append(value)
            values.append(user_id)
            
            query = f"UPDATE players SET {', '.join(fields)} WHERE user_id = ?"
            
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute(query, values)
                await db.commit()
                return True
        except Exception as e:
            print(f"Error updating player: {e}")
            return False
    
    async def add_coins(self, user_id: int, amount: int) -> bool:
        """Add coins to player"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute('''
                    UPDATE players SET coins = coins + ? WHERE user_id = ?
                ''', (amount, user_id))
                await db.commit()
                return True
        except Exception as e:
            print(f"Error adding coins: {e}")
            return False
    
    async def spend_coins(self, user_id: int, amount: int) -> bool:
        """Spend coins if player has enough"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                # Check if player has enough coins
                async with db.execute('''
                    SELECT coins FROM players WHERE user_id = ?
                ''', (user_id,)) as cursor:
                    row = await cursor.fetchone()
                    if not row or row[0] < amount:
                        return False
                
                # Spend coins
                await db.execute('''
                    UPDATE players SET coins = coins - ? WHERE user_id = ?
                ''', (amount, user_id))
                await db.commit()
                return True
        except Exception as e:
            print(f"Error spending coins: {e}")
            return False
    
    async def get_player_inventory(self, user_id: int) -> Dict[str, Dict[str, int]]:
        """Get player's inventory"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                db.row_factory = aiosqlite.Row
                async with db.execute('''
                    SELECT item_type, item_name, quantity FROM player_inventory 
                    WHERE user_id = ? AND quantity > 0
                ''', (user_id,)) as cursor:
                    rows = await cursor.fetchall()
                    
                    inventory = {}
                    for row in rows:
                        if row['item_type'] not in inventory:
                            inventory[row['item_type']] = {}
                        inventory[row['item_type']][row['item_name']] = row['quantity']
                    
                    return inventory
        except Exception as e:
            print(f"Error getting inventory: {e}")
            return {}
    
    async def add_item(self, user_id: int, item_type: str, item_name: str, quantity: int) -> bool:
        """Add item to player's inventory"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute('''
                    INSERT OR REPLACE INTO player_inventory (user_id, item_type, item_name, quantity)
                    VALUES (?, ?, ?, COALESCE((SELECT quantity FROM player_inventory 
                        WHERE user_id = ? AND item_type = ? AND item_name = ?), 0) + ?)
                ''', (user_id, item_type, item_name, user_id, item_type, item_name, quantity))
                await db.commit()
                return True
        except Exception as e:
            print(f"Error adding item: {e}")
            return False
    
    async def use_item(self, user_id: int, item_type: str, item_name: str, quantity: int = 1) -> bool:
        """Use/consume item from inventory"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                # Check if player has enough items
                async with db.execute('''
                    SELECT quantity FROM player_inventory 
                    WHERE user_id = ? AND item_type = ? AND item_name = ?
                ''', (user_id, item_type, item_name)) as cursor:
                    row = await cursor.fetchone()
                    if not row or row[0] < quantity:
                        return False
                
                # Use items
                await db.execute('''
                    UPDATE player_inventory SET quantity = quantity - ?
                    WHERE user_id = ? AND item_type = ? AND item_name = ?
                ''', (quantity, user_id, item_type, item_name))
                await db.commit()
                return True
        except Exception as e:
            print(f"Error using item: {e}")
            return False
    
    async def get_player_missiles(self, user_id: int) -> List[Dict[str, Any]]:
        """Get player's missiles"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                db.row_factory = aiosqlite.Row
                async with db.execute('''
                    SELECT item_name, quantity FROM player_inventory 
                    WHERE user_id = ? AND item_type = 'missiles' AND quantity > 0
                ''', (user_id,)) as cursor:
                    rows = await cursor.fetchall()
                    return [dict(row) for row in rows]
        except Exception as e:
            print(f"Error getting missiles: {e}")
            return []
    
    async def set_cooldown(self, user_id: int, action_type: str, duration: int):
        """Set cooldown for an action"""
        try:
            expires_at = int(time.time()) + duration
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute('''
                    INSERT OR REPLACE INTO cooldowns (user_id, action_type, expires_at)
                    VALUES (?, ?, ?)
                ''', (user_id, action_type, expires_at))
                await db.commit()
        except Exception as e:
            print(f"Error setting cooldown: {e}")
    
    async def get_cooldown(self, user_id: int, action_type: str) -> int:
        """Get remaining cooldown time in seconds"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                async with db.execute('''
                    SELECT expires_at FROM cooldowns 
                    WHERE user_id = ? AND action_type = ?
                ''', (user_id, action_type)) as cursor:
                    row = await cursor.fetchone()
                    if row:
                        remaining = row[0] - int(time.time())
                        return max(0, remaining)
                    return 0
        except Exception as e:
            print(f"Error getting cooldown: {e}")
            return 0
    
    async def cleanup_expired_cooldowns(self):
        """Remove expired cooldowns"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute('''
                    DELETE FROM cooldowns WHERE expires_at < ?
                ''', (int(time.time()),))
                await db.commit()
        except Exception as e:
            print(f"Error cleaning cooldowns: {e}")
    
    async def add_battle_record(self, attacker_id: int, target_id: int, battle_type: str, 
                              result: str, damage_dealt: int, coins_stolen: int, details: str = ""):
        """Add battle record to history"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute('''
                    INSERT INTO battle_history 
                    (attacker_id, target_id, battle_type, result, damage_dealt, coins_stolen, timestamp, details)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (attacker_id, target_id, battle_type, result, damage_dealt, coins_stolen, int(time.time()), details))
                await db.commit()
        except Exception as e:
            print(f"Error adding battle record: {e}")
    
    async def get_leaderboard(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get top players leaderboard"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                db.row_factory = aiosqlite.Row
                async with db.execute('''
                    SELECT username, army_name, soldiers, coins, battles_won, battles_lost
                    FROM players 
                    WHERE soldiers > 0
                    ORDER BY soldiers DESC, coins DESC
                    LIMIT ?
                ''', (limit,)) as cursor:
                    rows = await cursor.fetchall()
                    return [dict(row) for row in rows]
        except Exception as e:
            print(f"Error getting leaderboard: {e}")
            return []
    
    async def delete_player(self, user_id: int) -> bool:
        """Delete a player (when army is destroyed)"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute('DELETE FROM players WHERE user_id = ?', (user_id,))
                await db.execute('DELETE FROM player_inventory WHERE user_id = ?', (user_id,))
                await db.execute('DELETE FROM cooldowns WHERE user_id = ?', (user_id,))
                await db.commit()
                return True
        except Exception as e:
            print(f"Error deleting player: {e}")
            return False
    
    async def add_xp(self, user_id: int, amount: int) -> bool:
        """Add XP to player"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute(
                    'UPDATE players SET xp = xp + ? WHERE user_id = ?',
                    (amount, user_id)
                )
                await db.commit()
                return True
        except Exception as e:
            print(f"Error adding XP: {e}")
            return False
    
    async def get_player_level(self, user_id: int) -> int:
        """Get player's current level"""
        try:
            player = await self.get_player(user_id)
            if not player:
                return 1
            from config import Config
            config = Config()
            return config.calculate_level(player.get('xp', 0))
        except Exception as e:
            print(f"Error getting player level: {e}")
            return 1
