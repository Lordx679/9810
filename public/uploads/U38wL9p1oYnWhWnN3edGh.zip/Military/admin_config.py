# Admin Configuration File
# تكوين المشرفين - Admin Configuration

# Add your Discord User IDs here to get admin access
# أضف معرفات Discord الخاصة بك هنا للحصول على صلاحيات الإدارة

ADMIN_USER_IDS = [
    # Replace with your actual Discord user IDs
    # استبدل بمعرفات Discord الحقيقية الخاصة بك
    
    # Example format:
    # 123456789012345678,  # Your Discord ID
    # 987654321098765432,  # Another admin ID
    
    # To get your Discord ID:
    # 1. Enable Developer Mode in Discord Settings
    # 2. Right-click on your username
    # 3. Select "Copy ID"
    
    # للحصول على معرف Discord الخاص بك:
    # 1. فعل وضع المطور في إعدادات Discord
    # 2. انقر بالزر الأيمن على اسم المستخدم الخاص بك
    # 3. اختر "نسخ المعرف"
]

# Bot Owner ID (highest permissions)
# معرف مالك البوت (أعلى صلاحيات)
BOT_OWNER_ID = 394912002843344898  # Set this to your main Discord ID / ضع هنا معرف Discord الرئيسي

# Admin Commands Help
# مساعدة الأوامر الإدارية
ADMIN_COMMANDS_INFO = {
    "منح_عملات": "!منح_عملات @لاعب [مبلغ] - منح عملات للاعب",
    "منح_جنود": "!منح_جنود @لاعب [عدد] - منح جنود للاعب", 
    "منح_أسلحة": "!منح_أسلحة @لاعب [نوع] [اسم] [كمية] - منح أسلحة للاعب",
    "حذف_لاعب": "!حذف_لاعب @لاعب - حذف لاعب بالكامل",
    "تعديل_قاعدة": "!تعديل_قاعدة @لاعب [مستوى] - تعديل مستوى قاعدة اللاعب",
    "معلومات_لاعب": "!معلومات_لاعب @لاعب - عرض معلومات مفصلة عن اللاعب",
    "إزالة_تبريد": "!إزالة_تبريد @لاعب [نوع] - إزالة تبريد محدد أو جميع التبريدات",
    "أوامر_إدارية": "!أوامر_إدارية - عرض جميع الأوامر الإدارية"
}

# Weapon types for admin commands
# أنواع الأسلحة للأوامر الإدارية
WEAPON_TYPES = {
    "missiles": "صواريخ",
    "aircraft": "طائرات", 
    "ships": "سفن",
    "nuclear": "نووي",
    "weapons": "أسلحة",
    "defense": "دفاع"
}

# Common weapon names
# أسماء الأسلحة الشائعة
COMMON_WEAPONS = {
    "missiles": [
        "صاروخ مدمر",
        "صاروخ باليستي", 
        "صاروخ نووي"
    ],
    "aircraft": [
        "مقاتلة F-16",
        "مقاتلة ميج-29",
        "قاذفة قنابل",
        "طائرة استطلاع"
    ],
    "ships": [
        "مدمرة",
        "غواصة",
        "حاملة طائرات",
        "زورق دورية"
    ],
    "nuclear": [
        "يورانيوم مخصب",
        "قنبلة نووية تكتيكية",
        "قنبلة نووية استراتيجية",
        "رأس نووي باليستي"
    ]
}