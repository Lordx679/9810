import asyncio
import motor.motor_asyncio
from typing import Optional, Dict, Any, List
import datetime

class MongoDatabase:
    def __init__(self, connection_string: str):
        self.connection_string = connection_string
        self.client = None
        self.db = None
        
    async def initialize(self):
        """Initialize MongoDB connection"""
        try:
            self.client = motor.motor_asyncio.AsyncIOMotorClient(self.connection_string)
            self.db = self.client.war_game_bot
            
            # Test connection
            await self.client.admin.command('ping')
            print("✓ MongoDB connected successfully")
            
            # Create indexes for better performance
            await self.create_indexes()
            
        except Exception as e:
            print(f"❌ MongoDB connection failed: {e}")
            raise
    
    async def create_indexes(self):
        """Create database indexes for better performance"""
        try:
            # Players collection indexes
            await self.db.players.create_index("user_id", unique=True)
            await self.db.players.create_index("army_name")
            await self.db.players.create_index("soldiers")
            
            # Inventory collection indexes
            await self.db.inventory.create_index([("user_id", 1), ("item_type", 1)])
            
            # Cooldowns collection indexes
            await self.db.cooldowns.create_index([("user_id", 1), ("action_type", 1)])
            await self.db.cooldowns.create_index("expires_at")
            
            # Battle records collection indexes
            await self.db.battle_records.create_index("attacker_id")
            await self.db.battle_records.create_index("target_id")
            await self.db.battle_records.create_index("timestamp")
            
            print("✓ Database indexes created")
            
        except Exception as e:
            print(f"Warning: Could not create indexes: {e}")
    
    async def create_player(self, user_id: int, username: str, army_name: str) -> bool:
        """Create a new player"""
        try:
            player_data = {
                "user_id": user_id,
                "username": username,
                "army_name": army_name,
                "soldiers": 100,
                "coins": 1000,
                "xp": 0,
                "level": 1,
                "base_level": 1,
                "walls": 0,
                "air_defense": 0,
                "air_defense_ammo": 0,
                "created_at": datetime.datetime.utcnow(),
                "last_active": datetime.datetime.utcnow()
            }
            
            await self.db.players.insert_one(player_data)
            return True
            
        except Exception as e:
            print(f"Error creating player: {e}")
            return False
    
    async def get_player(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Get player data"""
        try:
            player = await self.db.players.find_one({"user_id": user_id})
            if player:
                # Update last active time
                await self.db.players.update_one(
                    {"user_id": user_id},
                    {"$set": {"last_active": datetime.datetime.utcnow()}}
                )
            return player
            
        except Exception as e:
            print(f"Error getting player: {e}")
            return None
    
    async def update_player(self, user_id: int, **kwargs) -> bool:
        """Update player data"""
        try:
            if not kwargs:
                return True
                
            update_data = kwargs.copy()
            update_data["last_active"] = datetime.datetime.utcnow()
            
            result = await self.db.players.update_one(
                {"user_id": user_id},
                {"$set": update_data}
            )
            
            return result.modified_count > 0
            
        except Exception as e:
            print(f"Error updating player: {e}")
            return False
    
    async def add_coins(self, user_id: int, amount: int) -> bool:
        """Add coins to player"""
        try:
            result = await self.db.players.update_one(
                {"user_id": user_id},
                {
                    "$inc": {"coins": amount},
                    "$set": {"last_active": datetime.datetime.utcnow()}
                }
            )
            
            return result.modified_count > 0
            
        except Exception as e:
            print(f"Error adding coins: {e}")
            return False
    
    async def spend_coins(self, user_id: int, amount: int) -> bool:
        """Spend coins if player has enough"""
        try:
            # Check if player has enough coins
            player = await self.get_player(user_id)
            if not player or player.get("coins", 0) < amount:
                return False
            
            result = await self.db.players.update_one(
                {"user_id": user_id, "coins": {"$gte": amount}},
                {
                    "$inc": {"coins": -amount},
                    "$set": {"last_active": datetime.datetime.utcnow()}
                }
            )
            
            return result.modified_count > 0
            
        except Exception as e:
            print(f"Error spending coins: {e}")
            return False
    
    async def get_player_inventory(self, user_id: int) -> Dict[str, Dict[str, int]]:
        """Get player's inventory"""
        try:
            inventory = {}
            cursor = self.db.inventory.find({"user_id": user_id})
            
            async for item in cursor:
                item_type = item["item_type"]
                item_name = item["item_name"]
                quantity = item["quantity"]
                
                if item_type not in inventory:
                    inventory[item_type] = {}
                
                inventory[item_type][item_name] = quantity
            
            return inventory
            
        except Exception as e:
            print(f"Error getting inventory: {e}")
            return {}
    
    async def add_item(self, user_id: int, item_type: str, item_name: str, quantity: int) -> bool:
        """Add item to player's inventory"""
        try:
            # Check if item already exists
            existing_item = await self.db.inventory.find_one({
                "user_id": user_id,
                "item_type": item_type,
                "item_name": item_name
            })
            
            if existing_item:
                # Update existing item
                result = await self.db.inventory.update_one(
                    {"user_id": user_id, "item_type": item_type, "item_name": item_name},
                    {"$inc": {"quantity": quantity}}
                )
            else:
                # Create new item
                result = await self.db.inventory.insert_one({
                    "user_id": user_id,
                    "item_type": item_type,
                    "item_name": item_name,
                    "quantity": quantity,
                    "added_at": datetime.datetime.utcnow()
                })
            
            return True
            
        except Exception as e:
            print(f"Error adding item: {e}")
            return False
    
    async def use_item(self, user_id: int, item_type: str, item_name: str, quantity: int = 1) -> bool:
        """Use/consume item from inventory"""
        try:
            # Check if player has enough items
            existing_item = await self.db.inventory.find_one({
                "user_id": user_id,
                "item_type": item_type,
                "item_name": item_name
            })
            
            if not existing_item or existing_item.get("quantity", 0) < quantity:
                return False
            
            new_quantity = existing_item["quantity"] - quantity
            
            if new_quantity <= 0:
                # Remove item if quantity reaches 0
                await self.db.inventory.delete_one({
                    "user_id": user_id,
                    "item_type": item_type,
                    "item_name": item_name
                })
            else:
                # Update quantity
                await self.db.inventory.update_one(
                    {"user_id": user_id, "item_type": item_type, "item_name": item_name},
                    {"$set": {"quantity": new_quantity}}
                )
            
            return True
            
        except Exception as e:
            print(f"Error using item: {e}")
            return False
    
    async def get_player_missiles(self, user_id: int) -> List[Dict[str, Any]]:
        """Get player's missiles"""
        try:
            missiles = []
            cursor = self.db.inventory.find({
                "user_id": user_id,
                "item_type": "missiles"
            })
            
            async for missile in cursor:
                missiles.append({
                    "name": missile["item_name"],
                    "quantity": missile["quantity"]
                })
            
            return missiles
            
        except Exception as e:
            print(f"Error getting missiles: {e}")
            return []
    
    async def set_cooldown(self, user_id: int, action_type: str, duration: int):
        """Set cooldown for an action"""
        try:
            expires_at = datetime.datetime.utcnow() + datetime.timedelta(seconds=duration)
            
            await self.db.cooldowns.update_one(
                {"user_id": user_id, "action_type": action_type},
                {
                    "$set": {
                        "expires_at": expires_at,
                        "created_at": datetime.datetime.utcnow()
                    }
                },
                upsert=True
            )
            
        except Exception as e:
            print(f"Error setting cooldown: {e}")
    
    async def get_cooldown(self, user_id: int, action_type: str) -> int:
        """Get remaining cooldown time in seconds"""
        try:
            cooldown = await self.db.cooldowns.find_one({
                "user_id": user_id,
                "action_type": action_type
            })
            
            if not cooldown:
                return 0
            
            now = datetime.datetime.utcnow()
            expires_at = cooldown["expires_at"]
            
            if now >= expires_at:
                # Cooldown expired, remove it
                await self.db.cooldowns.delete_one({
                    "user_id": user_id,
                    "action_type": action_type
                })
                return 0
            
            remaining = (expires_at - now).total_seconds()
            return max(0, int(remaining))
            
        except Exception as e:
            print(f"Error getting cooldown: {e}")
            return 0
    
    async def cleanup_expired_cooldowns(self):
        """Remove expired cooldowns"""
        try:
            now = datetime.datetime.utcnow()
            result = await self.db.cooldowns.delete_many({
                "expires_at": {"$lt": now}
            })
            
            if result.deleted_count > 0:
                print(f"Cleaned up {result.deleted_count} expired cooldowns")
                
        except Exception as e:
            print(f"Error cleaning cooldowns: {e}")
    
    async def add_battle_record(self, attacker_id: int, target_id: int, battle_type: str, 
                              result: str, damage_dealt: int, coins_stolen: int, details: str = ""):
        """Add battle record to history"""
        try:
            battle_record = {
                "attacker_id": attacker_id,
                "target_id": target_id,
                "battle_type": battle_type,
                "result": result,
                "damage_dealt": damage_dealt,
                "coins_stolen": coins_stolen,
                "details": details,
                "timestamp": datetime.datetime.utcnow()
            }
            
            await self.db.battle_records.insert_one(battle_record)
            
        except Exception as e:
            print(f"Error adding battle record: {e}")
    
    async def get_leaderboard(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get top players leaderboard"""
        try:
            cursor = self.db.players.find().sort("soldiers", -1).limit(limit)
            leaderboard = []
            
            async for player in cursor:
                leaderboard.append(player)
            
            return leaderboard
            
        except Exception as e:
            print(f"Error getting leaderboard: {e}")
            return []
    
    async def delete_player(self, user_id: int) -> bool:
        """Delete a player (when army is destroyed)"""
        try:
            # Delete player
            await self.db.players.delete_one({"user_id": user_id})
            
            # Delete inventory
            await self.db.inventory.delete_many({"user_id": user_id})
            
            # Delete cooldowns
            await self.db.cooldowns.delete_many({"user_id": user_id})
            
            return True
            
        except Exception as e:
            print(f"Error deleting player: {e}")
            return False
    
    async def add_xp(self, user_id: int, amount: int) -> bool:
        """Add XP to player"""
        try:
            result = await self.db.players.update_one(
                {"user_id": user_id},
                {
                    "$inc": {"xp": amount},
                    "$set": {"last_active": datetime.datetime.utcnow()}
                }
            )
            
            return result.modified_count > 0
            
        except Exception as e:
            print(f"Error adding XP: {e}")
            return False
    
    async def get_player_level(self, user_id: int) -> int:
        """Get player's current level"""
        try:
            player = await self.get_player(user_id)
            if not player:
                return 1
            
            # Simple level calculation: level = 1 + (xp // 1000)
            xp = player.get("xp", 0)
            level = 1 + (xp // 1000)
            
            # Update level if it changed
            current_level = player.get("level", 1)
            if level != current_level:
                await self.update_player(user_id, level=level)
            
            return min(level, 100)  # Max level 100
            
        except Exception as e:
            print(f"Error getting player level: {e}")
            return 1
    
    async def close(self):
        """Close database connection"""
        if self.client:
            self.client.close()