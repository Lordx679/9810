import os
try:
    from admin_config import ADMIN_USER_IDS, BOT_OWNER_ID
except ImportError:
    # Fallback if admin_config.py doesn't exist
    ADMIN_USER_IDS = []
    BOT_OWNER_ID = None

class Config:
    """Game configuration settings"""
    
    def __init__(self):
        # Discord settings
        self.DISCORD_TOKEN = os.getenv("DISCORD_TOKEN", "YOUR_DISCORD_BOT_TOKEN")
        
        # Database settings
        self.DATABASE_PATH = "game.db"
        
        # Admin settings from admin_config.py
        self.ADMIN_IDS = ADMIN_USER_IDS.copy()
        
        # Bot owner ID (can be set via environment variable or admin_config.py)
        self.OWNER_ID = os.getenv("OWNER_ID", BOT_OWNER_ID)
        if self.OWNER_ID:
            self.OWNER_ID = int(self.OWNER_ID)
            if self.OWNER_ID not in self.ADMIN_IDS:
                self.ADMIN_IDS.append(self.OWNER_ID)
        
        # Game balance settings
        self.STARTING_SOLDIERS = 100
        self.STARTING_COINS = 0
        
        # Cooldown settings (in seconds)
        self.RAID_COOLDOWN = 300  # 5 minutes
        self.ATTACK_COOLDOWN = 600  # 10 minutes
        self.MISSILE_COOLDOWN = 900  # 15 minutes
        
        # Raid settings
        self.RAID_BASE_COINS = 50
        self.RAID_BONUS_COINS = 100
        self.RAID_SOLDIER_LOSS_RATE = 0.15
        self.RAID_MAX_LOSS_PERCENT = 0.3
        
        # Combat settings
        self.MIN_ATTACK_LOSS = 0.05
        self.MAX_ATTACK_LOSS = 0.7
        self.COIN_STEAL_MIN = 100
        self.COIN_STEAL_MAX = 500
        
        # Shop prices
        self.SHOP_PRICES = {
            'soldier': 5,
            'soldier_pack_10': 45,
            'soldier_pack_50': 200,
            'soldier_pack_200': 900,
            'base': 1000,
            'base_upgrade': 2000,
            'wall': 500,
            'wall_pack_5': 2000,
            'air_defense': 3000,
            'air_defense_ammo': 100,
            'destroyer_missile': 800,
            'ballistic_missile': 1500,
            'nuclear_missile': 5000,
            'missile_base': 2500
        }
        
        # Channel IDs (to be configured by server admins)
        self.GAME_CHANNELS = {
            'start': None,  # Channel for starting armies and attacks
            'raids': None,  # Channel for monster raids
            'shop': None,   # Channel for shopping
        }
        
        # Rank thresholds
        self.RANKS = [
            (10000, "مارشال 🎖️"),
            (5000, "جنرال ⭐"),
            (2000, "عقيد 🔰"),
            (1000, "رائد 🎯"),
            (500, "نقيب ⚡"),
            (200, "ملازم 🏅"),
            (100, "جندي أول 🔰"),
            (0, "مجند 👤")
        ]
        
        # Level system configuration
        self.MAX_LEVEL = 100
        self.XP_PER_LEVEL = 1000  # XP needed per level
        
        # Level benefits configuration
        self.LEVEL_BENEFITS = {
            5: {"discount": 0.05, "unlock": "جندي متقدم", "bonus": "خصم 5% على الأسلحة"},
            10: {"discount": 0.10, "unlock": "ضابط صف", "bonus": "خصم 10% + مكافآت غارات إضافية"},
            15: {"discount": 0.15, "unlock": "ملازم ثاني", "bonus": "خصم 15% + قوة إضافية في المعارك"},
            20: {"discount": 0.20, "unlock": "ملازم أول", "bonus": "خصم 20% + تقليل أوقات التبريد"},
            25: {"discount": 0.25, "unlock": "نقيب", "bonus": "خصم 25% + فتح الصواريخ المتقدمة"},
            30: {"discount": 0.30, "unlock": "رائد", "bonus": "خصم 30% + قوات جوية متطورة"},
            40: {"discount": 0.35, "unlock": "مقدم", "bonus": "خصم 35% + قوات بحرية"},
            50: {"discount": 0.40, "unlock": "عقيد", "bonus": "خصم 40% + مصانع الأسلحة"},
            60: {"discount": 0.45, "unlock": "عميد", "bonus": "خصم 45% + القواعد العسكرية"},
            70: {"discount": 0.50, "unlock": "لواء", "bonus": "خصم 50% + تجارة الأسلحة"},
            80: {"discount": 0.55, "unlock": "فريق", "bonus": "خصم 55% + العمليات النووية"},
            90: {"discount": 0.60, "unlock": "جنرال", "bonus": "خصم 60% + غزو الدول"},
            100: {"discount": 0.70, "unlock": "مارشال الجيوش", "bonus": "خصم 70% + جميع المميزات"}
        }
        
        # Monster types for raids
        self.MONSTERS = [
            {
                "name": "ذئب بري",
                "difficulty": 1,
                "coins_min": 30,
                "coins_max": 80,
                "min_soldiers": 10
            },
            {
                "name": "دب شرس",
                "difficulty": 2,
                "coins_min": 60,
                "coins_max": 120,
                "min_soldiers": 40
            },
            {
                "name": "تنين صغير",
                "difficulty": 3,
                "coins_min": 100,
                "coins_max": 200,
                "min_soldiers": 80
            },
            {
                "name": "عملاق الجبل",
                "difficulty": 4,
                "coins_min": 150,
                "coins_max": 300,
                "min_soldiers": 150
            },
            {
                "name": "تنين النار",
                "difficulty": 5,
                "coins_min": 250,
                "coins_max": 500,
                "min_soldiers": 300
            }
        ]
        
        # Anti-cheat settings
        self.MAX_RAIDS_PER_COMMAND = 10
        self.MAX_SOLDIERS_PER_PURCHASE = 1000
        self.SUSPICIOUS_ACTIVITY_THRESHOLD = 50  # Actions per hour
        
        # Embed colors
        self.COLORS = {
            'success': 0x00ff00,
            'error': 0xff0000,
            'info': 0x0099ff,
            'warning': 0xffa500,
            'raid': 0x8b4513,
            'combat': 0xff4500,
            'shop': 0x9370db
        }
        
        # Game messages in Arabic
        self.MESSAGES = {
            'army_created': "تم إنشاء الجيش بنجاح! 🎖️",
            'army_exists': "لديك جيش بالفعل!",
            'no_army': "لا يوجد لديك جيش! استخدم أمر /البدء لإنشاء جيش",
            'no_soldiers': "لا يوجد لديك جنود!",
            'army_destroyed': "جيشك محطم، ابدأ من جديد",
            'insufficient_coins': "ليس لديك عملات كافية!",
            'cooldown_active': "انتظر قليلاً! ⏰",
            'purchase_success': "تم الشراء بنجاح! ✅",
            'attack_success': "هجوم ناجح! ⚔️",
            'missile_intercepted': "تم اعتراض الصاروخ! 🛡️",
            'system_error': "حدث خطأ في النظام"
        }
    
    def calculate_level(self, xp: int) -> int:
        """Calculate player level based on XP"""
        level = min(xp // self.XP_PER_LEVEL + 1, self.MAX_LEVEL)
        return level
    
    def get_xp_for_next_level(self, current_xp: int) -> int:
        """Get XP needed for next level"""
        current_level = self.calculate_level(current_xp)
        if current_level >= self.MAX_LEVEL:
            return 0
        next_level_xp = current_level * self.XP_PER_LEVEL
        return next_level_xp - current_xp
    
    def get_level_benefits(self, level: int) -> dict:
        """Get benefits for a specific level"""
        benefits = {"discount": 0.0, "unlock": "", "bonus": ""}
        
        for level_threshold in sorted(self.LEVEL_BENEFITS.keys()):
            if level >= level_threshold:
                benefits.update(self.LEVEL_BENEFITS[level_threshold])
        
        return benefits
    
    def apply_level_discount(self, price: int, level: int) -> int:
        """Apply level discount to price"""
        benefits = self.get_level_benefits(level)
        discount = benefits.get("discount", 0.0)
        discounted_price = int(price * (1 - discount))
        return max(discounted_price, 1)  # Minimum price of 1

    def get_rank(self, soldiers: int) -> str:
        """Get military rank based on soldier count"""
        for threshold, rank in self.RANKS:
            if soldiers >= threshold:
                return rank
        return self.RANKS[-1][1]
    
    def get_color(self, color_type: str) -> int:
        """Get embed color by type"""
        return self.COLORS.get(color_type, self.COLORS['info'])
    
    def is_admin(self, user_id: int) -> bool:
        """Check if user is an admin"""
        return user_id in self.ADMIN_IDS
    
    def is_owner(self, user_id: int) -> bool:
        """Check if user is the bot owner"""
        return self.OWNER_ID is not None and user_id == self.OWNER_ID
    
    def get_message(self, message_key: str) -> str:
        """Get localized message"""
        return self.MESSAGES.get(message_key, "رسالة غير محددة")
