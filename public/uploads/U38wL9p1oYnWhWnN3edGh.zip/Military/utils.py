import random
import time
import re
from typing import List, Dict, Any, Optional

class GameUtils:
    """Utility functions for the game"""
    
    @staticmethod
    def format_number(number: int) -> str:
        """Format numbers with Arabic numerals and separators"""
        # Convert to Arabic numerals
        english_to_arabic = str.maketrans('0123456789', '٠١٢٣٤٥٦٧٨٩')
        
        # Add thousand separators
        formatted = f"{number:,}".replace(',', '،')
        return formatted.translate(english_to_arabic)
    
    @staticmethod
    def format_time_remaining(seconds: int) -> str:
        """Format time remaining in Arabic"""
        if seconds <= 0:
            return "الآن"
        
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        seconds = seconds % 60
        
        parts = []
        if hours > 0:
            parts.append(f"{hours} ساعة")
        if minutes > 0:
            parts.append(f"{minutes} دقيقة")
        if seconds > 0:
            parts.append(f"{seconds} ثانية")
        
        return " و ".join(parts)
    
    @staticmethod
    def calculate_success_rate(attacker_power: int, defender_power: int) -> float:
        """Calculate battle success rate"""
        if defender_power == 0:
            return 1.0
        
        ratio = attacker_power / defender_power
        # Sigmoid function for balanced combat
        return 1 / (1 + pow(2.718, -2 * (ratio - 1)))
    
    @staticmethod
    def generate_battle_description(attacker_name: str, defender_name: str, 
                                  attacker_wins: bool, casualties: Dict[str, int]) -> str:
        """Generate battle description text"""
        if attacker_wins:
            templates = [
                f"🏆 انتصر {attacker_name} على {defender_name} في معركة ضارية!",
                f"⚔️ حقق {attacker_name} نصراً ساحقاً ضد {defender_name}!",
                f"🎖️ تفوق جيش {attacker_name} على دفاعات {defender_name}!"
            ]
        else:
            templates = [
                f"🛡️ صد {defender_name} هجوم {attacker_name} ببسالة!",
                f"💪 تمكن {defender_name} من إيقاف تقدم {attacker_name}!",
                f"🏰 فشل {attacker_name} في اختراق دفاعات {defender_name}!"
            ]
        
        return random.choice(templates)
    
    @staticmethod
    def calculate_raid_rewards(player_level: int, monster_difficulty: int) -> Dict[str, int]:
        """Calculate raid rewards based on player level and monster difficulty"""
        base_coins = monster_difficulty * 50
        level_bonus = player_level * 10
        random_bonus = random.randint(0, monster_difficulty * 20)
        
        total_coins = base_coins + level_bonus + random_bonus
        
        # Experience points for future features
        experience = monster_difficulty * 25
        
        return {
            'coins': total_coins,
            'experience': experience
        }
    
    @staticmethod
    def validate_army_name(name: str) -> bool:
        """Validate army name"""
        if not name or len(name.strip()) == 0:
            return False
        
        # Remove extra spaces
        name = re.sub(r'\s+', ' ', name.strip())
        
        # Check length
        if len(name) < 3 or len(name) > 50:
            return False
        
        # Check for inappropriate content (basic check)
        inappropriate_words = ['admin', 'bot', 'discord', 'test']
        name_lower = name.lower()
        
        for word in inappropriate_words:
            if word in name_lower:
                return False
        
        return True
    
    @staticmethod
    def generate_random_event() -> Optional[Dict[str, Any]]:
        """Generate random events for raids"""
        events = [
            {
                'type': 'treasure',
                'message': '💎 عثر جيشك على كنز مدفون!',
                'bonus_coins': random.randint(100, 300),
                'chance': 0.05  # 5% chance
            },
            {
                'type': 'ambush',
                'message': '🏹 تعرض جيشك لكمين! خسرت بعض الجنود',
                'soldier_loss': random.randint(5, 15),
                'chance': 0.03  # 3% chance
            },
            {
                'type': 'reinforcement',
                'message': '🎖️ انضم مقاتلون محليون إلى جيشك!',
                'bonus_soldiers': random.randint(5, 20),
                'chance': 0.02  # 2% chance
            }
        ]
        
        for event in events:
            if random.random() < event['chance']:
                return event
        
        return None
    
    @staticmethod
    def get_army_status_emoji(soldier_count: int) -> str:
        """Get emoji based on army size"""
        if soldier_count >= 5000:
            return "🏰"  # Castle - Massive army
        elif soldier_count >= 2000:
            return "⚔️"  # Crossed swords - Large army
        elif soldier_count >= 1000:
            return "🛡️"  # Shield - Medium army
        elif soldier_count >= 500:
            return "📈"  # Trending up - Growing army
        elif soldier_count >= 100:
            return "🌱"  # Seedling - Small army
        elif soldier_count > 0:
            return "⚠️"  # Warning - Weak army
        else:
            return "💀"  # Skull - Destroyed army
    
    @staticmethod
    def calculate_defense_effectiveness(walls: int, air_defense: int, 
                                     air_defense_ammo: int) -> Dict[str, float]:
        """Calculate defense effectiveness percentages"""
        # Wall effectiveness against ground attacks
        wall_effectiveness = min(0.8, walls * 0.1)  # Max 80% reduction
        
        # Air defense effectiveness against missiles
        if air_defense > 0 and air_defense_ammo > 0:
            air_defense_effectiveness = min(0.9, air_defense * 0.15)  # Max 90% intercept chance
        else:
            air_defense_effectiveness = 0.0
        
        return {
            'wall_defense': wall_effectiveness,
            'air_defense': air_defense_effectiveness
        }
    
    @staticmethod
    def generate_combat_log(battle_result: Dict[str, Any]) -> List[str]:
        """Generate detailed combat log"""
        log = []
        
        if battle_result.get('attacker_wins'):
            log.append("⚔️ بدأت المعركة بهجوم شرس من المهاجم")
            log.append("🏃 تراجعت القوات المدافعة تحت الضغط")
            log.append("🏆 تمكن المهاجم من كسر خطوط الدفاع")
        else:
            log.append("🛡️ استعدت القوات المدافعة لصد الهجوم")
            log.append("💥 اشتبكت القوات في معركة ضارية")
            log.append("🏰 صمدت الدفاعات وأجبرت المهاجم على التراجع")
        
        # Add casualty information
        attacker_losses = battle_result.get('attacker_losses', 0)
        target_losses = battle_result.get('target_losses', 0)
        
        if attacker_losses > 0:
            log.append(f"💀 خسر المهاجم {attacker_losses} جندي")
        if target_losses > 0:
            log.append(f"💀 خسر المدافع {target_losses} جندي")
        
        coins_stolen = battle_result.get('coins_stolen', 0)
        if coins_stolen > 0:
            log.append(f"💰 تم الاستيلاء على {coins_stolen} عملة")
        
        return log
    
    @staticmethod
    def is_suspicious_activity(user_id: int, action_counts: Dict[str, int]) -> bool:
        """Check for suspicious activity patterns"""
        # This is a basic implementation - in production you'd want more sophisticated detection
        total_actions = sum(action_counts.values())
        
        # More than 50 actions per hour is suspicious
        return total_actions > 50
    
    @staticmethod
    def sanitize_input(text: str) -> str:
        """Sanitize user input"""
        # Remove potential harmful characters
        text = re.sub(r'[<>@#&]', '', text)
        
        # Limit length
        text = text[:100]
        
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text.strip())
        
        return text
    
    @staticmethod
    def generate_unique_id() -> str:
        """Generate unique identifier for battles/events"""
        return f"{int(time.time())}_{random.randint(1000, 9999)}"
