import asyncio
import asyncpg
from typing import Optional, Dict, Any, List, Set
import datetime
import os

class PostgresDatabase:
    def __init__(self):
        self.pool = None
        self.database_url = os.getenv('DATABASE_URL')
        
    async def initialize(self):
        """Initialize PostgreSQL connection pool"""
        try:
            self.pool = await asyncpg.create_pool(
                self.database_url,
                min_size=1,
                max_size=10,
                command_timeout=60
            )
            print("✓ PostgreSQL connected successfully")
            
            # Create tables
            await self.create_tables()
            print("✓ Database tables initialized")
            
        except Exception as e:
            print(f"❌ PostgreSQL connection failed: {e}")
            raise
    
    async def create_tables(self):
        """Create database tables"""
        async with self.pool.acquire() as connection:
            # Players table
            await connection.execute('''
                CREATE TABLE IF NOT EXISTS players (
                    user_id BIGINT PRIMARY KEY,
                    username TEXT NOT NULL,
                    army_name TEXT NOT NULL,
                    soldiers INTEGER DEFAULT 100,
                    coins INTEGER DEFAULT 1000,
                    xp INTEGER DEFAULT 0,
                    level INTEGER DEFAULT 1,
                    base_level INTEGER DEFAULT 1,
                    walls INTEGER DEFAULT 0,
                    air_defense INTEGER DEFAULT 0,
                    air_defense_ammo INTEGER DEFAULT 0,
                    missile_base INTEGER DEFAULT 0,
                    total_raids INTEGER DEFAULT 0,
                    successful_raids INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Inventory table
            await connection.execute('''
                CREATE TABLE IF NOT EXISTS inventory (
                    id SERIAL PRIMARY KEY,
                    user_id BIGINT NOT NULL,
                    item_type TEXT NOT NULL,
                    item_name TEXT NOT NULL,
                    quantity INTEGER DEFAULT 0,
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(user_id, item_type, item_name)
                )
            ''')
            
            # Cooldowns table
            await connection.execute('''
                CREATE TABLE IF NOT EXISTS cooldowns (
                    id SERIAL PRIMARY KEY,
                    user_id BIGINT NOT NULL,
                    action_type TEXT NOT NULL,
                    expires_at TIMESTAMP NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(user_id, action_type)
                )
            ''')
            
            # Battle records table
            await connection.execute('''
                CREATE TABLE IF NOT EXISTS battle_records (
                    id SERIAL PRIMARY KEY,
                    attacker_id BIGINT NOT NULL,
                    target_id BIGINT NOT NULL,
                    battle_type TEXT NOT NULL,
                    result TEXT NOT NULL,
                    damage_dealt INTEGER DEFAULT 0,
                    coins_stolen INTEGER DEFAULT 0,
                    details TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Authorized channels table
            await connection.execute('''
                CREATE TABLE IF NOT EXISTS authorized_channels (
                    channel_id BIGINT PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    channel_name TEXT,
                    authorized_by BIGINT NOT NULL,
                    authorized_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Player changes log table
            await connection.execute('''
                CREATE TABLE IF NOT EXISTS player_changes (
                    id SERIAL PRIMARY KEY,
                    user_id BIGINT NOT NULL,
                    change_type TEXT NOT NULL,
                    old_value TEXT,
                    new_value TEXT,
                    changed_by TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Add missing columns if they don't exist
            try:
                await connection.execute('ALTER TABLE players ADD COLUMN IF NOT EXISTS missile_base INTEGER DEFAULT 0')
                await connection.execute('ALTER TABLE players ADD COLUMN IF NOT EXISTS total_raids INTEGER DEFAULT 0')
                await connection.execute('ALTER TABLE players ADD COLUMN IF NOT EXISTS successful_raids INTEGER DEFAULT 0')
            except Exception as e:
                print(f"Note: Column addition handled: {e}")
            
            # Create indexes
            await connection.execute('CREATE INDEX IF NOT EXISTS idx_players_user_id ON players(user_id)')
            await connection.execute('CREATE INDEX IF NOT EXISTS idx_inventory_user_id ON inventory(user_id)')
            await connection.execute('CREATE INDEX IF NOT EXISTS idx_cooldowns_user_id ON cooldowns(user_id)')
            await connection.execute('CREATE INDEX IF NOT EXISTS idx_cooldowns_expires ON cooldowns(expires_at)')
            await connection.execute('CREATE INDEX IF NOT EXISTS idx_battle_records_attacker ON battle_records(attacker_id)')
            await connection.execute('CREATE INDEX IF NOT EXISTS idx_battle_records_target ON battle_records(target_id)')
            await connection.execute('CREATE INDEX IF NOT EXISTS idx_authorized_channels_guild ON authorized_channels(guild_id)')
            await connection.execute('CREATE INDEX IF NOT EXISTS idx_player_changes_user ON player_changes(user_id)')
    
    async def log_player_change(self, user_id: int, change_type: str, old_value: str, new_value: str, changed_by: str = "system"):
        """Log player changes for tracking"""
        async with self.pool.acquire() as connection:
            await connection.execute('''
                INSERT INTO player_changes (user_id, change_type, old_value, new_value, changed_by)
                VALUES ($1, $2, $3, $4, $5)
            ''', user_id, change_type, str(old_value), str(new_value), changed_by)
    
    async def create_player(self, user_id: int, username: str, army_name: str) -> bool:
        """Create a new player"""
        try:
            async with self.pool.acquire() as connection:
                await connection.execute('''
                    INSERT INTO players (user_id, username, army_name, soldiers, coins, xp, level, base_level, walls, air_defense, air_defense_ammo, missile_base, total_raids, successful_raids)
                    VALUES ($1, $2, $3, 100, 1000, 0, 1, 1, 0, 0, 0, 0, 0, 0)
                ''', user_id, username, army_name)
                
                # Log player creation
                await self.log_player_change(user_id, "player_created", "", f"army_name: {army_name}", "user")
                return True
                
        except Exception as e:
            print(f"Error creating player: {e}")
            return False
    
    async def get_player(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Get player data"""
        try:
            async with self.pool.acquire() as connection:
                # Update last active time
                await connection.execute('''
                    UPDATE players SET last_active = CURRENT_TIMESTAMP WHERE user_id = $1
                ''', user_id)
                
                row = await connection.fetchrow('''
                    SELECT * FROM players WHERE user_id = $1
                ''', user_id)
                
                if row:
                    return dict(row)
                return None
                
        except Exception as e:
            print(f"Error getting player: {e}")
            return None
    
    async def update_player(self, user_id: int, **kwargs) -> bool:
        """Update player data with change logging"""
        try:
            if not kwargs:
                return True
            
            async with self.pool.acquire() as connection:
                # Get current values for logging
                old_player = await connection.fetchrow('SELECT * FROM players WHERE user_id = $1', user_id)
                
                # Build update query
                set_clauses = []
                values = []
                param_count = 1
                
                for key, value in kwargs.items():
                    set_clauses.append(f"{key} = ${param_count + 1}")
                    values.append(value)
                    param_count += 1
                
                set_clauses.append(f"updated_at = CURRENT_TIMESTAMP")
                
                query = f'''
                    UPDATE players 
                    SET {", ".join(set_clauses)}
                    WHERE user_id = $1
                '''
                
                result = await connection.execute(query, user_id, *values)
                
                # Log changes
                if old_player:
                    for key, new_value in kwargs.items():
                        old_value = old_player.get(key)
                        if old_value != new_value:
                            await self.log_player_change(user_id, f"update_{key}", str(old_value), str(new_value))
                
                return True
                
        except Exception as e:
            print(f"Error updating player: {e}")
            return False
    
    async def add_coins(self, user_id: int, amount: int) -> bool:
        """Add coins to player"""
        try:
            async with self.pool.acquire() as connection:
                old_coins = await connection.fetchval('SELECT coins FROM players WHERE user_id = $1', user_id)
                
                result = await connection.execute('''
                    UPDATE players 
                    SET coins = coins + $2, last_active = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = $1
                ''', user_id, amount)
                
                # Log coin change
                if old_coins is not None:
                    await self.log_player_change(user_id, "coins_added", str(old_coins), str(old_coins + amount))
                
                return True
                
        except Exception as e:
            print(f"Error adding coins: {e}")
            return False
    
    async def spend_coins(self, user_id: int, amount: int) -> bool:
        """Spend coins if player has enough"""
        try:
            async with self.pool.acquire() as connection:
                current_coins = await connection.fetchval('SELECT coins FROM players WHERE user_id = $1', user_id)
                
                if current_coins is None or current_coins < amount:
                    return False
                
                result = await connection.execute('''
                    UPDATE players 
                    SET coins = coins - $2, last_active = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = $1 AND coins >= $2
                ''', user_id, amount)
                
                # Log coin change
                await self.log_player_change(user_id, "coins_spent", str(current_coins), str(current_coins - amount))
                
                return True
                
        except Exception as e:
            print(f"Error spending coins: {e}")
            return False
    
    async def add_authorized_channel(self, channel_id: int, guild_id: int, channel_name: str, authorized_by: int) -> bool:
        """Add authorized channel"""
        try:
            async with self.pool.acquire() as connection:
                await connection.execute('''
                    INSERT INTO authorized_channels (channel_id, guild_id, channel_name, authorized_by)
                    VALUES ($1, $2, $3, $4)
                    ON CONFLICT (channel_id) DO UPDATE SET
                        channel_name = EXCLUDED.channel_name,
                        authorized_by = EXCLUDED.authorized_by,
                        authorized_at = CURRENT_TIMESTAMP
                ''', channel_id, guild_id, channel_name, authorized_by)
                return True
                
        except Exception as e:
            print(f"Error adding authorized channel: {e}")
            return False
    
    async def is_channel_authorized(self, channel_id: int) -> bool:
        """Check if channel is authorized"""
        try:
            async with self.pool.acquire() as connection:
                exists = await connection.fetchval('''
                    SELECT EXISTS(SELECT 1 FROM authorized_channels WHERE channel_id = $1)
                ''', channel_id)
                return exists
                
        except Exception as e:
            print(f"Error checking channel authorization: {e}")
            return False
    
    async def get_authorized_channels(self) -> Set[int]:
        """Get all authorized channel IDs"""
        try:
            async with self.pool.acquire() as connection:
                rows = await connection.fetch('SELECT channel_id FROM authorized_channels')
                return {row['channel_id'] for row in rows}
                
        except Exception as e:
            print(f"Error getting authorized channels: {e}")
            return set()
    
    async def get_player_inventory(self, user_id: int) -> Dict[str, Dict[str, int]]:
        """Get player's inventory"""
        try:
            async with self.pool.acquire() as connection:
                rows = await connection.fetch('''
                    SELECT item_type, item_name, quantity 
                    FROM inventory 
                    WHERE user_id = $1 AND quantity > 0
                ''', user_id)
                
                inventory = {}
                for row in rows:
                    item_type = row['item_type']
                    item_name = row['item_name']
                    quantity = row['quantity']
                    
                    if item_type not in inventory:
                        inventory[item_type] = {}
                    
                    inventory[item_type][item_name] = quantity
                
                return inventory
                
        except Exception as e:
            print(f"Error getting inventory: {e}")
            return {}
    
    async def add_item(self, user_id: int, item_type: str, item_name: str, quantity: int) -> bool:
        """Add item to player's inventory"""
        try:
            async with self.pool.acquire() as connection:
                await connection.execute('''
                    INSERT INTO inventory (user_id, item_type, item_name, quantity)
                    VALUES ($1, $2, $3, $4)
                    ON CONFLICT (user_id, item_type, item_name) 
                    DO UPDATE SET quantity = inventory.quantity + EXCLUDED.quantity
                ''', user_id, item_type, item_name, quantity)
                
                # Log inventory change
                await self.log_player_change(user_id, f"item_added_{item_type}", "", f"{item_name}: +{quantity}")
                return True
                
        except Exception as e:
            print(f"Error adding item: {e}")
            return False
    
    async def use_item(self, user_id: int, item_type: str, item_name: str, quantity: int = 1) -> bool:
        """Use/consume item from inventory"""
        try:
            async with self.pool.acquire() as connection:
                current_quantity = await connection.fetchval('''
                    SELECT quantity FROM inventory 
                    WHERE user_id = $1 AND item_type = $2 AND item_name = $3
                ''', user_id, item_type, item_name)
                
                if current_quantity is None or current_quantity < quantity:
                    return False
                
                new_quantity = current_quantity - quantity
                
                if new_quantity <= 0:
                    await connection.execute('''
                        DELETE FROM inventory 
                        WHERE user_id = $1 AND item_type = $2 AND item_name = $3
                    ''', user_id, item_type, item_name)
                else:
                    await connection.execute('''
                        UPDATE inventory 
                        SET quantity = $4 
                        WHERE user_id = $1 AND item_type = $2 AND item_name = $3
                    ''', user_id, item_type, item_name, new_quantity)
                
                # Log inventory change
                await self.log_player_change(user_id, f"item_used_{item_type}", str(current_quantity), str(new_quantity))
                return True
                
        except Exception as e:
            print(f"Error using item: {e}")
            return False
    
    async def get_player_missiles(self, user_id: int) -> List[Dict[str, Any]]:
        """Get player's missiles"""
        try:
            async with self.pool.acquire() as connection:
                rows = await connection.fetch('''
                    SELECT item_name as name, quantity 
                    FROM inventory 
                    WHERE user_id = $1 AND item_type = 'missiles' AND quantity > 0
                ''', user_id)
                
                return [dict(row) for row in rows]
                
        except Exception as e:
            print(f"Error getting missiles: {e}")
            return []
    
    async def set_cooldown(self, user_id: int, action_type: str, duration: int):
        """Set cooldown for an action"""
        try:
            async with self.pool.acquire() as connection:
                expires_at = datetime.datetime.utcnow() + datetime.timedelta(seconds=duration)
                
                await connection.execute('''
                    INSERT INTO cooldowns (user_id, action_type, expires_at)
                    VALUES ($1, $2, $3)
                    ON CONFLICT (user_id, action_type) 
                    DO UPDATE SET expires_at = EXCLUDED.expires_at, created_at = CURRENT_TIMESTAMP
                ''', user_id, action_type, expires_at)
                
        except Exception as e:
            print(f"Error setting cooldown: {e}")
    
    async def get_cooldown(self, user_id: int, action_type: str) -> int:
        """Get remaining cooldown time in seconds"""
        try:
            async with self.pool.acquire() as connection:
                expires_at = await connection.fetchval('''
                    SELECT expires_at FROM cooldowns 
                    WHERE user_id = $1 AND action_type = $2
                ''', user_id, action_type)
                
                if not expires_at:
                    return 0
                
                now = datetime.datetime.utcnow()
                
                if now >= expires_at:
                    # Cooldown expired, remove it
                    await connection.execute('''
                        DELETE FROM cooldowns 
                        WHERE user_id = $1 AND action_type = $2
                    ''', user_id, action_type)
                    return 0
                
                remaining = (expires_at - now).total_seconds()
                return max(0, int(remaining))
                
        except Exception as e:
            print(f"Error getting cooldown: {e}")
            return 0
    
    async def cleanup_expired_cooldowns(self):
        """Remove expired cooldowns"""
        try:
            async with self.pool.acquire() as connection:
                result = await connection.execute('''
                    DELETE FROM cooldowns WHERE expires_at < CURRENT_TIMESTAMP
                ''')
                
                if result != 'DELETE 0':
                    print(f"Cleaned up expired cooldowns")
                    
        except Exception as e:
            print(f"Error cleaning cooldowns: {e}")
    
    async def add_battle_record(self, attacker_id: int, target_id: int, battle_type: str, 
                              result: str, damage_dealt: int, coins_stolen: int, details: str = ""):
        """Add battle record to history"""
        try:
            async with self.pool.acquire() as connection:
                await connection.execute('''
                    INSERT INTO battle_records (attacker_id, target_id, battle_type, result, damage_dealt, coins_stolen, details)
                    VALUES ($1, $2, $3, $4, $5, $6, $7)
                ''', attacker_id, target_id, battle_type, result, damage_dealt, coins_stolen, details)
                
        except Exception as e:
            print(f"Error adding battle record: {e}")
    
    async def get_leaderboard(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get top players leaderboard"""
        try:
            async with self.pool.acquire() as connection:
                rows = await connection.fetch('''
                    SELECT * FROM players 
                    ORDER BY soldiers DESC, coins DESC 
                    LIMIT $1
                ''', limit)
                
                return [dict(row) for row in rows]
                
        except Exception as e:
            print(f"Error getting leaderboard: {e}")
            return []
    
    async def delete_player(self, user_id: int) -> bool:
        """Delete a player (when army is destroyed)"""
        try:
            async with self.pool.acquire() as connection:
                # Log player deletion
                await self.log_player_change(user_id, "player_deleted", "active", "deleted", "system")
                
                # Delete all related data
                await connection.execute('DELETE FROM inventory WHERE user_id = $1', user_id)
                await connection.execute('DELETE FROM cooldowns WHERE user_id = $1', user_id)
                await connection.execute('DELETE FROM players WHERE user_id = $1', user_id)
                
                return True
                
        except Exception as e:
            print(f"Error deleting player: {e}")
            return False
    
    async def add_xp(self, user_id: int, amount: int) -> bool:
        """Add XP to player"""
        try:
            async with self.pool.acquire() as connection:
                old_xp = await connection.fetchval('SELECT xp FROM players WHERE user_id = $1', user_id)
                
                result = await connection.execute('''
                    UPDATE players 
                    SET xp = xp + $2, last_active = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
                    WHERE user_id = $1
                ''', user_id, amount)
                
                # Log XP change
                if old_xp is not None:
                    await self.log_player_change(user_id, "xp_added", str(old_xp), str(old_xp + amount))
                
                return True
                
        except Exception as e:
            print(f"Error adding XP: {e}")
            return False
    
    async def get_player_level(self, user_id: int) -> int:
        """Get player's current level"""
        try:
            async with self.pool.acquire() as connection:
                xp = await connection.fetchval('SELECT xp FROM players WHERE user_id = $1', user_id)
                
                if xp is None:
                    return 1
                
                # Simple level calculation: level = 1 + (xp // 1000)
                level = 1 + (xp // 1000)
                level = min(level, 100)  # Max level 100
                
                # Update level if it changed
                current_level = await connection.fetchval('SELECT level FROM players WHERE user_id = $1', user_id)
                if current_level != level:
                    await connection.execute('''
                        UPDATE players SET level = $2 WHERE user_id = $1
                    ''', user_id, level)
                    
                    # Log level change
                    await self.log_player_change(user_id, "level_up", str(current_level), str(level))
                
                return level
                
        except Exception as e:
            print(f"Error getting player level: {e}")
            return 1
    
    async def close(self):
        """Close database connection pool"""
        if self.pool:
            await self.pool.close()