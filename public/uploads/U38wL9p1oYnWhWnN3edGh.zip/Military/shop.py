import discord
from typing import Dict, List, Tuple, Any
from postgres_database import PostgresDatabase

class Shop:
    def __init__(self, db: PostgresDatabase):
        self.db = db
        
        # Shop items configuration
        self.SHOP_ITEMS = {
            'soldiers': {
                'جنود مشاة': {'price': 5, 'quantity': 1, 'description': 'جنود مشاة أساسيون'},
                'مجموعة جنود': {'price': 45, 'quantity': 10, 'description': '10 جنود مشاة'},
                'فرقة كاملة': {'price': 200, 'quantity': 50, 'description': '50 جندي مشاة'},
                'كتيبة': {'price': 900, 'quantity': 200, 'description': '200 جندي نخبة'}
            },
            'base': {
                'قاعدة عسكرية': {'price': 1000, 'level': 1, 'description': 'قاعدة عسكرية أساسية'},
                'ترقية القاعدة': {'price': 2000, 'level': 1, 'description': 'ترقية مستوى القاعدة'}
            },
            'defense': {
                'سور حماية': {'price': 500, 'quantity': 1, 'description': 'سور واحد للحماية'},
                'مجموعة أسوار': {'price': 2000, 'quantity': 5, 'description': '5 أسوار حماية'},
                'نظام دفاع جوي': {'price': 3000, 'quantity': 1, 'description': 'نظام دفاع ضد الصواريخ'},
                'ذخيرة دفاع جوي': {'price': 100, 'quantity': 10, 'description': '10 قذائف دفاع جوي'}
            },
            'missiles': {
                'صاروخ مدمر': {'price': 800, 'damage': 100, 'description': 'يدمر الأسوار والمباني'},
                'صاروخ باليستي': {'price': 1500, 'damage': 200, 'description': 'صاروخ قوي لتدمير القواعد'},
                'صاروخ نووي': {'price': 5000, 'damage': 500, 'description': 'أقوى الصواريخ - دمار شامل!'},
                'قاعدة صواريخ': {'price': 2500, 'quantity': 1, 'description': 'لتصنيع وتخزين الصواريخ'}
            }
        }
    
    async def create_shop_menu(self, player: Dict[str, Any]) -> Tuple[discord.Embed, discord.ui.View]:
        """Create shop menu with categories"""
        # Get player level and benefits
        from config import Config
        config = Config()
        level = config.calculate_level(player.get('xp', 0))
        benefits = config.get_level_benefits(level)
        
        embed = discord.Embed(
            title="🏪 المتجر العسكري",
            description=f"**عملاتك:** {player['coins']} 💰\n**جنودك:** {player['soldiers']} ⚔️\n**مستواك:** {level} 🎖️",
            color=0x00ff00
        )
        
        # Show level discount if available
        if benefits['discount'] > 0:
            embed.add_field(
                name="🎉 مميزات المستوى",
                value=f"**خصم {int(benefits['discount']*100)}%** على جميع المشتريات!\n{benefits['bonus']}",
                inline=False
            )
        
        embed.add_field(
            name="🪖 الجنود",
            value="جنود مشاة وفرق قتالية",
            inline=True
        )
        
        embed.add_field(
            name="🏰 القواعد",
            value="قواعد عسكرية وترقيات",
            inline=True
        )
        
        embed.add_field(
            name="🛡️ الدفاع",
            value="أسوار وأنظمة دفاعية",
            inline=True
        )
        
        embed.add_field(
            name="🚀 الصواريخ",
            value="صواريخ وقواعد إطلاق",
            inline=True
        )
        
        embed.set_footer(text="اختر فئة للتسوق")
        
        view = ShopView(self, player)
        return embed, view
    
    async def create_category_menu(self, category: str, player: Dict[str, Any]) -> Tuple[discord.Embed, discord.ui.View]:
        """Create menu for specific category"""
        category_names = {
            'soldiers': '🪖 الجنود',
            'base': '🏰 القواعد',
            'defense': '🛡️ الدفاع',
            'missiles': '🚀 الصواريخ'
        }
        
        embed = discord.Embed(
            title=f"{category_names.get(category, category)}",
            description=f"**عملاتك:** {player['coins']} 💰",
            color=0x0099ff
        )
        
        items = self.SHOP_ITEMS.get(category, {})
        for item_name, item_data in items.items():
            price = item_data['price']
            description = item_data['description']
            
            # Apply level discount for display
            from config import Config
            config = Config()
            level = config.calculate_level(player.get('xp', 0))
            discounted_price = config.apply_level_discount(price, level)
            
            # Add quantity or special info
            if 'quantity' in item_data:
                description += f" (الكمية: {item_data['quantity']})"
            elif 'damage' in item_data:
                description += f" (الضرر: {item_data['damage']})"
            elif 'level' in item_data:
                description += f" (المستوى: {item_data['level']})"
            
            # Check if player can afford
            affordable = "✅" if player['coins'] >= discounted_price else "❌"
            
            # Show original and discounted price
            price_text = f"**السعر:** {discounted_price} 💰"
            if discounted_price < price:
                price_text += f" ~~{price}~~"
            
            embed.add_field(
                name=f"{affordable} {item_name}",
                value=f"{description}\n{price_text}",
                inline=False
            )
        
        view = CategoryView(self, category, player)
        return embed, view
    
    async def purchase_item(self, user_id: int, category: str, item_name: str, quantity: int = 1) -> Dict[str, Any]:
        """Purchase an item from the shop"""
        try:
            player = await self.db.get_player(user_id)
            if not player:
                return {'success': False, 'message': 'لا يوجد لديك جيش!'}
            
            items = self.SHOP_ITEMS.get(category, {})
            if item_name not in items:
                return {'success': False, 'message': 'العنصر غير موجود!'}
            
            item_data = items[item_name]
            base_price = item_data['price'] * quantity
            
            # Apply level discount
            from config import Config
            config = Config()
            level = config.calculate_level(player.get('xp', 0))
            total_price = config.apply_level_discount(base_price, level)
            
            # Calculate savings for display
            savings = base_price - total_price
            
            # Check if player has enough coins
            if player['coins'] < total_price:
                needed_coins = total_price - player['coins']
                return {'success': False, 'message': f'تحتاج {needed_coins} عملة إضافية!'}
            
            # Process purchase based on category
            success = False
            message = ""
            
            if category == 'soldiers':
                # Add soldiers
                soldiers_to_add = item_data['quantity'] * quantity
                await self.db.update_player(user_id, soldiers=player['soldiers'] + soldiers_to_add)
                success = True
                savings_msg = f" (وفرت {savings} عملة!)" if savings > 0 else ""
                message = f"تم شراء {soldiers_to_add} جندي بنجاح!{savings_msg}"
                
            elif category == 'base':
                if item_name == 'قاعدة عسكرية':
                    if player.get('base_level', 0) > 0:
                        return {'success': False, 'message': 'لديك قاعدة بالفعل! استخدم ترقية القاعدة'}
                    await self.db.update_player(user_id, base_level=1)
                    success = True
                    savings_msg = f" (وفرت {savings} عملة!)" if savings > 0 else ""
                    message = f"تم بناء القاعدة العسكرية!{savings_msg}"
                elif item_name == 'ترقية القاعدة':
                    if player.get('base_level', 0) == 0:
                        return {'success': False, 'message': 'يجب بناء قاعدة أولاً!'}
                    new_level = player['base_level'] + 1
                    await self.db.update_player(user_id, base_level=new_level)
                    success = True
                    savings_msg = f" (وفرت {savings} عملة!)" if savings > 0 else ""
                    message = f"تم ترقية القاعدة إلى المستوى {new_level}!{savings_msg}"
                    
            elif category == 'defense':
                if item_name == 'سور حماية':
                    walls_to_add = item_data['quantity'] * quantity
                    await self.db.update_player(user_id, walls=player.get('walls', 0) + walls_to_add)
                    success = True
                    message = f"تم بناء {walls_to_add} سور حماية!"
                elif item_name == 'مجموعة أسوار':
                    walls_to_add = item_data['quantity'] * quantity
                    await self.db.update_player(user_id, walls=player.get('walls', 0) + walls_to_add)
                    success = True
                    message = f"تم بناء {walls_to_add} سور حماية!"
                elif item_name == 'نظام دفاع جوي':
                    await self.db.update_player(user_id, air_defense=player.get('air_defense', 0) + quantity)
                    success = True
                    message = f"تم تركيب {quantity} نظام دفاع جوي!"
                elif item_name == 'ذخيرة دفاع جوي':
                    ammo_to_add = item_data['quantity'] * quantity
                    await self.db.update_player(user_id, air_defense_ammo=player.get('air_defense_ammo', 0) + ammo_to_add)
                    success = True
                    message = f"تم شراء {ammo_to_add} قذيفة دفاع جوي!"
                    
            elif category == 'missiles':
                if item_name == 'قاعدة صواريخ':
                    await self.db.update_player(user_id, missile_base=player.get('missile_base', 0) + quantity)
                    success = True
                    message = f"تم بناء {quantity} قاعدة صواريخ!"
                else:
                    # Add missile to inventory
                    await self.db.add_item(user_id, 'missiles', item_name, quantity)
                    success = True
                    message = f"تم شراء {quantity} {item_name}!"
            
            if success:
                # Deduct coins
                await self.db.spend_coins(user_id, total_price)
                
            return {'success': success, 'message': message}
            
        except Exception as e:
            print(f"Error in purchase_item: {e}")
            return {'success': False, 'message': 'حدث خطأ أثناء الشراء!'}

class ShopView(discord.ui.View):
    def __init__(self, shop: Shop, player: Dict[str, Any]):
        super().__init__(timeout=300)
        self.shop = shop
        self.player = player
    
    @discord.ui.button(label="🪖 الجنود", style=discord.ButtonStyle.primary)
    async def soldiers_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed, view = await self.shop.create_category_menu('soldiers', self.player)
        await interaction.response.edit_message(embed=embed, view=view)
    
    @discord.ui.button(label="🏰 القواعد", style=discord.ButtonStyle.primary)
    async def base_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed, view = await self.shop.create_category_menu('base', self.player)
        await interaction.response.edit_message(embed=embed, view=view)
    
    @discord.ui.button(label="🛡️ الدفاع", style=discord.ButtonStyle.primary)
    async def defense_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed, view = await self.shop.create_category_menu('defense', self.player)
        await interaction.response.edit_message(embed=embed, view=view)
    
    @discord.ui.button(label="🚀 الصواريخ", style=discord.ButtonStyle.primary)
    async def missiles_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed, view = await self.shop.create_category_menu('missiles', self.player)
        await interaction.response.edit_message(embed=embed, view=view)

class CategoryView(discord.ui.View):
    def __init__(self, shop: Shop, category: str, player: Dict[str, Any]):
        super().__init__(timeout=300)
        self.shop = shop
        self.category = category
        self.player = player
        
        # Create purchase buttons for each item
        items = shop.SHOP_ITEMS.get(category, {})
        for i, (item_name, item_data) in enumerate(items.items()):
            if i >= 4:  # Discord limit of 5 buttons per row
                break
            button = discord.ui.Button(
                label=item_name[:80],  # Discord label limit
                style=discord.ButtonStyle.success if player['coins'] >= item_data['price'] else discord.ButtonStyle.danger,
                custom_id=f"buy_{category}_{item_name}"
            )
            button.callback = self.create_purchase_callback(item_name)
            self.add_item(button)
        
        # Back button
        back_button = discord.ui.Button(label="🔙 العودة", style=discord.ButtonStyle.secondary)
        back_button.callback = self.back_callback
        self.add_item(back_button)
    
    def create_purchase_callback(self, item_name: str):
        async def purchase_callback(interaction: discord.Interaction):
            # Get fresh player data
            fresh_player = await self.shop.db.get_player(interaction.user.id)
            if not fresh_player:
                embed = discord.Embed(title="خطأ", description="لا يوجد لديك جيش!", color=0xff0000)
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            result = await self.shop.purchase_item(interaction.user.id, self.category, item_name)
            
            if result['success']:
                # Get updated player data to show new balance
                updated_player = await self.shop.db.get_player(interaction.user.id)
                remaining_coins = updated_player['coins'] if updated_player else 0
                
                embed = discord.Embed(
                    title="✅ تم الشراء بنجاح!",
                    description=f"{result['message']}\n\n💰 **رصيدك الحالي:** {remaining_coins} عملة",
                    color=0x00ff00
                )
            else:
                embed = discord.Embed(
                    title="❌ فشل الشراء",
                    description=result['message'],
                    color=0xff0000
                )
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
        
        return purchase_callback
    
    async def back_callback(self, interaction: discord.Interaction):
        # Get fresh player data
        fresh_player = await self.shop.db.get_player(interaction.user.id)
        if fresh_player:
            embed, view = await self.shop.create_shop_menu(fresh_player)
            await interaction.response.edit_message(embed=embed, view=view)
        else:
            embed = discord.Embed(title="خطأ", description="لا يوجد لديك جيش!", color=0xff0000)
            await interaction.response.edit_message(embed=embed, view=None)
